import Cocoa
import Carbon.HIToolbox
import CoreImage

// MARK: - 전역 단축키 (⌘ + Esc)

/// 어떤 앱을 쓰고 있든 눌리는 전역 단축키. Carbon 단축키 API라 손쉬운 사용 권한이 필요 없다.
final class GlobalHotKey {
    private var hotKeyRef: EventHotKeyRef?
    private var handlerRef: EventHandlerRef?
    private let action: @MainActor () -> Void

    init(keyCode: Int, modifiers: Int, action: @escaping @MainActor () -> Void) {
        self.action = action
        var eventType = EventTypeSpec(eventClass: OSType(kEventClassKeyboard), eventKind: UInt32(kEventHotKeyPressed))
        InstallEventHandler(GetApplicationEventTarget(), { _, _, userData in
            guard let userData else { return noErr }
            Unmanaged<GlobalHotKey>.fromOpaque(userData).takeUnretainedValue().fire()
            return noErr
        }, 1, &eventType, Unmanaged.passUnretained(self).toOpaque(), &handlerRef)

        let id = EventHotKeyID(signature: OSType(0x5350_4243), id: 1)   // 'SPBC'
        RegisterEventHotKey(UInt32(keyCode), UInt32(modifiers), id, GetApplicationEventTarget(), 0, &hotKeyRef)
    }

    private func fire() {
        let action = self.action
        Task { @MainActor in action() }
    }

    deinit {
        if let hotKeyRef { UnregisterEventHotKey(hotKeyRef) }
        if let handlerRef { RemoveEventHandler(handlerRef) }
    }
}

// MARK: - 전체 화면 앨범 커버

/// 화면 전체를 앨범 커버로 채우는 '지금 재생 중' 화면.
/// 배경은 커버를 크게 흐린 것, 가운데에 선명한 커버 + 곡 정보 + 진행 바 + 가사.
@MainActor
final class FullscreenCoverController: NSObject {
    private let music: MusicBridge
    private let lyrics: LyricsProvider
    private var window: FullscreenWindow?
    private let root = FullscreenRootView()
    private let backdrop = CoverView()
    private let dim = NSView()
    private let cover = CoverView()
    private let coverShadowHost = NSView()
    private let titleLabel = NSTextField(labelWithString: "")
    private let artistLabel = NSTextField(labelWithString: "")
    private let albumLabel = NSTextField(labelWithString: "")
    private let lyricLabel = NSTextField(wrappingLabelWithString: "")
    private let nextLyricLabel = NSTextField(labelWithString: "")
    private let progress = ProgressBarView()
    private let elapsedLabel = NSTextField(labelWithString: "")
    private let remainingLabel = NSTextField(labelWithString: "")
    private var timer: Timer?
    private var shownArtwork: NSImage?
    private var shownKey: String?
    private var shownLyric: String?
    private(set) var isVisible = false

    init(music: MusicBridge, lyrics: LyricsProvider) {
        self.music = music
        self.lyrics = lyrics
        super.init()

        root.wantsLayer = true
        root.layer?.backgroundColor = NSColor.black.cgColor
        dim.wantsLayer = true
        dim.layer?.backgroundColor = NSColor.black.withAlphaComponent(0.35).cgColor

        coverShadowHost.wantsLayer = true
        coverShadowHost.shadow = {
            let s = NSShadow()
            s.shadowColor = NSColor.black.withAlphaComponent(0.5)
            s.shadowBlurRadius = 40
            s.shadowOffset = NSSize(width: 0, height: -12)
            return s
        }()
        cover.cornerRadius = 18

        for label in [titleLabel, artistLabel, albumLabel, elapsedLabel, remainingLabel, nextLyricLabel] {
            label.alignment = .center
            label.lineBreakMode = .byTruncatingTail
            label.textColor = .white
        }
        lyricLabel.alignment = .center
        lyricLabel.textColor = .white
        lyricLabel.maximumNumberOfLines = 2
        lyricLabel.isSelectable = false
        artistLabel.textColor = NSColor.white.withAlphaComponent(0.8)
        albumLabel.textColor = NSColor.white.withAlphaComponent(0.55)
        nextLyricLabel.textColor = NSColor.white.withAlphaComponent(0.45)
        elapsedLabel.textColor = NSColor.white.withAlphaComponent(0.6)
        remainingLabel.textColor = NSColor.white.withAlphaComponent(0.6)
        elapsedLabel.alignment = .left
        remainingLabel.alignment = .right

        for view in [backdrop, dim, coverShadowHost, titleLabel, artistLabel, albumLabel,
                     progress, elapsedLabel, remainingLabel, lyricLabel, nextLyricLabel] as [NSView] {
            root.addSubview(view)
        }
        coverShadowHost.addSubview(cover)
        root.onDismiss = { [weak self] in self?.hide() }
    }

    func toggle() {
        isVisible ? hide() : show()
    }

    // MARK: 보이기 / 숨기기

    func show() {
        guard !isVisible else { return }
        isVisible = true
        window?.orderOut(nil)        // 닫히는 중이던 이전 창은 바로 치움
        // 마우스가 있는 화면을 채움
        let mouse = NSEvent.mouseLocation
        let screen = NSScreen.screens.first { $0.frame.contains(mouse) } ?? NSScreen.main ?? NSScreen.screens[0]

        let w = FullscreenWindow(contentRect: screen.frame, styleMask: [.borderless], backing: .buffered, defer: false)
        w.level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.screenSaverWindow)))
        w.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]
        w.isOpaque = true
        w.backgroundColor = .black
        w.isReleasedWhenClosed = false
        w.alphaValue = 0
        w.contentView = root
        w.setFrame(screen.frame, display: true)
        window = w

        shownArtwork = nil
        shownKey = nil
        shownLyric = nil
        layout(in: root.bounds)
        refresh()

        NSApp.activate()
        w.makeKeyAndOrderFront(nil)
        w.makeFirstResponder(root)
        NSCursor.setHiddenUntilMouseMoves(true)
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.45
            w.animator().alphaValue = 1
        }

        let t = Timer(timeInterval: 0.1, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
        t.tolerance = 0.02
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    func hide() {
        guard isVisible, let w = window else { return }
        isVisible = false
        timer?.invalidate()
        timer = nil
        NSAnimationContext.runAnimationGroup({ context in
            context.duration = 0.35
            w.animator().alphaValue = 0
        }, completionHandler: { [weak self] in
            MainActor.assumeIsolated {
                guard let self, !self.isVisible else { return }
                w.orderOut(nil)
                self.window = nil
            }
        })
    }

    // MARK: 배치

    private func layout(in bounds: NSRect) {
        backdrop.frame = bounds
        dim.frame = bounds
        let h = bounds.height
        let w = bounds.width
        let coverSide = floor(min(h * 0.48, w * 0.42))
        let coverY = floor(h * 0.42)
        coverShadowHost.frame = NSRect(x: floor((w - coverSide) / 2), y: coverY, width: coverSide, height: coverSide)
        cover.frame = coverShadowHost.bounds

        let textWidth = min(w * 0.7, 900)
        let textX = floor((w - textWidth) / 2)
        titleLabel.font = .systemFont(ofSize: 34, weight: .bold)
        artistLabel.font = .systemFont(ofSize: 22, weight: .medium)
        albumLabel.font = .systemFont(ofSize: 16, weight: .regular)
        var y = coverY - 30 - 44
        titleLabel.frame = NSRect(x: textX, y: y, width: textWidth, height: 44)
        y -= 30
        artistLabel.frame = NSRect(x: textX, y: y, width: textWidth, height: 28)
        y -= 24
        albumLabel.frame = NSRect(x: textX, y: y, width: textWidth, height: 22)

        let barWidth = min(coverSide * 1.2, w * 0.6)
        let barX = floor((w - barWidth) / 2)
        y -= 30
        progress.frame = NSRect(x: barX, y: y, width: barWidth, height: 4)
        let timeFont = NSFont.monospacedDigitSystemFont(ofSize: 13, weight: .medium)
        elapsedLabel.font = timeFont
        remainingLabel.font = timeFont
        elapsedLabel.frame = NSRect(x: barX, y: y - 22, width: 80, height: 18)
        remainingLabel.frame = NSRect(x: barX + barWidth - 80, y: y - 22, width: 80, height: 18)

        lyricLabel.font = .systemFont(ofSize: 28, weight: .bold)
        nextLyricLabel.font = .systemFont(ofSize: 20, weight: .semibold)
        lyricLabel.preferredMaxLayoutWidth = textWidth
        y -= 22 + 30 + 74
        lyricLabel.frame = NSRect(x: textX, y: y, width: textWidth, height: 74)
        nextLyricLabel.frame = NSRect(x: textX, y: y - 30, width: textWidth, height: 26)
    }

    // MARK: 내용 갱신

    @objc private func tick() {
        refresh()
    }

    private func refresh() {
        let track = music.track
        if track?.key != shownKey {
            shownKey = track?.key
            titleLabel.stringValue = track.map { $0.title.isEmpty ? "제목 없음" : $0.title } ?? "재생 중인 곡 없음"
            artistLabel.stringValue = track?.artist ?? ""
            albumLabel.stringValue = track?.album ?? ""
            lyrics.load(for: track)
        }
        // 새 곡 커버를 받는 동안엔 이전 커버 유지 → 받으면 크로스페이드
        if music.artwork !== shownArtwork, music.artwork != nil || track == nil || shownArtwork == nil {
            let first = shownArtwork == nil
            shownArtwork = music.artwork
            cover.setImage(music.artwork, fade: first ? 0 : 0.7)
            backdrop.setImage(music.artwork.flatMap { Self.blurred($0) }, fade: first ? 0 : 1.0)
            coverShadowHost.isHidden = music.artwork == nil
        }

        // 진행 바
        if let track, track.duration > 0 {
            let position = music.currentPosition
            progress.value = CGFloat(position / track.duration)
            elapsedLabel.stringValue = Self.format(position)
            remainingLabel.stringValue = "-" + Self.format(track.duration - position)
        } else {
            progress.value = 0
            elapsedLabel.stringValue = ""
            remainingLabel.stringValue = ""
        }

        // 가사
        let pair = track == nil ? nil : lyrics.lines(at: music.currentPosition)
        let current = pair?.current ?? ""
        if current != shownLyric {
            shownLyric = current
            lyricLabel.stringValue = pair == nil ? "" : (current.isEmpty ? "♪" : current)
            nextLyricLabel.stringValue = pair?.next ?? ""
            lyricLabel.alphaValue = 0.2
            NSAnimationContext.runAnimationGroup { context in
                context.duration = 0.3
                lyricLabel.animator().alphaValue = 1
            }
        }
    }

    private static func format(_ seconds: Double) -> String {
        let s = max(0, Int(seconds.rounded()))
        return String(format: "%d:%02d", s / 60, s % 60)
    }

    private static let ciContext = CIContext()

    /// 배경용: 크게 흐리고 살짝 어둡게
    private static func blurred(_ image: NSImage) -> NSImage? {
        guard let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return nil }
        let source = CIImage(cgImage: cg)
        let sigma = Double(max(cg.width, cg.height)) / 18
        let output = source.clampedToExtent()
            .applyingGaussianBlur(sigma: sigma)
            .applyingFilter("CIColorControls", parameters: [kCIInputSaturationKey: 1.3,
                                                            kCIInputBrightnessKey: -0.05])
            .cropped(to: source.extent)
        guard let result = ciContext.createCGImage(output, from: source.extent) else { return nil }
        return NSImage(cgImage: result, size: image.size)
    }
}

/// 테두리 없는 창이지만 키 입력(Esc)을 받을 수 있게
final class FullscreenWindow: NSWindow {
    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
}

/// Esc 또는 클릭으로 닫기
final class FullscreenRootView: NSView {
    var onDismiss: (@MainActor () -> Void)?

    override var acceptsFirstResponder: Bool { true }

    override func keyDown(with event: NSEvent) {
        if event.keyCode == UInt16(kVK_Escape) {
            onDismiss?()
        } else {
            super.keyDown(with: event)
        }
    }

    override func mouseDown(with event: NSEvent) {
        onDismiss?()
    }
}
