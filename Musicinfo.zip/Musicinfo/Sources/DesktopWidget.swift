import Cocoa
import CoreImage

// MARK: - Apple Music 연동

/// 다음 곡들
enum UpNext: Equatable {
    case tracks([String], total: Int)   // 앞 3곡 제목 + 전체 남은 곡 수
    case shuffle                        // 셔플 중인데 대기 목록을 못 읽음 (손쉬운 사용 권한 없음)
}

struct NowPlaying: Equatable, Sendable {
    var title: String
    var artist: String
    var album: String
    var duration: Double
    var key: String { "\(title)|\(artist)|\(album)" }
}

/// Apple Music의 재생 정보를 받아오고 조작한다.
/// - 곡 변경·재생 상태: 음악 앱이 보내는 알림(com.apple.Music.playerInfo) → 권한 필요 없음
/// - 앨범 아트·재생 위치·재생 버튼: AppleScript → 처음 한 번 '자동화' 권한 확인
@MainActor
final class MusicBridge: NSObject {
    static let bundleID = "com.apple.Music"

    private(set) var track: NowPlaying?
    private(set) var isPlaying = false
    private(set) var artwork: NSImage?
    private(set) var lastPlaying: TimeInterval = -100
    private(set) var lastError: String?
    private var position: Double = 0
    private var positionStamp: TimeInterval = 0
    private var artworkKey: String?
    private var artworkAttempts = 0
    private(set) var upNext: UpNext?
    // 알림으로 받은 곡: 직후 AppleScript가 이전 곡 정보를 돌려주면 무시하기 위해
    private var notifiedKey: String?
    private var notifiedAt: TimeInterval = -100
    private var refreshGeneration = 0
    private var resyncTimer: Timer?
    var onChange: (@MainActor () -> Void)?

    override init() {
        super.init()
        DistributedNotificationCenter.default().addObserver(
            self, selector: #selector(playerInfoChanged(_:)),
            name: NSNotification.Name("com.apple.Music.playerInfo"), object: nil)
        NSWorkspace.shared.notificationCenter.addObserver(
            self, selector: #selector(appTerminated(_:)),
            name: NSWorkspace.didTerminateApplicationNotification, object: nil)
        refresh()

        // 재생 중엔 4초마다 실제 재생 위치로 다시 맞춤 (가사가 밀리지 않게)
        let t = Timer(timeInterval: 4, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self, self.isPlaying else { return }
                self.refresh()
            }
        }
        t.tolerance = 0.5
        RunLoop.main.add(t, forMode: .common)
        resyncTimer = t
    }

    var isMusicRunning: Bool {
        !NSRunningApplication.runningApplications(withBundleIdentifier: MusicBridge.bundleID).isEmpty
    }

    /// 현재 재생 위치(초). 마지막으로 받은 위치에서 시간을 더해 계산
    var currentPosition: Double {
        guard let track else { return 0 }
        let p = isPlaying ? position + (monotonicNow() - positionStamp) : position
        return track.duration > 0 ? min(max(0, p), track.duration) : max(0, p)
    }

    // MARK: 재생 조작

    func playPause() { command("playpause") }
    func nextTrack() { command("next track") }
    func previousTrack() { command("previous track") }

    func openMusicApp() {
        if let app = NSRunningApplication.runningApplications(withBundleIdentifier: MusicBridge.bundleID).first {
            app.activate()
        }
    }

    private func command(_ verb: String) {
        _ = run("tell application \"Music\" to \(verb)")
        // 곡을 넘긴 직후엔 음악 앱이 아직 이전 곡·이전 위치를 돌려줄 때가 있어서
        // 바로 읽지 않고 잠깐 뒤에 두 번 확인
        scheduleRefresh(after: [0.25, 0.9])
    }

    /// 조금 뒤에 refresh (새로 예약하면 이전 예약은 취소)
    private func scheduleRefresh(after delays: [Double]) {
        refreshGeneration += 1
        let generation = refreshGeneration
        for delay in delays {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                MainActor.assumeIsolated {
                    guard let self, self.refreshGeneration == generation else { return }
                    self.refresh()
                }
            }
        }
    }

    // MARK: 정보 갱신

    @objc private func playerInfoChanged(_ note: Notification) {
        let info = note.userInfo ?? [:]
        let state = info["Player State"] as? String ?? ""
        if state == "Stopped" {
            clear()
            return
        }

        // 1단계: 알림에 이미 들어 있는 정보로 화면을 '즉시' 갱신 (AppleScript 없이)
        let wasPlaying = isPlaying
        isPlaying = state == "Playing"
        if isPlaying { lastPlaying = monotonicNow() }
        if let name = info["Name"] as? String {
            let totalMs = (info["Total Time"] as? NSNumber)?.doubleValue ?? 0
            let newTrack = NowPlaying(title: name,
                                      artist: info["Artist"] as? String ?? "",
                                      album: info["Album"] as? String ?? "",
                                      duration: totalMs / 1000)
            if newTrack.key != track?.key {
                position = 0            // 새 곡은 0초부터
                positionStamp = monotonicNow()
            }
            notifiedKey = newTrack.key
            notifiedAt = monotonicNow()
            track = newTrack
            if artworkKey != newTrack.key {
                // 이전 곡 커버가 새 곡 제목과 함께 보이지 않도록 바로 비우고 새로 가져옴
                artworkKey = nil
                artwork = nil
                advanceQueue(to: newTrack)
            }
        }
        if wasPlaying && !isPlaying {
            // 일시정지 순간의 위치를 고정
            position += monotonicNow() - positionStamp
            positionStamp = monotonicNow()
        } else if !wasPlaying && isPlaying {
            positionStamp = monotonicNow()
        }
        onChange?()

        // 2단계: 정확한 재생 위치·앨범 아트는 다음 순간에 따로 (화면 갱신을 막지 않도록)
        // 음악 앱이 늦게 반영하는 경우를 대비해 한 번 더 확인
        scheduleRefresh(after: [0.05, 0.8])
    }

    @objc private func appTerminated(_ note: Notification) {
        let app = note.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication
        if app?.bundleIdentifier == MusicBridge.bundleID { clear() }
    }

    private func clear() {
        track = nil
        artwork = nil
        artworkKey = nil
        notifiedKey = nil
        upNext = nil
        queue = []
        queueTotal = 0
        queueForKey = nil
        isPlaying = false
        onChange?()
    }

    /// 곡 정보·재생 상태·위치를 읽고, 곡이 바뀌었으면 앨범 아트도 새로 가져옴
    func refresh() {
        guard isMusicRunning else {
            clear()
            return
        }
        let source = """
        tell application "Music"
            try
                if player state is stopped then return {"stopped"}
                set t to current track
                set d to 0
                try
                    set d to duration of t
                end try
                return {(player state as text), (name of t), (artist of t), (album of t), d, player position}
            on error
                return {"stopped"}
            end try
        end tell
        """
        guard let result = run(source), result.numberOfItems >= 1 else {
            onChange?()
            return
        }
        let state = result.atIndex(1)?.stringValue ?? "stopped"
        guard state != "stopped", result.numberOfItems >= 6 else {
            clear()
            return
        }

        let newTrack = NowPlaying(title: result.atIndex(2)?.stringValue ?? "",
                                  artist: result.atIndex(3)?.stringValue ?? "",
                                  album: result.atIndex(4)?.stringValue ?? "",
                                  duration: result.atIndex(5)?.doubleValue ?? 0)
        // 알림으로 방금 새 곡을 받았는데 음악 앱이 아직 이전 곡을 돌려주면 → 무시하고 잠시 뒤 다시
        if let notifiedKey, newTrack.key != notifiedKey, monotonicNow() - notifiedAt < 1.5 {
            scheduleRefresh(after: [0.3])
            return
        }

        isPlaying = state == "playing"
        if isPlaying { lastPlaying = monotonicNow() }
        if newTrack.key != track?.key { artwork = nil }
        track = newTrack
        position = result.atIndex(6)?.doubleValue ?? 0
        positionStamp = monotonicNow()

        if artworkKey != newTrack.key {
            artworkKey = newTrack.key
            artworkAttempts = 0
            loadArtwork(for: newTrack)
            advanceQueue(to: newTrack)
        }
        onChange?()
    }

    /// 다음 곡: 지금 재생 목록에서 현재 곡 바로 다음 곡.
    /// (음악 앱의 '다음 재생' 대기열은 AppleScript로 읽을 수 없어서 재생 목록 순서를 씀)
    // MARK: 다음 곡 목록 (한 번 읽어 두고 곡이 넘어갈 때마다 앞에서 하나씩 뺌)

    struct QueueEntry: Equatable {
        let title: String
        let subtitle: String
    }
    enum QueueStatus { case unknown, ok, notTrusted, noTable, minimized }
    static let queueChanged = Notification.Name("MusicInfo.queueChanged")

    private(set) var queue: [QueueEntry] = []
    private(set) var queueTotal = 0
    private(set) var queueStatus: QueueStatus = .unknown
    private var queueForKey: String?
    private var queueLoading = false
    private var queueReloadPending = false

    /// 곡이 바뀌면: 읽어 둔 목록에서 지금 곡까지 빼고 바로 보여 줌. 남은 게 3곡 미만이면 그사이 다시 읽음
    private func advanceQueue(to newTrack: NowPlaying) {
        // 알림과 AppleScript가 앨범 이름 등을 조금 다르게 줄 때가 있어서 제목+가수로만 같은 곡인지 판단
        let key = newTrack.title + "|" + newTrack.artist
        guard queueForKey != key else { return }
        queueForKey = key
        if let i = queue.prefix(6).firstIndex(where: { $0.title == newTrack.title }) {
            queue.removeFirst(i + 1)
            queueTotal = max(queue.count, queueTotal - (i + 1))
            publishQueue()
            if queue.count < 3 { reloadQueue() }
        } else if queue.isEmpty {
            reloadQueue()
        } else {
            // 목록에 없는 곡으로 건너뜀(이전 곡·직접 고른 곡) → 새로 읽음, 그동안은 지금 목록 유지
            reloadQueue()
        }
    }

    /// 음악 앱 재생 대기 목록을 다시 읽음 (읽는 동안 화면은 지금 목록 그대로)
    func reloadQueue() {
        guard !queueLoading else { queueReloadPending = true; return }
        guard MusicQueueReader.isTrusted,
              let pid = NSRunningApplication.runningApplications(withBundleIdentifier: MusicBridge.bundleID).first?.processIdentifier else {
            queueStatus = .notTrusted
            let fallback = playlistUpNext()
            if fallback != upNext { upNext = fallback; onChange?() }
            NotificationCenter.default.post(name: Self.queueChanged, object: self)
            return
        }
        // 음악 창이 최소화돼 있으면 목록이 멈춰 있어서 읽어도 예전 것 → 지금 갖고 있는 목록(곡마다 당겨 온 것)을 그대로 씀
        if MusicQueueReader.isMinimized(pid: pid) {
            queueStatus = .minimized
            if queue.isEmpty {
                // 처음 한 번은 멈춘 목록이라도 읽어 둠 (지금 곡 앞부분은 잘라 냄)
            } else {
                publishQueue()
                return
            }
        }
        queueLoading = true
        let currentTitle = track?.title
        let minimized = queueStatus == .minimized
        Task { @MainActor [weak self] in
            let result = await MusicQueueReader.read(pid: pid, limit: 30, current: currentTitle)
            guard let self else { return }
            self.queueLoading = false
            if let result {
                let subs = result.subtitles + Array(repeating: "", count: max(0, result.titles.count - result.subtitles.count))
                self.queue = zip(result.titles, subs).map { QueueEntry(title: $0.0, subtitle: $0.1) }
                self.queueTotal = result.total
                self.queueStatus = minimized ? .minimized : .ok
                // 읽는 사이에 곡이 넘어갔으면 그만큼 빼기
                if let now = self.track?.title, now != currentTitle,
                   let i = self.queue.prefix(6).firstIndex(where: { $0.title == now }) {
                    self.queue.removeFirst(i + 1)
                    self.queueTotal = max(self.queue.count, self.queueTotal - (i + 1))
                }
                debugLog("queue loaded: \(self.queue.count) (total \(self.queueTotal))")
            } else {
                self.queueStatus = .noTable        // 목록이 닫혀 있음 — 지금 목록은 유지
            }
            self.publishQueue()
            if self.queueReloadPending {
                self.queueReloadPending = false
                self.reloadQueue()
            }
        }
    }

    /// 최소화된 음악 창을 잠깐 펼쳐서 목록을 새로 읽고 다시 최소화
    func refreshQueueRestoringWindow() {
        guard let pid = NSRunningApplication.runningApplications(withBundleIdentifier: MusicBridge.bundleID).first?.processIdentifier else { return }
        MusicQueueReader.setMinimized(pid: pid, false)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) { [weak self] in
            MainActor.assumeIsolated {
                guard let self else { return }
                self.queueStatus = .unknown
                self.queue = []
                self.queueLoading = false
                self.reloadQueue()
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                    MusicQueueReader.setMinimized(pid: pid, true)
                }
            }
        }
    }

    private func publishQueue() {
        let value: UpNext? = queueStatus == .ok || queueStatus == .minimized || !queue.isEmpty
            ? .tracks(queue.prefix(3).map(\.title), total: queueTotal) : nil
        if value != upNext {
            upNext = value
            onChange?()
        }
        NotificationCenter.default.post(name: Self.queueChanged, object: self)
    }

    /// 예전 이름 호환
    private func loadUpNext() { reloadQueue() }

    private func playlistUpNext() -> UpNext? {
        let source = """
        tell application "Music"
            try
                if shuffle enabled then return {"shuffle"}
                set p to current playlist
                set c to current track
                set pid to persistent ID of c
                set n to count tracks of p
                set i to 0
                try
                    set i to index of c
                    if i > n or (persistent ID of track i of p) is not pid then set i to 0
                end try
                if i is 0 then return {"none"}
                set names to {"ok", n - i}
                repeat with k from i + 1 to i + 3
                    if k > n then exit repeat
                    set end of names to (name of track k of p)
                end repeat
                return names
            on error
                return {"none"}
            end try
        end tell
        """
        guard let result = run(source), result.numberOfItems >= 1 else { return nil }
        switch result.atIndex(1)?.stringValue {
        case "shuffle":
            return .shuffle
        case "ok" where result.numberOfItems >= 3:
            let total = Int(result.atIndex(2)?.int32Value ?? 0)
            let titles = (3...result.numberOfItems).compactMap { result.atIndex($0)?.stringValue }
            return .tracks(titles, total: total)
        default:
            return nil
        }
    }

    // MARK: 보관함 검색용 (⌘ 두 번 → 노래 검색)

    /// 보관함의 모든 노래 (제목·아티스트·앨범·고유 ID) — 한 번에 가져옴
    func libraryTracks() -> [LibraryTrack]? {
        let source = """
        tell application "Music"
            set lp to library playlist 1
            return {name of every track of lp, artist of every track of lp, album of every track of lp, persistent ID of every track of lp, genre of every track of lp, played count of every track of lp}
        end tell
        """
        guard let result = run(source), result.numberOfItems == 6,
              let names = result.atIndex(1), let artists = result.atIndex(2), let albums = result.atIndex(3),
              let ids = result.atIndex(4), let genres = result.atIndex(5), let counts = result.atIndex(6) else { return nil }
        let n = names.numberOfItems
        guard n > 0, [artists, albums, ids, genres, counts].allSatisfy({ $0.numberOfItems == n }) else { return [] }
        var tracks: [LibraryTrack] = []
        tracks.reserveCapacity(n)
        for i in 1...n {
            tracks.append(LibraryTrack(title: names.atIndex(i)?.stringValue ?? "",
                                       artist: artists.atIndex(i)?.stringValue ?? "",
                                       album: albums.atIndex(i)?.stringValue ?? "",
                                       persistentID: ids.atIndex(i)?.stringValue ?? "",
                                       genre: genres.atIndex(i)?.stringValue ?? "",
                                       playCount: Int(counts.atIndex(i)?.int32Value ?? 0)))
        }
        return tracks
    }

    /// 보관함 노래 한 곡의 앨범 아트 (검색 목록 썸네일용)
    func artwork(persistentID: String) -> NSImage? {
        guard let result = run("""
        tell application "Music"
            try
                return raw data of artwork 1 of (first track of library playlist 1 whose persistent ID is \(Self.quoted(persistentID)))
            end try
        end tell
        """, cache: false) else { return nil }
        let data = result.data
        return data.isEmpty ? nil : NSImage(data: data)
    }

    // MARK: 재생 설정 (셔플·반복·음량·좋아요)

    struct PlaybackOptions: Equatable {
        var shuffle = false
        var repeatMode = "off"      // off / one / all
        var volume = 50
        var favorited = false
    }

    func playbackOptions() -> PlaybackOptions? {
        guard let result = run("""
        tell application "Music"
            set fav to false
            try
                set fav to favorited of current track
            on error
                try
                    set fav to loved of current track
                end try
            end try
            return {shuffle enabled, (song repeat as text), sound volume, fav}
        end tell
        """), result.numberOfItems == 4 else { return nil }
        return PlaybackOptions(shuffle: result.atIndex(1)?.booleanValue ?? false,
                               repeatMode: result.atIndex(2)?.stringValue ?? "off",
                               volume: Int(result.atIndex(3)?.int32Value ?? 50),
                               favorited: result.atIndex(4)?.booleanValue ?? false)
    }

    func setShuffle(_ on: Bool) {
        _ = run("tell application \"Music\" to set shuffle enabled to \(on)")
        loadUpNext()
    }

    /// 끔 → 전체 → 한 곡 → 끔
    func cycleRepeat(from mode: String) -> String {
        let next = mode == "off" ? "all" : (mode == "all" ? "one" : "off")
        _ = run("tell application \"Music\" to set song repeat to \(next)")
        return next
    }

    func setVolume(_ volume: Int) {
        _ = run("tell application \"Music\" to set sound volume to \(max(0, min(100, volume)))", cache: false)
    }

    func setFavorited(_ on: Bool) {
        _ = run("""
        tell application "Music"
            try
                set favorited of current track to \(on)
            on error
                try
                    set loved of current track to \(on)
                end try
            end try
        end tell
        """)
    }

    /// 직접 만든 일반 플레이리스트 이름들 (스마트·폴더 제외)
    func userPlaylistNames() -> [String] {
        let source = """
        tell application "Music"
            set out to {}
            repeat with p in (user playlists whose smart is false)
                try
                    if special kind of p is none then set end of out to (name of p)
                end try
            end repeat
            return out
        end tell
        """
        guard let result = run(source), result.numberOfItems > 0 else { return [] }
        return (1...result.numberOfItems).compactMap { result.atIndex($0)?.stringValue }
    }

    private static func quoted(_ s: String) -> String {
        "\"" + s.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
    }

    /// 바로 재생 (보관함 순서로 이어서 재생)
    @discardableResult
    func play(persistentID: String) -> Bool {
        let ok = run("""
        tell application "Music" to play (first track of library playlist 1 whose persistent ID is \(Self.quoted(persistentID)))
        """, cache: false) != nil
        scheduleRefresh(after: [0.3, 1.0])
        return ok
    }

    /// 플레이리스트에 추가
    @discardableResult
    func add(persistentID: String, toPlaylist name: String) -> Bool {
        run("""
        tell application "Music"
            duplicate (first track of library playlist 1 whose persistent ID is \(Self.quoted(persistentID))) to (first user playlist whose name is \(Self.quoted(name)))
        end tell
        """, cache: false) != nil
    }

    /// 재생 대기열에 넣기: 음악 앱에서 그 노래를 선택(reveal)한 뒤 '노래' 메뉴의
    /// '바로 다음에 재생' / '대기열에 추가'를 누름 (AppleScript에는 대기열 명령이 없어서)
    func enqueue(persistentID: String, next: Bool, completion: @escaping @MainActor (Bool) -> Void) {
        guard run("""
        tell application "Music" to reveal (first track of library playlist 1 whose persistent ID is \(Self.quoted(persistentID)))
        """, cache: false) != nil,
              let pid = NSRunningApplication.runningApplications(withBundleIdentifier: MusicBridge.bundleID).first?.processIdentifier else {
            completion(false)
            return
        }
        let titles: Set<String> = next ? ["바로 다음에 재생", "Play Next", "次に再生"] : ["대기열에 추가", "Play Later", "後で再生"]
        Task { @MainActor [weak self] in
            var ok = false
            for _ in 0..<5 {            // 선택이 반영될 때까지 잠깐씩 기다리며 시도
                try? await Task.sleep(nanoseconds: 250_000_000)
                if MusicMenu.press(pid: pid, menuTitles: ["노래", "Song", "曲"], itemTitles: titles) { ok = true; break }
            }
            completion(ok)
            if ok { self?.loadUpNext(); self?.scheduleRefresh(after: [0.8]) }
        }
    }

    /// 앨범 아트를 '곡 정보와 같이' 읽어서, 정말 그 곡의 커버일 때만 씀.
    /// 아직 이전 곡이거나 커버가 준비 안 됐으면(스트리밍 곡) 잠시 뒤 다시 시도.
    private func loadArtwork(for expected: NowPlaying) {
        let source = """
        tell application "Music"
            try
                set t to current track
                set n to name of t
                set a to artist of t
                set b to album of t
                try
                    return {n, a, b, raw data of artwork 1 of t}
                end try
                try
                    return {n, a, b, data of artwork 1 of t}
                end try
                return {n, a, b}
            on error
                return {}
            end try
        end tell
        """
        var image: NSImage?
        var matches = false
        if let result = run(source), result.numberOfItems >= 3 {
            let key = "\(result.atIndex(1)?.stringValue ?? "")|\(result.atIndex(2)?.stringValue ?? "")|\(result.atIndex(3)?.stringValue ?? "")"
            matches = key == expected.key
            if matches, result.numberOfItems >= 4, let data = result.atIndex(4)?.data, !data.isEmpty {
                image = NSImage(data: data)
            }
        }
        if let image {
            artwork = image
            return
        }
        let key = expected.key
        // 음악 앱에서 못 받으면(스트리밍 곡은 커버를 늦게 받거나 아예 안 줌) → 인터넷에서 앨범 커버 찾기
        if matches, artworkAttempts == 3 { fetchOnlineArtwork(for: expected) }
        // 처음 3초는 0.3초마다, 그 뒤엔 2초마다 30초까지 다시 시도
        guard artworkAttempts < 24 else { return }
        artworkAttempts += 1
        let delay = artworkAttempts <= 10 ? 0.3 : 2.0
        DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
            MainActor.assumeIsolated {
                // 그사이 인터넷 커버를 받았으면 그만
                guard let self, self.artworkKey == key, self.track?.key == key, self.artwork == nil else { return }
                self.loadArtwork(for: expected)
                if self.artwork != nil { self.onChange?() }
            }
        }
    }

    // MARK: 인터넷 앨범 커버 (iTunes 검색 — 음악 앱이 커버를 안 줄 때)

    private var onlineArtCache: [String: NSImage] = [:]

    private func fetchOnlineArtwork(for track: NowPlaying) {
        let albumKey = "\(track.artist)|\(track.album)"
        if let cached = onlineArtCache[albumKey] {
            if artworkKey == track.key, track.key == self.track?.key, artwork == nil {
                artwork = cached
                onChange?()
            }
            return
        }
        let album = track.album, title = track.title, artist = track.artist, key = track.key
        Task { [weak self] in
            let image = await Self.searchArtwork(title: title, artist: artist, album: album)
            await MainActor.run {
                guard let self else { return }
                debugLog("artwork: online cover for \(title): \(image != nil)")
                guard let image else { return }
                self.onlineArtCache[albumKey] = image
                if self.artworkKey == key, self.track?.key == key, self.artwork == nil {
                    self.artwork = image
                    self.onChange?()
                }
            }
        }
    }

    /// iTunes 검색으로 커버 찾기: 여러 검색어·나라(한국·일본·미국)로 차례대로 시도
    nonisolated private static func searchArtwork(title: String, artist: String, album: String) async -> NSImage? {
        func norm(_ s: String) -> String {
            s.folding(options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive], locale: nil)
                .replacingOccurrences(of: "- single", with: "").replacingOccurrences(of: "- ep", with: "")
                .filter { $0.isLetter || $0.isNumber }
        }
        let wantAlbum = norm(album), wantTitle = norm(title)
        // (검색어, 종류)
        var queries: [(String, String)] = []
        if !album.isEmpty {
            queries.append(("\(artist) \(album)", "album"))
            queries.append((album, "album"))
        }
        queries.append(("\(title) \(artist)", "song"))
        queries.append((title, "song"))
        for country in ["kr", "jp", "us"] {
            for (term, entity) in queries {
                guard var components = URLComponents(string: "https://itunes.apple.com/search") else { continue }
                components.queryItems = [URLQueryItem(name: "term", value: term),
                                         URLQueryItem(name: "entity", value: entity),
                                         URLQueryItem(name: "limit", value: "15"),
                                         URLQueryItem(name: "country", value: country)]
                guard let url = components.url,
                      let (data, _) = try? await URLSession.shared.data(from: url),
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let results = json["results"] as? [[String: Any]], !results.isEmpty else { continue }
                let best = results.first { r in
                    let c = norm(r["collectionName"] as? String ?? "")
                    let t = norm(r["trackName"] as? String ?? "")
                    if entity == "album" { return !wantAlbum.isEmpty && (c == wantAlbum || c.hasPrefix(wantAlbum) || wantAlbum.hasPrefix(c) && !c.isEmpty) }
                    // 곡으로 찾을 땐: 제목이 같고, 앨범이 비슷하거나 앨범 정보가 없으면 OK
                    return t == wantTitle && (wantAlbum.isEmpty || c == wantAlbum || c.contains(wantAlbum) || wantAlbum.contains(c))
                }
                guard let best, let small = best["artworkUrl100"] as? String,
                      let bigURL = URL(string: small.replacingOccurrences(of: "100x100bb", with: "600x600bb")),
                      let (imageData, _) = try? await URLSession.shared.data(from: bigURL),
                      let image = NSImage(data: imageData) else { continue }
                return image
            }
        }
        return nil
    }

    /// 음악 앱이 켜져 있을 때만 실행 (꺼져 있을 때 실행하면 음악 앱이 열려 버림)
    /// 컴파일한 스크립트를 보관해서 다시 쓰기 (매번 컴파일하면 느림)
    private var compiled: [String: NSAppleScript] = [:]

    /// cache: 늘 같은 스크립트만 보관 (곡 ID·음량처럼 값이 들어가는 건 보관하지 않음 → 메모리가 계속 늘지 않게)
    private func run(_ source: String, cache: Bool = true) -> NSAppleEventDescriptor? {
        guard isMusicRunning else { return nil }
        let script: NSAppleScript
        if let cached = compiled[source] {
            script = cached
        } else {
            guard let fresh = NSAppleScript(source: source) else { return nil }
            var compileError: NSDictionary?
            fresh.compileAndReturnError(&compileError)
            if cache { compiled[source] = fresh }
            script = fresh
        }
        var error: NSDictionary?
        let result = script.executeAndReturnError(&error)
        if let error {
            let code = error[NSAppleScript.errorNumber] as? Int ?? 0
            lastError = code == -1743
                ? "음악 앱 제어 권한이 없습니다 (시스템 설정 › 개인정보 보호 및 보안 › 자동화)"
                : (error[NSAppleScript.errorMessage] as? String ?? "AppleScript 오류 \(code)")
            return nil
        }
        lastError = nil
        return result
    }
}

// MARK: - 바탕화면 '지금 재생 중' 위젯

/// 배경화면 바로 위 층에 떠 있는 위젯: 앨범 커버 + 제목·아티스트·앨범 + 진행 바 + 재생 버튼 + 미니 스펙트럼
@MainActor
final class DesktopWidgetController: NSObject {
    /// 정사각형: 2×2 = macOS 소형 위젯과 같은 170pt / 크게 / 아주 크게
    // 화면에서 잰 macOS 위젯 크기: 소형 163pt, 소형 2개 + 간격 = 344pt
    static let sizes: [NSSize] = [NSSize(width: 163, height: 163),   // 2×2 (소형 위젯 1개)
                                  NSSize(width: 344, height: 344)]   // 4×4 (소형 위젯 2개 너비)
    static let cornerRadius: CGFloat = 20
    static let sizeTitles = ["2×2 (소형)", "4×4 (대형)"]

    let music = MusicBridge()
    private let settings = Settings.shared
    private let window: NSWindow
    private let container = WidgetContainerView()
    // 층 구조 (아래 → 위)
    //   glass        macOS 26+: 시스템 리퀴드 글라스(NSGlassEffectView) — 애플 위젯처럼 배경화면이 비침
    //     └ content  글라스의 콘텐츠
    //         coverBase  평상시: 색을 덜어 낸 반투명 커버 (유리판에 인쇄된 느낌)
    //         cover      마우스를 올리면: 선명한 컬러 커버
    //         shade      글자 쪽을 살짝 어둡게
    //         글자·진행 바·버튼·스펙트럼
    private let coverBase = CoverView()
    private let cover = CoverView()
    private let shade = GradientShadeView()
    private let glass: NSView = DesktopWidgetController.makeGlass()
    private let content = NSView()
    private var shownArtwork: NSImage?
    private var artworkMissingSince: TimeInterval?   // 새 곡 커버를 기다리기 시작한 시각
    static let coverFade: TimeInterval = 0.6
    private let rim = GlassRimView()              // 애플 위젯 같은 얇고 밝은 유리 테두리 (맨 위)
    private var hovering = false
    private let placeholder = NSImageView()         // 커버가 없을 때 음표
    private let titleLabel = NSTextField(labelWithString: "")
    private let artistLabel = NSTextField(labelWithString: "")
    private let albumLabel = NSTextField(labelWithString: "")
    private let elapsedLabel = NSTextField(labelWithString: "")
    // 가사 (커버 왼쪽 위): 지금 줄 + 다음 줄
    let lyrics = LyricsProvider()
    private let lyricLabel = NSTextField(wrappingLabelWithString: "")
    private let nextLyricLabel = NSTextField(labelWithString: "")
    private var shownLyric = ""
    // 제목 위 오른쪽: 다음 곡 3개 (위에서부터 1·2·3번째) + 나머지는 "…"
    private let upNextLabels = (0..<3).map { _ in NSTextField(labelWithString: "") }
    private let upNextMoreLabel = NSTextField(labelWithString: "")
    private var upNextCompact = false   // 2×2: "…"를 3번째 줄 끝에 붙임
    private var shownUpNext: UpNext?
    private var upNextFontSize: CGFloat = 10
    private let remainingLabel = NSTextField(labelWithString: "")
    private let progress = ProgressBarView()
    private let spectrumView = SpectrumView()
    private var previousButton: NSButton!
    private var playButton: NSButton!
    private var nextButton: NSButton!
    private var clock: Timer?
    private var moveObserver: NSObjectProtocol?
    private var applyingFrame = false
    private(set) var isShowing = false
    private var positioningUntil: TimeInterval = 0

    enum Corner: Int, CaseIterable {
        case topLeft, topRight, bottomLeft, bottomRight, center
        var title: String {
            switch self {
            case .topLeft: return "왼쪽 위"
            case .topRight: return "오른쪽 위"
            case .bottomLeft: return "왼쪽 아래"
            case .bottomRight: return "오른쪽 아래"
            case .center: return "화면 가운데"
            }
        }
    }

    override init() {
        window = NSWindow(contentRect: NSRect(origin: .zero, size: DesktopWidgetController.sizes[0]),
                          styleMask: [.borderless], backing: .buffered, defer: false)
        super.init()

        window.isOpaque = false
        window.backgroundColor = .clear
        window.hasShadow = false          // 애플 위젯처럼 창 그림자 없음 (테두리는 글라스가 그림)
        window.isReleasedWhenClosed = false
        // 바탕화면 아이콘 바로 위 (일반 창보다 항상 아래).
        // 바탕화면 레벨에 두면 Finder의 바탕화면 층이 클릭을 가로채서 끌 수가 없음
        window.level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.desktopIconWindow)) + 1)
        window.collectionBehavior = [.canJoinAllSpaces, .stationary, .ignoresCycle]
        window.appearance = NSAppearance(named: .darkAqua)
        window.alphaValue = 0

        container.wantsLayer = true
        let radius = DesktopWidgetController.cornerRadius
        coverBase.cornerRadius = radius
        cover.cornerRadius = radius
        shade.cornerRadius = radius

        placeholder.image = NSImage(systemSymbolName: "music.note", accessibilityDescription: nil)
        placeholder.imageScaling = .scaleProportionallyUpOrDown
        placeholder.contentTintColor = NSColor.white.withAlphaComponent(0.35)

        for label in [titleLabel, artistLabel, albumLabel, elapsedLabel, remainingLabel] {
            label.lineBreakMode = .byTruncatingTail
            label.maximumNumberOfLines = 1
            label.textColor = .white
            // 밝은 배경화면 위 글라스에서도 글자가 보이도록 옅은 그림자
            let shadow = NSShadow()
            shadow.shadowColor = NSColor.black.withAlphaComponent(0.25)
            shadow.shadowBlurRadius = 2
            shadow.shadowOffset = NSSize(width: 0, height: -0.5)
            label.shadow = shadow
        }
        remainingLabel.alignment = .right

        previousButton = makeButton("backward.fill", #selector(previousTapped))
        playButton = makeButton("play.fill", #selector(playTapped))
        nextButton = makeButton("forward.fill", #selector(nextTapped))

        container.addSubview(glass)
        rim.cornerRadius = radius
        for label in [lyricLabel, nextLyricLabel] {
            label.textColor = .white
            label.isSelectable = false
            label.drawsBackground = false
            label.isBordered = false
            let glow = NSShadow()
            glow.shadowColor = NSColor.black.withAlphaComponent(0.6)
            glow.shadowBlurRadius = 4
            glow.shadowOffset = NSSize(width: 0, height: -0.5)
            label.shadow = glow
        }
        for label in upNextLabels + [upNextMoreLabel] {
            label.alignment = .right
            label.lineBreakMode = .byTruncatingTail
            label.isSelectable = false
            label.drawsBackground = false
            label.isBordered = false
            let glow = NSShadow()
            glow.shadowColor = NSColor.black.withAlphaComponent(0.5)
            glow.shadowBlurRadius = 3
            glow.shadowOffset = NSSize(width: 0, height: -0.5)
            label.shadow = glow
        }
        lyricLabel.maximumNumberOfLines = 2
        lyricLabel.lineBreakMode = .byWordWrapping
        nextLyricLabel.lineBreakMode = .byTruncatingTail
        nextLyricLabel.textColor = NSColor.white.withAlphaComponent(0.55)
        lyrics.onChange = { [weak self] in self?.updateLyrics(force: true) }

        for view in [coverBase, cover, shade, placeholder, lyricLabel, nextLyricLabel, titleLabel, artistLabel, albumLabel, progress,
                     elapsedLabel, remainingLabel, spectrumView, previousButton!, playButton!, nextButton!] as [NSView] {
            content.addSubview(view)
        }
        for label in upNextLabels + [upNextMoreLabel] { content.addSubview(label) }
        installContent()
        container.addSubview(rim)
        window.contentView = container
        container.onClick = { [weak self] in self?.music.openMusicApp() }
        container.onCommandClick = { [weak self] in self?.toggleCommandDetailMode() }
        container.onRightClick = { [weak self] event in self?.showContextMenu(event) }
        container.onHover = { [weak self] inside in self?.setHovering(inside) }

        music.onChange = { [weak self] in self?.musicChanged() }

        // 지난번에 앱이 비정상 종료돼서 애플 위젯이 숨겨진 채 남았다면 되돌림
        SystemWidgets.restore()

        moveObserver = NotificationCenter.default.addObserver(
            forName: NSWindow.didMoveNotification, object: window, queue: .main) { [weak self] _ in
            MainActor.assumeIsolated { self?.savePosition() }
        }

        // 진행 바·시간·표시 여부를 0.1초마다 갱신
        let t = Timer(timeInterval: 0.1, target: self, selector: #selector(clockTick), userInfo: nil, repeats: true)
        t.tolerance = 0.02
        RunLoop.main.add(t, forMode: .common)
        clock = t

        applyAppearance()
        musicChanged()
    }

    // MARK: - 외부에서 호출

    /// 크기·배경·버튼·스펙트럼·위치 설정 반영
    func applyAppearance() {
        let sizeIndex = min(max(settings.widgetSize, 0), DesktopWidgetController.sizes.count - 1)
        let size = DesktopWidgetController.sizes[sizeIndex]
        applyingFrame = true
        window.setFrame(NSRect(origin: origin(for: size), size: size), display: true)
        applyingFrame = false
        container.frame = NSRect(origin: .zero, size: size)
        container.allowsDrag = !settings.widgetLocked
        // 투명 창은 기본값이면 macOS가 클릭을 뒤로 통과시켜 버림 → 명시적으로 클릭을 받게 함
        window.ignoresMouseEvents = false

        layout(size: size, sizeIndex: sizeIndex == 0 ? 0 : 2)   // 글자·버튼 크기 단계: 2×2 = 작게, 4×4 = 크게

        // 미니 스펙트럼: 메뉴바와 같은 모양·색상 설정, 막대 두께만 칸에 맞춤
        let n = max(1, settings.bandCount)
        let gap = CGFloat(settings.barGap)
        let usable = spectrumView.bounds.width - SpectrumView.hPadding * 2 - CGFloat(n - 1) * gap
        var look = SpectrumLook()
        look.shape = settings.barShape
        look.style = settings.barStyle
        look.colorMode = settings.colorMode
        look.barWidth = max(1, floor(usable / CGFloat(n)))
        look.barGap = gap
        look.verticalFade = settings.verticalFade
        look.levelColor = settings.levelColor
        look.peakCaps = settings.peakCaps
        spectrumView.look = look
        musicChanged()
        applyHover(animated: false)
        // 설정을 끄면 숨겨 둔 애플 위젯을 바로 되돌림
        if !settings.widgetHideOthers { SystemWidgets.restore() }
        else if isShowing && positioningUntil <= monotonicNow() { SystemWidgets.hide() }
    }

    /// 매 프레임: 미니 스펙트럼 막대 값
    func update(levels: [CGFloat], peaks: [CGFloat]) {
        // 안 보이는 미니 스펙트럼은 그리지 않음 (숨김·깔끔 모드·투명할 때)
        guard isShowing, settings.widgetSpectrum, !cleanMode, !spectrumView.isHidden,
              window.alphaValue > 0.01 else { return }
        spectrumView.update(levels: levels, peaks: peaks)
    }

    /// 앱 종료 시: 숨겨 둔 애플 위젯을 원래대로
    func teardown() {
        SystemWidgets.restore()
    }

    func resetPosition() {
        settings.widgetX = nil
        settings.widgetY = nil
        applyAppearance()
    }

    /// 화면 모서리/가운데로 옮기기 (주 화면 기준, 메뉴바·Dock 제외 영역에서 여백 24)
    func move(to corner: Corner) {
        let size = window.frame.size
        let v = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1440, height: 900)
        let m: CGFloat = 24
        let origin: NSPoint
        switch corner {
        case .topLeft: origin = NSPoint(x: v.minX + m, y: v.maxY - size.height - m)
        case .topRight: origin = NSPoint(x: v.maxX - size.width - m, y: v.maxY - size.height - m)
        case .bottomLeft: origin = NSPoint(x: v.minX + m, y: v.minY + m)
        case .bottomRight: origin = NSPoint(x: v.maxX - size.width - m, y: v.minY + m)
        case .center: origin = NSPoint(x: v.midX - size.width / 2, y: v.midY - size.height / 2)
        }
        settings.widgetX = Double(origin.x)
        settings.widgetY = Double(origin.y)
        showForPositioning()
        applyAppearance()
    }

    /// 기본 위치로 되돌리기
    func moveToDefault() {
        settings.widgetX = nil
        settings.widgetY = nil
        showForPositioning()
        applyAppearance()
    }

    /// 재생 중이 아니어도 15초간 보여 줘서 끌어서 위치를 맞출 수 있게
    func showForPositioning() {
        positioningUntil = monotonicNow() + 15
        refreshVisibility()
    }

    // MARK: - 배치

    /// 커버 전체 배경 배치
    ///  ╭───────────────╮
    ///  │░░░░░░░░░░░░░░░│  앨범 커버가 위젯 전체를 채움
    ///  │░░░░░ 커버 ░░░░│
    ///  │▁▃▅▇▅▃▂▁▃▅▇▅▃▁ │  미니 스펙트럼
    ///  │ 곡 제목        │  ← 아래쪽은 어둡게 깔아서 글자가 잘 보이게
    ///  │ 아티스트       │
    ///  │ ━━━━━━──────  │
    ///  │    ⏮  ⏯  ⏭    │
    ///  ╰───────────────╯
    private var lastLayout: (size: NSSize, sizeIndex: Int)?
    /// 깔끔 모드(평소): 가사 + 진행 바 + 재생 버튼만 — 제목·다음 곡·미니 스펙트럼은 마우스를 올렸을 때만
    /// (바탕화면에서도, 검색 창 옆에 붙었을 때도 같은 규칙)
    private(set) var cleanMode = true
    private var commandDetailMode = false

    func setCleanMode(_ on: Bool, animated: Bool, duration: TimeInterval = 0.36,
                      restyle: Bool = true) {
        guard on != cleanMode else { return }
        cleanMode = on
        if animated {
            content.wantsLayer = true
            let t = CATransition()
            t.type = .fade
            t.duration = duration
            t.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            content.layer?.add(t, forKey: "clean")
        }
        if let last = lastLayout { layout(size: last.size, sizeIndex: last.sizeIndex) }
        if restyle { applyHover(animated: false) }
        updateLyrics(force: true)
        updateUpNext(force: true)
    }

    private func layout(size: NSSize, sizeIndex: Int) {
        lastLayout = (size, sizeIndex)
        let side = size.width
        let height = size.height
        let pad: CGFloat = [12, 14, 16][sizeIndex]
        let titleSize: [CGFloat] = [13, 15, 17]
        let artistSize: [CGFloat] = [11.5, 12.5, 14]
        let row: CGFloat = [16, 18, 22][sizeIndex]

        coverBase.frame = container.bounds
        cover.frame = container.bounds
        glass.frame = container.bounds
        content.frame = glass.bounds
        rim.frame = container.bounds
        let ph = floor(side * 0.32)
        placeholder.frame = NSRect(x: (side - ph) / 2, y: height - pad - ph - height * 0.08, width: ph, height: ph)

        let width = side - pad * 2
        let x = pad

        // 맨 아래: 재생 버튼 (가운데 정렬)
        let controls = settings.widgetControls
        let buttonGap = row * 1.25
        let buttonsWidth = row * 3 + buttonGap * 2
        for (i, button) in [previousButton!, playButton!, nextButton!].enumerated() {
            let bx = floor((side - buttonsWidth) / 2 + CGFloat(i) * (row + buttonGap))
            button.frame = NSRect(x: bx, y: pad, width: row, height: row)
            button.isHidden = !controls
        }
        let bottom = controls ? pad + row : pad - 6

        // 시간 + 진행 바
        let showTimes = sizeIndex > 0
        let timeFont = NSFont.monospacedDigitSystemFont(ofSize: 9.5, weight: .medium)
        for label in [elapsedLabel, remainingLabel] {
            label.font = timeFont
            label.textColor = NSColor.white.withAlphaComponent(0.7)
            label.isHidden = !showTimes
        }
        elapsedLabel.frame = NSRect(x: x, y: bottom + 4, width: width / 2, height: 12)
        remainingLabel.frame = NSRect(x: x + width / 2, y: bottom + 4, width: width / 2, height: 12)
        let barY = showTimes ? bottom + 18 : bottom + 8
        progress.frame = NSRect(x: x, y: barY, width: width, height: 3)

        // 아티스트·제목 (크게일 때 앨범도)
        titleLabel.font = .systemFont(ofSize: titleSize[sizeIndex], weight: .bold)
        artistLabel.font = .systemFont(ofSize: artistSize[sizeIndex], weight: .medium)
        albumLabel.font = .systemFont(ofSize: artistSize[sizeIndex] - 1.5, weight: .regular)
        artistLabel.textColor = NSColor.white.withAlphaComponent(0.85)
        albumLabel.textColor = NSColor.white.withAlphaComponent(0.6)
        let titleH = ceil(titleSize[sizeIndex] * 1.3)
        let artistH = ceil(artistSize[sizeIndex] * 1.3)
        albumLabel.isHidden = sizeIndex < 2
        var y = barY + 8
        if sizeIndex >= 2 {
            albumLabel.frame = NSRect(x: x, y: y, width: width, height: artistH - 1)
            y += artistH - 1
        }
        artistLabel.frame = NSRect(x: x, y: y, width: width, height: artistH)
        y += artistH
        titleLabel.frame = NSRect(x: x, y: y, width: width, height: titleH)
        y += titleH

        // 다음 곡 3개: 제목 바로 위, 오른쪽 끝 정렬 (1번째가 맨 위)
        // 4×4: 그 아래 "…" 줄 따로 / 2×2: 자리가 좁아서 "…"를 3번째 줄 끝에 붙임
        upNextCompact = sizeIndex == 0
        upNextFontSize = upNextCompact ? 8.5 : 12
        let upNextH = ceil(upNextFontSize * 1.3)
        let showUpNext = settings.widgetUpNext
        for label in upNextLabels + [upNextMoreLabel] { label.isHidden = !showUpNext }
        upNextMoreLabel.isHidden = !showUpNext || upNextCompact
        if showUpNext {
            y += 1
            if !upNextCompact {
                upNextMoreLabel.frame = NSRect(x: x, y: y - 2, width: width, height: upNextH)
                y += upNextH - 4
            }
            for label in upNextLabels.reversed() {
                label.frame = NSRect(x: x, y: y, width: width, height: upNextH)
                y += upNextH
            }
        }
        updateUpNext(force: true)

        // 미니 스펙트럼: 그 위 한 줄 (2×2에서 다음 곡을 보이면 가사와 겹치므로 숨김)
        spectrumView.frame = NSRect(x: x - SpectrumView.hPadding, y: y + 2,
                                    width: width + SpectrumView.hPadding * 2, height: row + 8)
        spectrumView.isHidden = !settings.widgetSpectrum || (upNextCompact && showUpNext)

        // 글자 정렬 (가운데 / 왼쪽)
        let alignment: NSTextAlignment = settings.widgetCenterText ? .center : .left
        for label in [titleLabel, artistLabel, albumLabel] { label.alignment = alignment }

        // 어둡게 까는 영역: 글자 영역까지만 (스펙트럼 뒤로는 커버가 그대로 보이게)
        shade.frame = NSRect(x: 0, y: 0, width: side, height: min(height, y + height * 0.06))

        // 가사: 커버 왼쪽 위 (지금 줄은 최대 2줄, 다음 줄은 흐리게 1줄)
        let lyricSize: CGFloat = sizeIndex == 0 ? 11 : 15
        lyricLabel.font = .systemFont(ofSize: lyricSize, weight: .bold)
        nextLyricLabel.font = .systemFont(ofSize: lyricSize - 2, weight: .semibold)
        let lyricLineH = ceil(lyricSize * 1.3)
        lyricLabel.preferredMaxLayoutWidth = width
        lyricLabel.frame = NSRect(x: x, y: height - pad - lyricLineH * 2, width: width, height: lyricLineH * 2)
        let nextH = ceil((lyricSize - 2) * 1.3)
        nextLyricLabel.frame = NSRect(x: x, y: lyricLabel.frame.minY - nextH, width: width, height: nextH)
        let showLyrics = settings.widgetLyrics
        lyricLabel.isHidden = !showLyrics
        nextLyricLabel.isHidden = !showLyrics
        lyricLabel.alignment = .left
        nextLyricLabel.alignment = .left

        // 깔끔 모드: 글자는 가사만, 가사는 가운데에 크게
        let cleanHidden: [NSView] = [titleLabel, artistLabel, albumLabel, upNextMoreLabel] + upNextLabels
        for view in cleanHidden where cleanMode { view.isHidden = true }
        if cleanMode {
            spectrumView.isHidden = true
            lyricLabel.isHidden = false
            nextLyricLabel.isHidden = false
            let big: CGFloat = sizeIndex == 0 ? 14 : 22
            lyricLabel.font = .systemFont(ofSize: big, weight: .bold)
            nextLyricLabel.font = .systemFont(ofSize: big * 0.72, weight: .semibold)
            lyricLabel.alignment = .center
            nextLyricLabel.alignment = .center
            cleanLyricArea = NSRect(x: x, y: progress.frame.maxY + 10, width: width,
                                    height: max(0, height - pad - progress.frame.maxY - 10))
            cleanLineHeight = ceil(big * 1.3)
            cleanNextHeight = ceil(big * 0.72 * 1.3)
            lyricLabel.preferredMaxLayoutWidth = width
            positionCleanLyrics()
            shade.frame = NSRect(x: 0, y: 0, width: side, height: height)   // 전체를 고르게 어둡게 → 가사가 잘 보이게
        } else {
            for view in [titleLabel, artistLabel] as [NSView] { view.isHidden = false }
            albumLabel.isHidden = sizeIndex < 2
        }

        // 호버 중에는 가사를 숨기고 다음 곡 목록을 위젯 중앙에 모아 보여줌
        if hovering && !cleanMode {
            lyricLabel.isHidden = true
            nextLyricLabel.isHidden = true
            if settings.widgetUpNext {
                let visible = upNextLabels.filter { !$0.attributedStringValue.string.isEmpty }
                if !upNextMoreLabel.attributedStringValue.string.isEmpty { upNextMoreLabel.isHidden = false }
                let items = visible + (upNextMoreLabel.isHidden ? [] : [upNextMoreLabel])
                let itemHeight = upNextH
                let gap: CGFloat = 3
                let blockHeight = CGFloat(items.count) * itemHeight + CGFloat(max(0, items.count - 1)) * gap
                var itemY = max(barY + 8, (height - blockHeight) / 2)
                for item in items {
                    item.frame = NSRect(x: x, y: itemY, width: width, height: itemHeight)
                    item.alignment = .center
                    itemY += itemHeight + gap
                }
            }
        }
        if commandDetailMode {
            lyricLabel.isHidden = true
            nextLyricLabel.isHidden = true
            if !hovering {
                for label in upNextLabels + [upNextMoreLabel] { label.isHidden = true }
            }
        }
    }

    private var cleanLyricArea = NSRect.zero
    private var cleanLineHeight: CGFloat = 20
    private var cleanNextHeight: CGFloat = 15

    /// 깔끔 모드 가사: 지금 줄(1~2줄)과 다음 줄을 한 덩어리로 가운데에 (한 줄일 때 빈칸이 생기지 않게 실제 높이로)
    private func positionCleanLyrics() {
        guard cleanMode, cleanLyricArea.width > 0 else { return }
        let area = cleanLyricArea
        var currentH = cleanLineHeight
        if let cell = lyricLabel.cell, !lyricLabel.stringValue.isEmpty {
            currentH = min(cleanLineHeight * 2, max(cleanLineHeight,
                ceil(cell.cellSize(forBounds: NSRect(x: 0, y: 0, width: area.width, height: 1000)).height)))
        }
        let hasNext = !nextLyricLabel.stringValue.isEmpty
        let blockH = currentH + (hasNext ? 6 + cleanNextHeight : 0)
        let y0 = area.minY + max(0, (area.height - blockH) / 2)
        nextLyricLabel.frame = NSRect(x: area.minX, y: y0, width: area.width, height: cleanNextHeight)
        lyricLabel.frame = NSRect(x: area.minX, y: y0 + (hasNext ? cleanNextHeight + 6 : 0), width: area.width, height: currentH)
    }

    /// 개발용: 마우스를 올린 것처럼 (화면 확인용)
    func devSetHover(_ inside: Bool) { setHovering(inside) }

    private func makeButton(_ symbol: String, _ action: Selector) -> NSButton {
        let image = NSImage(systemSymbolName: symbol, accessibilityDescription: nil) ?? NSImage()
        let button = NSButton(image: image, target: self, action: action)
        button.isBordered = false
        button.imageScaling = .scaleProportionallyUpOrDown
        button.contentTintColor = .white
        return button
    }

    // MARK: - 곡 정보 반영

    private func musicChanged() {
        if let track = music.track {
            titleLabel.stringValue = track.title.isEmpty ? "제목 없음" : track.title
            artistLabel.stringValue = track.artist
            albumLabel.stringValue = track.album
        } else {
            titleLabel.stringValue = "재생 중인 곡 없음"
            artistLabel.stringValue = music.lastError ?? "Apple Music에서 곡을 재생하세요"
            albumLabel.stringValue = ""
        }

        syncArtwork()

        lyrics.load(for: settings.widgetLyrics ? music.track : nil)
        updateUpNext()

        let symbol = music.isPlaying ? "pause.fill" : "play.fill"
        playButton.image = NSImage(systemSymbolName: symbol, accessibilityDescription: nil)

        updateProgress()
        refreshVisibility()
    }

    /// 제목 위 오른쪽 '다음 ▸ 곡 제목 · 아티스트'
    private func updateUpNext(force: Bool = false) {
        let value = music.track == nil ? nil : music.upNext
        guard force || value != shownUpNext else { return }
        shownUpNext = value
        let caption = NSFont.systemFont(ofSize: upNextFontSize - 1, weight: .semibold)
        let body = NSFont.systemFont(ofSize: upNextFontSize, weight: .semibold)
        let paragraph = NSMutableParagraphStyle()
        paragraph.alignment = hovering ? .center : .right
        paragraph.lineBreakMode = .byTruncatingTail
        func line(_ parts: [(String, NSFont, CGFloat)]) -> NSAttributedString {
            let text = NSMutableAttributedString()
            for (s, font, alpha) in parts {
                text.append(NSAttributedString(string: s, attributes: [
                    .font: font, .foregroundColor: NSColor.white.withAlphaComponent(alpha),
                    .paragraphStyle: paragraph]))
            }
            return text
        }

        var lines: [NSAttributedString] = []
        var more = false
        switch value {
        case .tracks(let titles, let total)?:
            more = total > titles.count
            for (i, title) in titles.prefix(3).enumerated() {
                var parts: [(String, NSFont, CGFloat)] = []
                if i == 0 { parts.append(("다음  ", caption, 0.5)) }
                parts.append((title.isEmpty ? "제목 없음" : title, body, i == 0 ? 0.95 : 0.75))
                if i == 2, more, upNextCompact { parts.append(("  …", body, 0.6)) }
                lines.append(line(parts))
            }
        case .shuffle?:
            lines.append(line([("다음  ", caption, 0.5), ("셔플 재생 중", body, 0.7)]))
        case nil:
            break
        }
        // 위에서부터 채움 (곡이 적으면 아래 줄이 비고, 제목에 붙는 쪽이 비지 않도록 아래로 당김)
        let offset = upNextLabels.count - lines.count
        for (i, label) in upNextLabels.enumerated() {
            let index = i - offset
            label.attributedStringValue = index >= 0 && index < lines.count ? lines[index] : NSAttributedString()
        }
        upNextMoreLabel.attributedStringValue = more && !upNextCompact
            ? line([("…", body, 0.6)]) : NSAttributedString()
        // 바뀔 때 부드럽게 (처음 배치할 땐 바로)
        if !force {
            for label in upNextLabels + [upNextMoreLabel] {
                label.wantsLayer = true
                let t = CATransition()
                t.type = .fade
                t.duration = 0.35
                label.layer?.add(t, forKey: "upNext")
            }
        }
    }

    /// 커버 바꾸기: 이전 커버 → 새 커버 크로스페이드.
    /// 곡이 바뀌어 새 커버를 받는 동안(보통 0.3초 안팎)은 이전 커버를 유지해서 빈 화면이 번쩍이지 않게 함.
    private func syncArtwork() {
        let artwork = music.artwork
        guard artwork !== shownArtwork else {
            artworkMissingSince = nil
            return
        }
        if artwork == nil, shownArtwork != nil, music.track != nil {
            let now = monotonicNow()
            if artworkMissingSince == nil { artworkMissingSince = now }
            if now - (artworkMissingSince ?? now) < 3 { return }   // 3초까지 기다려 봄
        }
        artworkMissingSince = nil
        let fade = isShowing ? Self.coverFade : 0
        shownArtwork = artwork
        cover.setImage(artwork, fade: fade)
        coverBase.setImage(artwork.flatMap { DesktopWidgetController.softened($0) }, fade: fade)
        if fade > 0 { shade.layer?.add(CoverView.crossfade(fade), forKey: "shadeFade") }
        if let artwork {
            // 글자 뒤 그라데이션은 앨범 색보다 검정에 가깝게 두어 밝은 커버에서도 자연스럽게 읽히게 함
            shade.baseColor = (averageColor(of: artwork) ?? .black).blended(withFraction: 0.82, of: .black) ?? .black
        } else {
            shade.baseColor = .black
        }
        if fade > 0 {
            NSAnimationContext.runAnimationGroup { context in
                context.duration = fade
                placeholder.animator().alphaValue = artwork == nil ? 1 : 0
            }
        } else {
            placeholder.alphaValue = artwork == nil ? 1 : 0
        }
        placeholder.isHidden = false
        applyHover(animated: fade > 0)
    }

    @objc private func clockTick() {
        syncArtwork()
        // 위젯이 안 보일 땐 진행 바·가사는 건너뜀
        if isShowing {
            updateProgress()
            updateLyrics(force: false)
        }
        refreshVisibility()
    }

    /// 재생 위치에 맞춰 가사 줄 바꾸기 (바뀔 때 살짝 페이드)
    private func updateLyrics(force: Bool) {
        guard settings.widgetLyrics, music.track != nil,
              let pair = lyrics.lines(at: music.currentPosition) else {
            // 가사가 없을 때: 깔끔 모드면 빈 커버 대신 제목·가수를 가운데에
            let fallback = cleanMode ? (music.track.map { $0.title.isEmpty ? "제목 없음" : $0.title } ?? "") : ""
            let key = "\u{1}" + fallback
            if shownLyric != key || force {
                shownLyric = key
                lyricLabel.stringValue = fallback
                nextLyricLabel.stringValue = cleanMode ? (music.track?.artist ?? "") : ""
                positionCleanLyrics()
            }
            return
        }
        guard force || pair.current != shownLyric else { return }
        shownLyric = pair.current
        lyricLabel.stringValue = pair.current.isEmpty ? "♪" : pair.current
        nextLyricLabel.stringValue = pair.next
        positionCleanLyrics()
        lyricLabel.alphaValue = 0.2
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.25
            lyricLabel.animator().alphaValue = 1
        }
    }

    private func updateProgress() {
        guard let track = music.track, track.duration > 0 else {
            progress.value = 0
            elapsedLabel.stringValue = ""
            remainingLabel.stringValue = ""
            return
        }
        let position = music.currentPosition
        progress.value = CGFloat(position / track.duration)
        // 글자는 바뀔 때만 (같은 값을 넣어도 다시 그려지므로)
        let elapsed = Self.format(position)
        if elapsedLabel.stringValue != elapsed { elapsedLabel.stringValue = elapsed }
        let remaining = "-" + Self.format(track.duration - position)
        if remainingLabel.stringValue != remaining { remainingLabel.stringValue = remaining }
    }

    private static func format(_ seconds: Double) -> String {
        let s = max(0, Int(seconds.rounded()))
        return String(format: "%d:%02d", s / 60, s % 60)
    }

    /// 앨범 아트의 평균 색 → 위젯 배경 색조
    private func averageColor(of image: NSImage) -> NSColor? {
        guard let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return nil }
        var pixel = [UInt8](repeating: 0, count: 4)
        let drawn: Bool = pixel.withUnsafeMutableBytes { buffer in
            guard let ctx = CGContext(data: buffer.baseAddress, width: 1, height: 1, bitsPerComponent: 8,
                                      bytesPerRow: 4, space: CGColorSpaceCreateDeviceRGB(),
                                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return false }
            ctx.interpolationQuality = .medium
            ctx.draw(cg, in: CGRect(x: 0, y: 0, width: 1, height: 1))
            return true
        }
        guard drawn else { return nil }
        return NSColor(srgbRed: CGFloat(pixel[0]) / 255, green: CGFloat(pixel[1]) / 255,
                       blue: CGFloat(pixel[2]) / 255, alpha: 1)
    }

    // MARK: - 리퀴드 글라스 ↔ 컬러 커버 (마우스 호버)

    private static func makeGlass() -> NSView {
        #if compiler(>=6.2)
        if #available(macOS 26.0, *) {
            let glass = NSGlassEffectView()
            glass.cornerRadius = DesktopWidgetController.cornerRadius
            glass.style = .regular
            return glass
        }
        #endif
        let blur = NSVisualEffectView()
        blur.material = .hudWindow
        blur.blendingMode = .behindWindow
        blur.state = .active
        blur.wantsLayer = true
        blur.layer?.cornerRadius = DesktopWidgetController.cornerRadius
        blur.layer?.masksToBounds = true
        return blur
    }

    /// 글자·버튼을 글라스의 콘텐츠로 넣는다 (macOS 26+). 이전 버전은 블러 위에 얹기만 함
    private func installContent() {
        content.autoresizingMask = [.width, .height]
        #if compiler(>=6.2)
        if #available(macOS 26.0, *), let liquid = glass as? NSGlassEffectView {
            liquid.contentView = content
            return
        }
        #endif
        container.addSubview(content)
    }

    /// 평상시 = 기본(Regular) 글라스, 마우스를 올려 컬러를 볼 때 = 맑은(Clear) 글라스
    private func setGlassClear(_ clear: Bool) {
        #if compiler(>=6.2)
        if #available(macOS 26.0, *), let liquid = glass as? NSGlassEffectView {
            liquid.style = clear ? .clear : .regular
            return
        }
        #endif
    }

    private static let ciContext = CIContext()

    /// 평상시 커버: 흐리게 하지 않고 색만 조금 빼서, 글라스 너머로 차분하게 보이도록
    static func softened(_ image: NSImage) -> NSImage? {
        guard let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return nil }
        let source = CIImage(cgImage: cg)
        let output = source.applyingFilter("CIColorControls", parameters: [kCIInputSaturationKey: 0.52,
                                                                           kCIInputBrightnessKey: 0.0,
                                                                           kCIInputContrastKey: 1.0])
        guard let result = ciContext.createCGImage(output, from: source.extent) else { return nil }
        return NSImage(cgImage: result, size: image.size)
    }

    /// 마우스를 올리면: 컬러 커버 + 세부 정보(제목·다음 곡·미니 스펙트럼) / 떼면: 글라스 + 가사만
    private func setHovering(_ inside: Bool) {
        guard inside != hovering else { return }
        hovering = inside
        setCleanMode(!(inside || commandDetailMode), animated: true, duration: 0.3, restyle: false)
        if let lastLayout { layout(size: lastLayout.size, sizeIndex: lastLayout.sizeIndex) }
        applyHover(animated: true)
    }

    private func toggleCommandDetailMode() {
        commandDetailMode.toggle()
        setCleanMode(!(hovering || commandDetailMode), animated: true, restyle: false)
        applyHover(animated: true)
    }

    /// 평상시: 글라스 위에 반투명 커버 (배경화면 색이 비쳐 유리 느낌) / 마우스를 올리면: 선명한 컬러 커버
    private func applyHover(animated: Bool) {
        let hasArt = shownArtwork != nil
        let showColor = (hovering || commandDetailMode) && hasArt
        // '기본 글라스' 설정을 끄면 맑은(Clear) 글라스
        setGlassClear(!settings.widgetBackground)
        #if compiler(>=6.2)
        if #available(macOS 26.0, *), let liquid = glass as? NSGlassEffectView {
            liquid.style = commandDetailMode ? .clear : (settings.widgetBackground ? .regular : .clear)
            if commandDetailMode {
                liquid.contentView = nil
                if content.superview !== container { container.addSubview(content) }
                liquid.removeFromSuperview()
            } else {
                if liquid.superview !== container {
                    container.addSubview(liquid, positioned: .below, relativeTo: content)
                }
                liquid.contentView = content
            }
        } else if let blur = glass as? NSVisualEffectView {
            if commandDetailMode {
                blur.removeFromSuperview()
            } else if blur.superview !== container {
                container.addSubview(blur, positioned: .below, relativeTo: content)
            }
        }
        #else
        if let blur = glass as? NSVisualEffectView {
            if commandDetailMode {
                blur.removeFromSuperview()
            } else if blur.superview !== container {
                container.addSubview(blur, positioned: .below, relativeTo: content)
            }
        }
        #endif

        let colorAlpha: CGFloat = showColor ? 1 : 0
        // 평소 색(색을 덜어 낸 커버)은 늘 깔아 둠
        let baseAlpha: CGFloat = hasArt ? Self.glassCoverAlpha : 0
        // 깔끔 모드(평소)엔 가사가 잘 보이게 조금 더 어둡게
        let shadeAlpha: CGFloat = hasArt ? (showColor ? 0.62 : (cleanMode ? 0.50 : 0.35)) : 0
        if animated {
            NSAnimationContext.runAnimationGroup { context in
                context.duration = 0.35
                cover.animator().alphaValue = colorAlpha
                coverBase.animator().alphaValue = baseAlpha
                shade.animator().alphaValue = shadeAlpha
            }
        } else {
            cover.alphaValue = colorAlpha
            coverBase.alphaValue = baseAlpha
            shade.alphaValue = shadeAlpha
        }
    }

    /// 평상시 커버 진하기 (낮을수록 유리·배경화면이 더 비침)
    static let glassCoverAlpha: CGFloat = 0.65

    // MARK: - 표시 / 숨김

    private func refreshVisibility() {
        let recentlyPlaying = monotonicNow() - music.lastPlaying < 3
        let hasTrack = music.track != nil
        let wanted = settings.widgetEnabled
            && (isAttached && hasTrack
                || positioningUntil > monotonicNow()       // '위치 맞추기' 중엔 잠깐 보임
                || (hasTrack && (settings.widgetShowMode == 1 || music.isPlaying || recentlyPlaying)))
        setShowing(wanted)
    }

    private func setShowing(_ wanted: Bool) {
        guard wanted != isShowing else { return }
        isShowing = wanted
        if wanted {
            // 애플 바탕화면 위젯을 먼저 사라지게 하고 (위치 맞추기 중엔 그대로),
            // 그 애니메이션이 끝난 뒤에 우리 위젯이 나타나게 함
            var delay: TimeInterval = 0
            if settings.widgetHideOthers && positioningUntil <= monotonicNow() && SystemWidgets.hide() {
                delay = SystemWidgets.hideAnimationTime
            }
            fadeIn(after: delay)
        } else {
            NSAnimationContext.runAnimationGroup({ context in
                context.duration = 0.5
                window.animator().alphaValue = 0
            }, completionHandler: { [weak self] in
                MainActor.assumeIsolated {
                    guard let self, !self.isShowing else { return }
                    self.window.orderOut(nil)
                    // 우리 위젯이 다 사라진 뒤 애플 위젯을 원래대로
                    SystemWidgets.restore()
                }
            })
        }
    }

    private func fadeIn(after delay: TimeInterval) {
        guard delay > 0 else {
            window.orderFrontRegardless()
            NSAnimationContext.runAnimationGroup { context in
                context.duration = 0.35
                window.animator().alphaValue = 1
            }
            return
        }
        Timer.scheduledTimer(withTimeInterval: delay, repeats: false) { [weak self] _ in
            MainActor.assumeIsolated {
                guard let self, self.isShowing else { return }   // 그사이 다시 숨겨졌으면 취소
                self.fadeIn(after: 0)
            }
        }
    }

    // MARK: - 검색 창 옆에 붙기 (⌘ 두 번)

    private(set) var isAttached = false
    private var savedFrameBeforeAttach: NSRect?

    /// 붙을 수 있으면 위젯 너비 (안 붙으면 0)
    var attachableWidth: CGFloat {
        settings.widgetEnabled && music.track != nil ? window.frame.width : 0
    }

    /// 검색 창 왼쪽에 위쪽을 맞춰 붙을 자리
    func attachTarget(leftOf rect: NSRect, gap: CGFloat) -> NSRect? {
        guard attachableWidth > 0 else { return nil }
        let size = window.frame.size
        return NSRect(x: rect.minX - gap - size.width, y: rect.maxY - size.height, width: size.width, height: size.height)
    }

    /// 붙기 시작: 지금 자리를 기억하고 다른 창 위로 올림. (출발 자리, 숨어 있었는지) 를 돌려줌
    /// 실제 움직임은 검색 창이 한꺼번에 프레임마다 그려 줌 (모두 같은 순간에 도착하도록)
    func beginAttach() -> (from: NSRect, wasHidden: Bool) {
        let wasHidden = !isShowing || window.alphaValue < 0.05 || !window.isVisible
        if !isAttached { savedFrameBeforeAttach = window.frame }
        isAttached = true
        applyingFrame = true
        isShowing = true                 // 숨김 판정이 끼어들지 않게 (페이드는 검색 창이 직접)
        window.level = .floating
        setCleanMode(!hovering, animated: !wasHidden)
        window.orderFrontRegardless()
        return (window.frame, wasHidden)
    }

    /// 프레임마다: 위치·투명도 바로 지정
    func setAttachState(frame: NSRect, alpha: CGFloat) {
        window.setFrame(frame, display: false)
        window.alphaValue = alpha
    }

    var currentFrame: NSRect? { window.frame }

    /// 돌아갈 자리
    var detachTarget: NSRect {
        savedFrameBeforeAttach ?? NSRect(origin: origin(for: window.frame.size), size: window.frame.size)
    }

    /// 돌아가기 끝: 바탕화면 층으로 내리고 평소 표시 규칙으로
    func finishDetach() {
        guard isAttached else { return }
        isAttached = false
        setCleanMode(!hovering, animated: false)
        window.setFrame(detachTarget, display: true)
        savedFrameBeforeAttach = nil
        window.level = NSWindow.Level(rawValue: Int(CGWindowLevelForKey(.desktopIconWindow)) + 1)
        applyingFrame = false
        if window.alphaValue < 0.05 { isShowing = false }   // 사라진 채 돌아왔으면 평소 규칙대로 다시 판단
        refreshVisibility()
    }

    // MARK: - 위치

    private func origin(for size: NSSize) -> NSPoint {
        if let x = settings.widgetX, let y = settings.widgetY {
            let rect = NSRect(x: x, y: y, width: size.width, height: size.height)
            if NSScreen.screens.contains(where: { $0.frame.intersects(rect) }) {
                return rect.origin
            }
        }
        return DesktopWidgetController.defaultOrigin(for: size)
    }

    /// 기본 위치: 사용자가 정해 둔 자리 = 주 화면 왼쪽에서 16pt, 위에서 51pt (위젯 왼쪽 위 모서리 기준)
    static func defaultOrigin(for size: NSSize) -> NSPoint {
        let frame = NSScreen.screens.first?.frame ?? NSRect(x: 0, y: 0, width: 1728, height: 1117)
        return NSPoint(x: frame.minX + 16, y: frame.maxY - 51 - size.height)
    }

    private func savePosition() {
        guard !applyingFrame, !isAttached else { return }
        settings.widgetX = Double(window.frame.minX)
        settings.widgetY = Double(window.frame.minY)
    }

    // MARK: - 버튼·오른쪽 클릭

    @objc private func previousTapped() { music.previousTrack() }
    @objc private func playTapped() { music.playPause() }
    @objc private func nextTapped() { music.nextTrack() }

    private func showContextMenu(_ event: NSEvent) {
        let menu = NSMenu()
        for corner in Corner.allCases {
            let item = NSMenuItem(title: corner.title, action: #selector(moveTapped(_:)), keyEquivalent: "")
            item.target = self
            item.tag = corner.rawValue
            menu.addItem(item)
        }
        menu.addItem(.separator())
        let lock = NSMenuItem(title: "위치 고정 (끌어서 옮기기 막기)", action: #selector(toggleLock), keyEquivalent: "")
        lock.target = self
        lock.state = settings.widgetLocked ? .on : .off
        menu.addItem(lock)
        menu.addItem(.separator())
        for (i, title) in DesktopWidgetController.sizeTitles.enumerated() {
            let item = NSMenuItem(title: title, action: #selector(setSize(_:)), keyEquivalent: "")
            item.target = self
            item.tag = i
            item.state = settings.widgetSize == i ? .on : .off
            menu.addItem(item)
        }
        NSMenu.popUpContextMenu(menu, with: event, for: container)
    }

    @objc private func moveTapped(_ sender: NSMenuItem) {
        if let corner = Corner(rawValue: sender.tag) { move(to: corner) }
    }

    @objc private func toggleLock() {
        settings.widgetLocked.toggle()
        applyAppearance()
    }

    @objc private func setSize(_ sender: NSMenuItem) {
        settings.widgetSize = sender.tag
        applyAppearance()
    }
}

/// 위젯 전체 클릭 처리: 버튼은 그대로 누르고, 나머지는 끌기(위치 고정 해제 시) 또는 음악 앱 열기
final class WidgetContainerView: NSView {
    var allowsDrag = false
    var onClick: (@MainActor () -> Void)?
    var onCommandClick: (@MainActor () -> Void)?
    var onRightClick: (@MainActor (NSEvent) -> Void)?
    var onHover: (@MainActor (Bool) -> Void)?
    private var trackingArea: NSTrackingArea?

    // 마우스가 위젯 위에 있는지 감지
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let trackingArea { removeTrackingArea(trackingArea) }
        let area = NSTrackingArea(rect: .zero,
                                  options: [.mouseEnteredAndExited, .activeAlways, .inVisibleRect],
                                  owner: self, userInfo: nil)
        addTrackingArea(area)
        trackingArea = area
    }

    override func mouseEntered(with event: NSEvent) { onHover?(true) }
    override func mouseExited(with event: NSEvent) { onHover?(false) }

    override func hitTest(_ point: NSPoint) -> NSView? {
        guard let hit = super.hitTest(point) else { return nil }
        return hit is NSButton ? hit : self
    }

    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    private var dragStartMouse: NSPoint?
    private var dragStartOrigin: NSPoint?

    // 끌기를 직접 처리 (창 시스템의 끌기에 의존하지 않음)
    override func mouseDown(with event: NSEvent) {
        if event.modifierFlags.contains(.command) {
            onCommandClick?()
            return
        }
        if event.clickCount == 2 {
            onClick?()
            return
        }
        guard allowsDrag, let window else { return }
        dragStartMouse = NSEvent.mouseLocation
        dragStartOrigin = window.frame.origin
    }

    override func mouseDragged(with event: NSEvent) {
        guard allowsDrag, let window, let startMouse = dragStartMouse, let startOrigin = dragStartOrigin else { return }
        let now = NSEvent.mouseLocation
        window.setFrameOrigin(NSPoint(x: startOrigin.x + now.x - startMouse.x,
                                      y: startOrigin.y + now.y - startMouse.y))
    }

    override func mouseUp(with event: NSEvent) {
        dragStartMouse = nil
        dragStartOrigin = nil
    }

    override func rightMouseDown(with event: NSEvent) {
        onRightClick?(event)
    }
}

/// 얇은 재생 진행 바
final class ProgressBarView: NSView {
    var value: CGFloat = 0 {
        // 마지막으로 그린 자리에서 반 픽셀 이상 움직였을 때만 다시 그림
        didSet {
            if abs(value - drawnValue) * max(bounds.width, 1) >= 0.5 || (value == 0) != (drawnValue == 0) {
                needsDisplay = true
            }
        }
    }
    private var drawnValue: CGFloat = -1

    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func draw(_ dirtyRect: NSRect) {
        let r = bounds.height / 2
        NSColor.white.withAlphaComponent(0.22).setFill()
        NSBezierPath(roundedRect: bounds, xRadius: r, yRadius: r).fill()
        drawnValue = value
        let filled = NSRect(x: 0, y: 0, width: bounds.width * min(1, max(0, value)), height: bounds.height)
        guard filled.width > 0 else { return }
        NSColor.white.withAlphaComponent(0.9).setFill()
        NSBezierPath(roundedRect: filled, xRadius: min(r, filled.width / 2), yRadius: r).fill()
    }
}

/// 앨범 커버를 비율 유지한 채 꽉 채워 그리는 뷰 (넘치는 부분은 잘림)
final class CoverView: NSView {
    var cornerRadius: CGFloat = 0 {
        didSet { layer?.cornerRadius = cornerRadius }
    }

    var image: NSImage? {
        didSet {
            layer?.contents = image?.cgImage(forProposedRect: nil, context: nil, hints: nil)
        }
    }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer?.contentsGravity = .resizeAspectFill
        layer?.masksToBounds = true
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    /// 이전 커버에서 새 커버로 겹쳐지며 자연스럽게 바뀜 (크로스페이드)
    func setImage(_ newImage: NSImage?, fade duration: TimeInterval) {
        if duration > 0, let layer {
            layer.add(Self.crossfade(duration), forKey: "coverFade")
        }
        image = newImage
    }

    static func crossfade(_ duration: TimeInterval) -> CATransition {
        let t = CATransition()
        t.type = .fade
        t.duration = duration
        t.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        return t
    }
}

/// 아래에서 위로 점점 투명해지는 그늘 (글자 가독성용)
final class GradientShadeView: NSView {
    var baseColor: NSColor = .black { didSet { needsDisplay = true } }
    var cornerRadius: CGFloat = 0 { didSet { needsDisplay = true } }

    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func draw(_ dirtyRect: NSRect) {
        let gradient = NSGradient(colors: [baseColor.withAlphaComponent(0.85),
                                           baseColor.withAlphaComponent(0.55),
                                           baseColor.withAlphaComponent(0)],
                                  atLocations: [0, 0.55, 1],
                                  colorSpace: .sRGB)
        // 위젯 아래쪽 모서리 곡률에 맞춰 자름
        let clip = NSBezierPath(roundedRect: NSRect(x: 0, y: 0, width: bounds.width,
                                                    height: bounds.height + cornerRadius),
                                xRadius: cornerRadius, yRadius: cornerRadius)
        clip.addClip()
        gradient?.draw(in: bounds, angle: 90)
    }
}

/// 애플 위젯 가장자리의 얇고 밝은 유리 테두리 (위·아래가 조금 더 밝음)
final class GlassRimView: NSView {
    var cornerRadius: CGFloat = 20 { didSet { needsDisplay = true } }

    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func draw(_ dirtyRect: NSRect) {
        guard let ctx = NSGraphicsContext.current?.cgContext else { return }
        let rect = bounds.insetBy(dx: 0.5, dy: 0.5)
        let r = max(0, min(cornerRadius - 0.5, rect.width / 2, rect.height / 2))
        ctx.addPath(CGPath(roundedRect: rect, cornerWidth: r, cornerHeight: r, transform: nil))
        ctx.setLineWidth(1)
        ctx.replacePathWithStrokedPath()
        ctx.clip()
        let colors = [NSColor(srgbRed: 0.85, green: 0.92, blue: 1, alpha: 0.55).cgColor,
                      NSColor(srgbRed: 0.85, green: 0.92, blue: 1, alpha: 0.25).cgColor,
                      NSColor(srgbRed: 0.85, green: 0.92, blue: 1, alpha: 0.5).cgColor]
        let locations: [CGFloat] = [0, 0.5, 1]
        guard let gradient = CGGradient(colorsSpace: CGColorSpace(name: CGColorSpace.sRGB),
                                        colors: colors as CFArray, locations: locations) else { return }
        ctx.drawLinearGradient(gradient, start: CGPoint(x: bounds.midX, y: bounds.minY),
                               end: CGPoint(x: bounds.midX, y: bounds.maxY), options: [])
    }
}

/// 애플 바탕화면 위젯 숨기기/되돌리기.
/// 시스템 설정 '바탕화면 및 Dock › 위젯 보기'와 같은 값(com.apple.WindowManager)을 바꾸면
/// macOS가 위젯을 직접 사라지게/나타나게 한다. 원래 값은 저장해 두었다가 그대로 되돌린다.
@MainActor
enum SystemWidgets {
    private static let domain = "com.apple.WindowManager" as CFString
    /// 일반 바탕화면 / 스테이지 매니저 사용 중
    private static let keys = ["StandardHideWidgets", "StageManagerHideWidgets"]
    /// 우리가 숨기기 전의 원래 값 (앱 설정에 보관 → 비정상 종료 후에도 복구 가능)
    private static let savedKey = "savedSystemWidgetHide"

    static var hiddenByUs: Bool {
        UserDefaults.standard.dictionary(forKey: savedKey) != nil
    }

    /// macOS가 위젯을 사라지게 하는 데 걸리는 시간 (이만큼 기다렸다가 우리 위젯을 보여 줌)
    static let hideAnimationTime: TimeInterval = 0.6

    /// 숨김을 새로 걸었으면 true (이미 숨겨 둔 상태면 false)
    @discardableResult
    static func hide() -> Bool {
        guard !hiddenByUs else { return false }
        var saved: [String: Int] = [:]
        for key in keys {
            let current = (CFPreferencesCopyAppValue(key as CFString, domain) as? NSNumber)?.intValue ?? 0
            saved[key] = current
            CFPreferencesSetAppValue(key as CFString, NSNumber(value: 1), domain)
        }
        CFPreferencesAppSynchronize(domain)
        UserDefaults.standard.set(saved, forKey: savedKey)
        // 원래부터 위젯을 숨겨 두었으면 사라지는 애니메이션이 없으니 기다릴 필요 없음
        return saved["StandardHideWidgets"] == 0
    }

    static func restore() {
        guard let saved = UserDefaults.standard.dictionary(forKey: savedKey) else { return }
        for (key, value) in saved {
            let number = (value as? NSNumber) ?? NSNumber(value: 0)
            CFPreferencesSetAppValue(key as CFString, number, domain)
        }
        CFPreferencesAppSynchronize(domain)
        UserDefaults.standard.removeObject(forKey: savedKey)
    }
}
