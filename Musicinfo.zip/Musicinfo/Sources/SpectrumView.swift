import Cocoa

/// 스펙트럼 디자인 설정 묶음
struct SpectrumLook: Equatable {
    var shape: BarShape = .pill
    var style: BarStyle = .bottom
    var colorMode: ColorMode = .mono
    var barWidth: CGFloat = 2
    var barGap: CGFloat = 1
    var verticalFade = true
    var levelColor = false
    var peakCaps = true
}

/// 메뉴바 버튼 위에 그려지는 스펙트럼 (막대 / 알약 / LED 블록 / 곡선 웨이브)
final class SpectrumView: NSView {
    var look = SpectrumLook() {
        didSet {
            guard look != oldValue else { return }
            if look.colorMode != oldValue.colorMode { resolvedMono = nil }
            refresh()
        }
    }
    private(set) var levels: [CGFloat] = []
    private(set) var peaks: [CGFloat] = []

    // 막대·알약 모양은 CALayer로: 매 프레임 CPU로 다시 그리지 않고 위치·크기만 바꿔 GPU가 합성
    // (LED·웨이브는 기존처럼 직접 그림)
    private let barsContainer = CALayer()
    private let fadeMask = CAGradientLayer()
    private var barLayers: [CALayer] = []
    private var capLayers: [CALayer] = []
    private var lowerCapLayers: [CALayer] = []     // 가운데 대칭일 때 아래쪽 피크 캡
    private var resolvedMono: CGColor?
    private var usesLayers: Bool { look.shape == .rounded || look.shape == .pill }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layerContentsRedrawPolicy = .onSetNeedsDisplay
        barsContainer.anchorPoint = .zero
        layer?.addSublayer(barsContainer)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    static let hPadding: CGFloat = 4

    /// 막대 개수·두께·간격으로 메뉴바 아이템 너비 계산
    static func width(bands: Int, barWidth: Int, gap: Int) -> CGFloat {
        CGFloat(bands * barWidth + max(bands - 1, 0) * gap) + hPadding * 2
    }

    func update(levels: [CGFloat], peaks: [CGFloat]) {
        self.levels = levels
        self.peaks = peaks
        refresh()
    }

    private func refresh() {
        if usesLayers {
            updateLayers()
        } else {
            if !barLayers.isEmpty { removeBarLayers() }
            needsDisplay = true
        }
    }

    override func setFrameSize(_ newSize: NSSize) {
        super.setFrameSize(newSize)
        if usesLayers { updateLayers() }
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        resolvedMono = nil              // 라이트/다크가 바뀌면 기본 색(글자색)을 다시 구함
        refresh()
    }

    /// 막대가 그려질 영역 (그리기·레이어 공통)
    private func barArea(n: Int) -> CGRect? {
        guard n > 0 else { return nil }
        let contentWidth = CGFloat(n) * look.barWidth + CGFloat(n - 1) * look.barGap
        let x0 = floor((bounds.width - contentWidth) / 2)
        let vInset = max(3, floor(bounds.height * 0.17))
        let area = CGRect(x: x0, y: vInset, width: contentWidth, height: bounds.height - vInset * 2)
        return area.height > 0 && area.width > 0 ? area : nil
    }

    private func removeBarLayers() {
        (barLayers + capLayers + lowerCapLayers).forEach { $0.removeFromSuperlayer() }
        barLayers = []
        capLayers = []
        lowerCapLayers = []
    }

    /// 단색(기본) 계열의 바탕색: 메뉴바 라이트/다크에 맞춘 글자색을 한 번만 구해 둠
    private var monoBase: CGColor {
        if let resolvedMono { return resolvedMono }
        var color = NSColor.white.cgColor
        effectiveAppearance.performAsCurrentDrawingAppearance {
            color = self.themeColor(0).withAlphaComponent(1).cgColor
        }
        resolvedMono = color
        return color
    }

    private func updateLayers() {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        defer { CATransaction.commit() }

        let n = levels.count
        if barsContainer.superlayer !== layer, let layer { layer.addSublayer(barsContainer) }
        barsContainer.frame = bounds
        while barLayers.count < n {
            let bar = CALayer(), cap = CALayer(), lowerCap = CALayer()
            [bar, cap, lowerCap].forEach { barsContainer.addSublayer($0) }
            barLayers.append(bar)
            capLayers.append(cap)
            lowerCapLayers.append(lowerCap)
        }
        while barLayers.count > n {
            barLayers.removeLast().removeFromSuperlayer()
            capLayers.removeLast().removeFromSuperlayer()
            lowerCapLayers.removeLast().removeFromSuperlayer()
        }
        guard let area = barArea(n: n) else {
            (barLayers + capLayers + lowerCapLayers).forEach { $0.isHidden = true }
            return
        }

        // 세로 그라데이션(끝으로 갈수록 투명): 막대 전체에 마스크 하나
        if look.verticalFade, bounds.height > 0 {
            fadeMask.frame = barsContainer.bounds
            let lo = area.minY / bounds.height, hi = area.maxY / bounds.height
            let full = NSColor.black.cgColor, faded = NSColor.black.withAlphaComponent(0.3).cgColor
            fadeMask.startPoint = CGPoint(x: 0.5, y: lo)
            fadeMask.endPoint = CGPoint(x: 0.5, y: hi)
            if look.style == .mirror {
                fadeMask.colors = [faded, full, faded]
                fadeMask.locations = [0, 0.5, 1]
            } else {
                fadeMask.colors = [full, faded]
                fadeMask.locations = [0, 1]
            }
            if barsContainer.mask !== fadeMask { barsContainer.mask = fadeMask }
        } else if barsContainer.mask != nil {
            barsContainer.mask = nil
        }

        let mono = look.colorMode == .mono || look.colorMode == .white
        let base = mono ? monoBase : nil
        let bw = look.barWidth, gap = look.barGap
        let minHeight: CGFloat = look.shape == .pill ? min(bw, area.height) : 1.5
        let wanted: CGFloat = look.shape == .pill ? bw / 2 : 1.5
        for i in 0..<n {
            let level = clamp(levels[i])
            let x = area.minX + CGFloat(i) * (bw + gap)
            let h = max(minHeight, (area.height * level).rounded())
            let y = look.style == .bottom ? area.minY : floor(area.midY - h / 2)
            let bar = barLayers[i]
            bar.isHidden = false
            bar.frame = CGRect(x: x, y: y, width: bw, height: h)
            bar.cornerRadius = max(0, min(wanted, bw / 2, h / 2))
            let color: CGColor
            let opacity: Float
            if let base {
                color = base
                opacity = Float(look.levelColor ? 0.45 + 0.55 * level : 0.92)
            } else {
                color = barColor(i, n, level: level).cgColor
                opacity = 1
            }
            bar.backgroundColor = color
            bar.opacity = opacity

            // 피크 캡 (아래서 위로: 위에 하나 / 가운데 대칭: 위아래 둘)
            let cap = capLayers[i], lowerCap = lowerCapLayers[i]
            let peak = peaks.count == n ? clamp(peaks[i]) : 0
            guard look.peakCaps, peak > 0.03 else {
                cap.isHidden = true
                lowerCap.isHidden = true
                continue
            }
            let capH: CGFloat = look.shape == .pill ? min(bw, 2) : 1.5
            let capR = max(0, min(capH / 2, bw / 2))
            if look.style == .bottom {
                cap.frame = CGRect(x: x, y: min(area.maxY - capH, area.minY + area.height * peak + 1), width: bw, height: capH)
                lowerCap.isHidden = true
            } else {
                let offset = area.height * peak / 2 + 1
                cap.frame = CGRect(x: x, y: min(area.maxY - capH, area.midY + offset), width: bw, height: capH)
                lowerCap.frame = CGRect(x: x, y: max(area.minY, area.midY - offset - capH), width: bw, height: capH)
                lowerCap.isHidden = false
            }
            for c in [cap, lowerCap] {
                c.cornerRadius = capR
                c.backgroundColor = color
                c.opacity = opacity
            }
            cap.isHidden = false
        }
    }


    // 클릭은 아래의 상태바 버튼이 받도록 통과시킴 (메뉴 열기)
    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func draw(_ dirtyRect: NSRect) {
        guard !usesLayers, let ctx = NSGraphicsContext.current?.cgContext, !levels.isEmpty else { return }
        let n = levels.count
        let contentWidth = CGFloat(n) * look.barWidth + CGFloat(n - 1) * look.barGap
        let x0 = floor((bounds.width - contentWidth) / 2)
        let vInset = max(3, floor(bounds.height * 0.17))
        let area = CGRect(x: x0, y: vInset, width: contentWidth, height: bounds.height - vInset * 2)
        guard area.height > 0, area.width > 0 else { return }

        switch look.shape {
        case .wave: drawWave(ctx, area: area, n: n)
        case .led: drawLED(ctx, area: area, n: n)
        case .rounded, .pill: drawBars(ctx, area: area, n: n)
        }
    }

    // MARK: - 막대 / 알약

    private func drawBars(_ ctx: CGContext, area: CGRect, n: Int) {
        let bw = look.barWidth
        let gap = look.barGap
        // 단색 계열(기본·흰색): 색과 세로 그라데이션을 한 번만 만들고, 막대마다 투명도만 바꿔 그림
        // → 막대 수 × 초당 프레임만큼 하던 색·그라데이션 생성을 프레임당 한 번으로
        let mono = look.colorMode == .mono || look.colorMode == .white
        let monoBase: CGColor? = mono ? themeColor(0).withAlphaComponent(1).cgColor : nil
        let monoGradient: CGGradient? = (monoBase != nil && look.verticalFade) ? fadeGradient(monoBase!) : nil
        let minHeight: CGFloat = look.shape == .pill ? min(bw, area.height) : 1.5
        let wanted: CGFloat = look.shape == .pill ? bw / 2 : 1.5
        for i in 0..<n {
            let level = clamp(levels[i])
            let x = area.minX + CGFloat(i) * (bw + gap)
            let h = max(minHeight, (area.height * level).rounded())
            let y = look.style == .bottom ? area.minY : floor(area.midY - h / 2)
            let rect = CGRect(x: x, y: y, width: bw, height: h)
            let r = max(0, min(wanted, bw / 2, h / 2))
            let path = CGPath(roundedRect: rect, cornerWidth: r, cornerHeight: r, transform: nil)
            let color: CGColor
            if let monoBase {
                let alpha: CGFloat = look.levelColor ? 0.45 + 0.55 * level : 0.92
                color = monoBase.copy(alpha: alpha) ?? monoBase
                if let monoGradient {
                    ctx.saveGState()
                    ctx.addPath(path)
                    ctx.clip()
                    ctx.setAlpha(alpha)
                    ctx.drawLinearGradient(monoGradient,
                                           start: CGPoint(x: area.midX, y: area.minY),
                                           end: CGPoint(x: area.midX, y: area.maxY),
                                           options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
                    ctx.restoreGState()
                } else {
                    ctx.setFillColor(color)
                    ctx.addPath(path)
                    ctx.fillPath()
                }
            } else {
                color = barColor(i, n, level: level).cgColor
                fill(ctx, path: path, color: color, fadeRect: area)
            }

            if look.peakCaps && peaks.count == n {
                drawCaps(ctx, x: x, area: area, peak: clamp(peaks[i]), level: level, color: color)
            }
        }
    }

    /// 아래(또는 가운데)는 진하고 끝으로 갈수록 투명해지는 세로 그라데이션
    private func fadeGradient(_ color: CGColor) -> CGGradient? {
        let faded = color.copy(alpha: color.alpha * 0.3) ?? color
        let colors: [CGColor] = look.style == .mirror ? [faded, color, faded] : [color, faded]
        let locations: [CGFloat] = look.style == .mirror ? [0, 0.5, 1] : [0, 1]
        return CGGradient(colorsSpace: Self.sRGB, colors: colors as CFArray, locations: locations)
    }

    private static let sRGB = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()

    private func drawCaps(_ ctx: CGContext, x: CGFloat, area: CGRect, peak: CGFloat, level: CGFloat, color: CGColor) {
        guard peak > 0.03 else { return }
        let bw = look.barWidth
        let capH: CGFloat = look.shape == .pill ? min(bw, 2) : 1.5
        let r = max(0, min(capH / 2, bw / 2))
        ctx.setFillColor(color)
        if look.style == .bottom {
            let y = min(area.maxY - capH, area.minY + area.height * peak + 1)
            ctx.addPath(CGPath(roundedRect: CGRect(x: x, y: y, width: bw, height: capH),
                               cornerWidth: r, cornerHeight: r, transform: nil))
        } else {
            let offset = area.height * peak / 2 + 1
            let top = min(area.maxY - capH, area.midY + offset)
            let bottom = max(area.minY, area.midY - offset - capH)
            ctx.addPath(CGPath(roundedRect: CGRect(x: x, y: top, width: bw, height: capH),
                               cornerWidth: r, cornerHeight: r, transform: nil))
            ctx.addPath(CGPath(roundedRect: CGRect(x: x, y: bottom, width: bw, height: capH),
                               cornerWidth: r, cornerHeight: r, transform: nil))
        }
        ctx.fillPath()
    }

    // MARK: - LED 블록

    private func drawLED(_ ctx: CGContext, area: CGRect, n: Int) {
        let bw = look.barWidth
        let gap = look.barGap
        let blockH: CGFloat = 2
        let blockGap: CGFloat = 1
        let step = blockH + blockGap
        let r = max(0, min(0.5, bw / 2))

        for i in 0..<n {
            let level = clamp(levels[i])
            let peak = (look.peakCaps && peaks.count == n) ? clamp(peaks[i]) : -1
            let x = area.minX + CGFloat(i) * (bw + gap)
            let base = barColor(i, n, level: level).cgColor

            // 블록 하나 그리기 (pos: 0 = 바닥/가운데, 1 = 끝)
            func block(y: CGFloat, on: Bool, isPeak: Bool, pos: CGFloat) {
                let alpha: CGFloat = (on || isPeak) ? (look.verticalFade ? 1 - 0.6 * pos : 1) : 0.12
                ctx.setFillColor(base.copy(alpha: base.alpha * alpha) ?? base)
                ctx.addPath(CGPath(roundedRect: CGRect(x: x, y: y, width: bw, height: blockH),
                                   cornerWidth: r, cornerHeight: r, transform: nil))
                ctx.fillPath()
            }

            if look.style == .bottom {
                let count = max(1, Int((area.height + blockGap) / step))
                let lit = max(1, Int((level * CGFloat(count)).rounded()))
                let peakIndex = peak >= 0 ? min(count - 1, Int(peak * CGFloat(count))) : -1
                for k in 0..<count {
                    let pos = CGFloat(k) / CGFloat(max(count - 1, 1))
                    block(y: area.minY + CGFloat(k) * step, on: k < lit,
                          isPeak: k == peakIndex && k >= lit, pos: pos)
                }
            } else {
                // 가운데 대칭: 가운데 블록에서 위아래로 쌓기
                let half = max(1, Int((area.height / 2 + blockH / 2) / step))
                let lit = max(1, Int((level * CGFloat(half)).rounded()))
                let peakIndex = peak >= 0 ? min(half - 1, Int(peak * CGFloat(half))) : -1
                let centerY = floor(area.midY - blockH / 2)
                for k in 0..<half {
                    let pos = CGFloat(k) / CGFloat(max(half - 1, 1))
                    let on = k < lit
                    let isPeak = k == peakIndex && k >= lit
                    block(y: centerY + CGFloat(k) * step, on: on, isPeak: isPeak, pos: pos)
                    if k > 0 { block(y: centerY - CGFloat(k) * step, on: on, isPeak: isPeak, pos: pos) }
                }
            }
        }
    }

    // MARK: - 곡선 웨이브

    private func drawWave(_ ctx: CGContext, area: CGRect, n: Int) {
        let bw = look.barWidth
        let gap = look.barGap
        let mirror = look.style == .mirror
        let baseY = mirror ? area.midY : area.minY
        let amplitude = mirror ? area.height / 2 : area.height

        func curvePoints(_ values: [CGFloat], sign: CGFloat) -> [CGPoint] {
            (0..<n).map { i in
                CGPoint(x: area.minX + CGFloat(i) * (bw + gap) + bw / 2,
                        y: baseY + sign * max(0.75, clamp(values[i]) * amplitude))
            }
        }
        let top = curvePoints(levels, sign: 1)
        let bottom = mirror ? curvePoints(levels, sign: -1) : []

        // 채움 영역
        let shape = CGMutablePath()
        shape.move(to: CGPoint(x: area.minX, y: baseY))
        shape.addLine(to: top[0])
        addSmoothCurve(shape, top)
        shape.addLine(to: CGPoint(x: area.maxX, y: baseY))
        if mirror {
            shape.addLine(to: bottom[n - 1])
            addSmoothCurve(shape, Array(bottom.reversed()))
        }
        shape.closeSubpath()

        // 윤곽선
        let line = CGMutablePath()
        line.move(to: top[0])
        addSmoothCurve(line, top)
        if mirror {
            line.move(to: bottom[0])
            addSmoothCurve(line, bottom)
        }

        let average = levels.reduce(0, +) / CGFloat(n)
        let stops = (0..<5).map { s -> CGColor in
            let i = Int((CGFloat(s) / 4 * CGFloat(n - 1)).rounded())
            return barColor(i, n, level: average).cgColor
        }

        ctx.saveGState()
        ctx.clip(to: area.insetBy(dx: -1, dy: -1))

        // 채움: 가로 색 그라데이션, 반투명
        ctx.saveGState()
        ctx.addPath(shape)
        ctx.clip()
        ctx.setAlpha(look.verticalFade ? 0.28 : 0.45)
        drawHorizontalGradient(ctx, colors: stops, area: area)
        ctx.restoreGState()

        // 선: 같은 그라데이션으로 진하게
        ctx.saveGState()
        ctx.addPath(line)
        ctx.setLineWidth(1.3)
        ctx.setLineJoin(.round)
        ctx.setLineCap(.round)
        ctx.replacePathWithStrokedPath()
        ctx.clip()
        drawHorizontalGradient(ctx, colors: stops, area: area.insetBy(dx: -2, dy: -2))
        ctx.restoreGState()

        // 피크: 작은 점
        if look.peakCaps && peaks.count == n {
            for i in 0..<n {
                let p = clamp(peaks[i])
                guard p > clamp(levels[i]) + 0.04 else { continue }
                ctx.setFillColor(barColor(i, n, level: p).cgColor)
                let x = top[i].x
                let d: CGFloat = 1.6
                ctx.fillEllipse(in: CGRect(x: x - d / 2, y: baseY + p * amplitude, width: d, height: d))
                if mirror {
                    ctx.fillEllipse(in: CGRect(x: x - d / 2, y: baseY - p * amplitude - d, width: d, height: d))
                }
            }
        }
        ctx.restoreGState()
    }

    /// Catmull-Rom 스플라인으로 점들을 부드럽게 잇는다 (현재 위치가 points[0]이어야 함)
    private func addSmoothCurve(_ path: CGMutablePath, _ points: [CGPoint]) {
        guard points.count > 1 else { return }
        for i in 0..<(points.count - 1) {
            let p0 = points[max(i - 1, 0)]
            let p1 = points[i]
            let p2 = points[i + 1]
            let p3 = points[min(i + 2, points.count - 1)]
            let c1 = CGPoint(x: p1.x + (p2.x - p0.x) / 6, y: p1.y + (p2.y - p0.y) / 6)
            let c2 = CGPoint(x: p2.x - (p3.x - p1.x) / 6, y: p2.y - (p3.y - p1.y) / 6)
            path.addCurve(to: p2, control1: c1, control2: c2)
        }
    }

    private func drawHorizontalGradient(_ ctx: CGContext, colors: [CGColor], area: CGRect) {
        let locations: [CGFloat] = (0..<colors.count).map { CGFloat($0) / CGFloat(max(colors.count - 1, 1)) }
        guard let gradient = CGGradient(colorsSpace: Self.sRGB, colors: colors as CFArray, locations: locations) else { return }
        ctx.drawLinearGradient(gradient,
                               start: CGPoint(x: area.minX, y: area.midY),
                               end: CGPoint(x: area.maxX, y: area.midY),
                               options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
    }

    // MARK: - 칠하기·색상

    /// 세로 그라데이션 옵션에 따라 단색 또는 끝으로 갈수록 투명하게 칠하기
    private func fill(_ ctx: CGContext, path: CGPath, color: CGColor, fadeRect: CGRect) {
        guard look.verticalFade else {
            ctx.setFillColor(color)
            ctx.addPath(path)
            ctx.fillPath()
            return
        }
        guard let gradient = fadeGradient(color) else { return }
        ctx.saveGState()
        ctx.addPath(path)
        ctx.clip()
        ctx.drawLinearGradient(gradient,
                               start: CGPoint(x: fadeRect.midX, y: fadeRect.minY),
                               end: CGPoint(x: fadeRect.midX, y: fadeRect.maxY),
                               options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
        ctx.restoreGState()
    }

    private func barColor(_ i: Int, _ n: Int, level: CGFloat) -> NSColor {
        let t = CGFloat(i) / CGFloat(max(n - 1, 1))
        let base = themeColor(t)
        switch look.colorMode {
        case .mono, .white:
            // 단색 계열: 소리 크기 반응이면 밝기(투명도)로 표현
            return base.withAlphaComponent(look.levelColor ? 0.45 + 0.55 * level : 0.92)
        default:
            guard look.levelColor else { return base }
            return base.blended(withFraction: level * 0.45, of: .white) ?? base
        }
    }

    private func themeColor(_ t: CGFloat) -> NSColor {
        switch look.colorMode {
        case .mono:
            return .labelColor                       // 메뉴바 라이트/다크 자동
        case .white:
            return .white
        case .gradient:
            return NSColor(calibratedHue: 0.62 - 0.62 * t, saturation: 0.75, brightness: 1, alpha: 1)
        case .neon:
            return Self.mix([Self.rgb(0.0, 0.95, 1.0), Self.rgb(0.55, 0.4, 1.0), Self.rgb(1.0, 0.2, 0.85)], t)
        case .sunset:
            return Self.mix([Self.rgb(1.0, 0.85, 0.3), Self.rgb(1.0, 0.45, 0.35), Self.rgb(0.85, 0.25, 0.6)], t)
        case .ocean:
            return Self.mix([Self.rgb(0.3, 0.95, 0.85), Self.rgb(0.2, 0.6, 1.0), Self.rgb(0.4, 0.35, 0.95)], t)
        }
    }

    private static func rgb(_ r: CGFloat, _ g: CGFloat, _ b: CGFloat) -> NSColor {
        NSColor(srgbRed: r, green: g, blue: b, alpha: 1)
    }

    private static func mix(_ stops: [NSColor], _ t: CGFloat) -> NSColor {
        let x = min(1, max(0, t)) * CGFloat(stops.count - 1)
        let i = min(Int(x), stops.count - 2)
        return stops[i].blended(withFraction: x - CGFloat(i), of: stops[i + 1]) ?? stops[i]
    }

    private func clamp(_ v: CGFloat) -> CGFloat { min(1, max(0, v)) }
}
