import Foundation
import Accelerate

/// Accelerate(vDSP) FFT로 샘플을 로그 간격 주파수 밴드 레벨(0~1)로 변환한다.
/// 오디오(io) 큐에서만 사용할 것.
final class SpectrumAnalyzer {
    static let fftSize = 2048

    var bandCount: Int
    var gain: Float

    private let half: Int
    private let log2n: vDSP_Length
    private let setup: FFTSetup
    private let window: [Float]
    private var ring: [Float] = []

    // 표시 범위
    private let minDB: Float = -75
    private let maxDB: Float = -15
    private let minFreq: Float = 40
    private let maxFreq: Float = 16_000

    init(bandCount: Int, gain: Float) {
        let n = SpectrumAnalyzer.fftSize
        let log2n = vDSP_Length(log2(Double(n)))
        var w = [Float](repeating: 0, count: n)
        vDSP_hann_window(&w, vDSP_Length(n), Int32(vDSP_HANN_NORM))

        self.bandCount = bandCount
        self.gain = gain
        self.half = n / 2
        self.log2n = log2n
        self.setup = vDSP_create_fftsetup(log2n, FFTRadix(kFFTRadix2))!
        self.window = w
        ring.reserveCapacity(n * 2)
    }

    deinit { vDSP_destroy_fftsetup(setup) }

    /// 샘플을 받아 밴드 레벨을 돌려준다. 샘플이 아직 FFT 크기만큼 모이지 않았으면 nil
    func process(_ samples: [Float], sampleRate: Double) -> [Float]? {
        let n = SpectrumAnalyzer.fftSize
        let half = self.half
        let log2n = self.log2n
        let setup = self.setup
        ring.append(contentsOf: samples)
        if ring.count < n { return nil }
        if ring.count > n { ring.removeFirst(ring.count - n) }

        // 1) 해닝 윈도우
        var windowed = [Float](repeating: 0, count: n)
        vDSP_vmul(ring, 1, window, 1, &windowed, 1, vDSP_Length(n))

        // 2) 실수 FFT → 크기(magnitude)
        var real = [Float](repeating: 0, count: half)
        var imag = [Float](repeating: 0, count: half)
        var mags = [Float](repeating: 0, count: half)
        real.withUnsafeMutableBufferPointer { rp in
            imag.withUnsafeMutableBufferPointer { ip in
                var split = DSPSplitComplex(realp: rp.baseAddress!, imagp: ip.baseAddress!)
                windowed.withUnsafeBufferPointer { wp in
                    wp.baseAddress!.withMemoryRebound(to: DSPComplex.self, capacity: half) { cp in
                        vDSP_ctoz(cp, 2, &split, 1, vDSP_Length(half))
                    }
                }
                vDSP_fft_zrip(setup, &split, 1, log2n, FFTDirection(FFT_FORWARD))
                vDSP_zvabs(&split, 1, &mags, 1, vDSP_Length(half))
            }
        }

        // 3) 로그 스케일 밴드로 묶기
        let sr = Float(sampleRate > 0 ? sampleRate : 48_000)
        let binHz = sr / Float(n)
        let fMax = min(maxFreq, sr / 2)
        let ratio = fMax / minFreq
        let bands = max(1, bandCount)
        var out = [Float](repeating: 0, count: bands)

        for b in 0..<bands {
            let f0 = minFreq * pow(ratio, Float(b) / Float(bands))
            let f1 = minFreq * pow(ratio, Float(b + 1) / Float(bands))
            var lo = Int(f0 / binHz)
            var hi = Int(f1 / binHz)
            lo = max(1, min(lo, half - 1))
            hi = min(half, max(lo + 1, hi))

            var peak: Float = 0
            for k in lo..<hi where mags[k] > peak { peak = mags[k] }

            let amp = peak / Float(n)
            var db = 20 * log10(amp + 1e-9)
            // 고음역은 에너지가 작으므로 옥타브당 +3dB 보정 (1kHz 기준)
            let center = (f0 * f1).squareRoot()
            db += 3 * log2(center / 1000)
            db += gain

            let level = (db - minDB) / (maxDB - minDB)
            out[b] = min(1, max(0, level))
        }
        return out
    }
}
