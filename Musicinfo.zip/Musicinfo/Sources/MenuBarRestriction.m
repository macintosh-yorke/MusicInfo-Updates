//  MenuBarRestriction.m
//  SpectrumBar

#import "MenuBarRestriction.h"
#import <dlfcn.h>

// 비공개 클래스가 가진 메서드 선언 (실제 구현은 런타임에 MenuBarClientCore가 제공)
@interface NSObject (SBMenuBarClientCore)
- (instancetype)initWithAllowedSystemItems:(NSArray *)systemItems
                  allowedBundleIdentifiers:(NSArray *)bundleIdentifiers;
- (void)activateWithConfiguration:(id)configuration
                completionHandler:(void (^)(NSError * _Nullable error))handler;
- (void)invalidate;
@end

static NSString *const SBFrameworkPath =
    @"/System/Library/PrivateFrameworks/MenuBarClientCore.framework/MenuBarClientCore";
static NSString *const SBConfigurationClass = @"MBAssessmentModeConfiguration";
static NSString *const SBAssertionClass = @"MBAssessmentModeAssertion";

static NSError *SBError(NSString *message) {
    return [NSError errorWithDomain:@"SpectrumBar.MenuBarRestriction"
                               code:1
                           userInfo:@{NSLocalizedDescriptionKey: message}];
}

BOOL SBMenuBarRestrictionIsAvailable(void) {
    static BOOL available = NO;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        if (!dlopen(SBFrameworkPath.fileSystemRepresentation, RTLD_NOW | RTLD_LOCAL)) {
            return;
        }
        Class configuration = NSClassFromString(SBConfigurationClass);
        Class assertion = NSClassFromString(SBAssertionClass);
        available = configuration != Nil && assertion != Nil
            && [configuration instancesRespondToSelector:@selector(initWithAllowedSystemItems:allowedBundleIdentifiers:)]
            && [assertion instancesRespondToSelector:@selector(activateWithConfiguration:completionHandler:)]
            && [assertion instancesRespondToSelector:@selector(invalidate)];
    });
    return available;
}

void SBMenuBarRestrictionActivate(NSArray<NSNumber *> *allowedSystemItems,
                                  NSArray<NSString *> *allowedBundleIDs,
                                  void (^completion)(id _Nullable restriction, NSError * _Nullable error)) {
    void (^finish)(id, NSError *) = ^(id restriction, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            completion(restriction, error);
        });
    };

    if (!SBMenuBarRestrictionIsAvailable()) {
        finish(nil, SBError(@"MenuBarClientCore를 사용할 수 없습니다."));
        return;
    }

    @try {
        // 비공개 API가 배열 인덱스로 접근하므로 반드시 NSArray로 넘긴다
        id configuration = [[NSClassFromString(SBConfigurationClass) alloc]
                            initWithAllowedSystemItems:[allowedSystemItems copy]
                            allowedBundleIdentifiers:[allowedBundleIDs copy]];
        id assertion = [[NSClassFromString(SBAssertionClass) alloc] init];
        if (configuration == nil || assertion == nil) {
            finish(nil, SBError(@"메뉴바 제한 객체를 만들지 못했습니다."));
            return;
        }
        [assertion activateWithConfiguration:configuration completionHandler:^(NSError * _Nullable error) {
            finish(error ? nil : assertion, error);
        }];
    } @catch (NSException *exception) {
        finish(nil, SBError([NSString stringWithFormat:@"%@: %@", exception.name, exception.reason]));
    }
}

void SBMenuBarRestrictionInvalidate(id restriction) {
    @try {
        if ([restriction respondsToSelector:@selector(invalidate)]) {
            [restriction invalidate];
        }
    } @catch (NSException *exception) {
        NSLog(@"SpectrumBar: 메뉴바 제한 해제 중 예외 %@: %@", exception.name, exception.reason);
    }
}
