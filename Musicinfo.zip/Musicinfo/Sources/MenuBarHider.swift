import Cocoa

// MARK: - 상태 막대 아이템 위치 저장값

/// macOS는 autosaveName별 메뉴바 위치를 앱 설정의 "NSStatusItem Preferred Position <이름>" 키에 저장한다.
/// isVisible=false로 아이템을 빼면 이 값이 지워지므로, 보관했다가 되돌려 놓는다. (Ice, Hidden Bar와 같은 방식)
enum StatusItemPosition {
    private static func key(_ name: String) -> String { "NSStatusItem Preferred Position \(name)" }

    static func preferred(_ name: String) -> Double? {
        (UserDefaults.standard.object(forKey: key(name)) as? NSNumber)?.doubleValue
    }

    static func setPreferred(_ name: String, _ value: Double) {
        UserDefaults.standard.set(value, forKey: key(name))
    }

    /// 저장된 위치가 없을 때만 기본 위치 지정 (0 = 맨 오른쪽, 1 = 그 바로 왼쪽)
    static func setDefault(_ name: String, _ value: Double) {
        if preferred(name) == nil { setPreferred(name, value) }
    }

    /// 아이템을 메뉴바에 넣거나 빼면서 위치 저장값을 유지
    @MainActor
    static func setVisible(_ item: NSStatusItem, _ visible: Bool) {
        guard item.isVisible != visible else { return }
        let name: String = item.autosaveName ?? ""
        let cached = preferred(name)
        item.isVisible = visible
        if let cached { setPreferred(name, cached) }
    }
}

// MARK: - 다른 아이콘 숨기기 엔진

/// macOS 26 이하와 27 이상은 숨기는 방법이 완전히 달라서 두 가지 구현을 둔다.
@MainActor
protocol MenuBarHider: AnyObject {
    /// 메뉴에 보여 줄 문제 설명 (정상이면 nil)
    var problem: String? { get }
    /// 애니메이션이나 요청이 진행 중이면 true (빠른 갱신 필요)
    var isBusy: Bool { get }
    /// 매 프레임 호출
    /// - wantHidden: 지금 다른 아이콘을 숨겨야 하는지
    /// - needed: 숨기기 기능이 쓰이는 상황인지 (재생 중 + 설정 켜짐, 또는 배치 모드)
    /// - arrange: 아이콘 배치 모드 (구분선을 보여 주고 숨기지 않음)
    func update(wantHidden: Bool, needed: Bool, arrange: Bool, animate: Bool, spectrum: NSStatusItem)
    func resetPositions()
    func teardown()
}

// MARK: macOS 26 이하: 구분선 아이템 길이를 늘려 왼쪽 아이콘을 화면 밖으로 밀어내기

@MainActor
final class LengthHider: MenuBarHider {
    static let autosaveName = "SpectrumBarDivider"

    private let divider: NSStatusItem
    private let lineView = DividerLineView()
    private(set) var problem: String?
    private(set) var isBusy = false
    private var invalidSince: TimeInterval?
    private var fixAttempts = 0
    private let arrangeLength: CGFloat = 16

    init() {
        StatusItemPosition.setDefault(LengthHider.autosaveName, 1)    // 스펙트럼(0) 바로 왼쪽
        let item = NSStatusBar.system.statusItem(withLength: 0)
        item.autosaveName = LengthHider.autosaveName
        divider = item
        if let button = item.button {
            lineView.frame = button.bounds
            lineView.autoresizingMask = [.width, .height]
            button.addSubview(lineView)
        }
        StatusItemPosition.setVisible(item, false)
    }

    func update(wantHidden: Bool, needed: Bool, arrange: Bool, animate: Bool, spectrum: NSStatusItem) {
        lineView.showsLine = arrange

        // 쓰지 않을 때: (애니메이션으로 펼친 뒤) 구분선을 메뉴바에서 빼서 빈틈이 남지 않게 한다
        guard needed else {
            if divider.isVisible {
                if animate && divider.length > 0.5 {
                    isBusy = step(toward: 0, spectrum: spectrum)
                    if isBusy { return }
                }
                setLength(0)
                StatusItemPosition.setVisible(divider, false)
            }
            isBusy = false
            invalidSince = nil
            return
        }

        if !divider.isVisible {
            setLength(0)
            StatusItemPosition.setVisible(divider, true)
        }

        // 배치 모드: 점선 구분선만 보여 주고 숨기지 않음
        if arrange {
            setLength(arrangeLength)
            isBusy = false
            return
        }

        var target: CGFloat = 0
        if wantHidden {
            switch order(spectrum) {
            case .valid:
                target = collapseLength
                invalidSince = nil
                problem = nil
            case .unknown:
                // 위치를 아직 모르면(메뉴바 배치 직후) 지금 상태를 유지
                target = divider.length > arrangeLength ? collapseLength : 0
            case .invalid:
                let now = monotonicNow()
                if invalidSince == nil { invalidSince = now }
                if let since = invalidSince, now - since > 1.5 { autoFix(spectrum) }
                target = 0
            }
        }

        if animate {
            isBusy = step(toward: target, spectrum: spectrum)
        } else {
            setLength(target)
            isBusy = false
        }
    }

    func resetPositions() {
        setLength(0)
        StatusItemPosition.setVisible(divider, false)
        StatusItemPosition.setPreferred(LengthHider.autosaveName, 1)
        fixAttempts = 0
        invalidSince = nil
        problem = nil
    }

    func teardown() {
        setLength(0)
    }

    // MARK: 내부

    private enum Order { case valid, invalid, unknown }

    /// 구분선이 스펙트럼 '왼쪽'에 있어야, 구분선을 늘렸을 때 다른 아이콘만 밀려나고 스펙트럼은 남는다
    private func order(_ spectrum: NSStatusItem) -> Order {
        guard let d = divider.button?.window?.frame.origin,
              let s = spectrum.button?.window?.frame.origin,
              d != .zero, s != .zero else {
            return .unknown       // macOS 26은 배치 직후 잠깐 (0,0)을 보고한다
        }
        return d.x <= s.x ? .valid : .invalid
    }

    /// 가장 넓은 화면 기준으로 충분히 길게 (macOS는 10,000pt 넘는 길이를 받지 않음)
    private var collapseLength: CGFloat {
        let widest = NSScreen.screens.map { $0.frame.width }.max() ?? 1728
        return max(500, min(widest * 2, 10_000))
    }

    /// 구분선 길이를 목표 쪽으로 한 프레임 이동. 아직 움직이는 중이면 true
    private func step(toward target: CGFloat, spectrum: NSStatusItem) -> Bool {
        let current = divider.length
        if abs(current - target) < 0.5 { return false }

        // 실제로 눈에 보이는 구간 = 화면 왼쪽 끝 ~ 스펙트럼 왼쪽 끝
        var span: CGFloat = 1200
        if let window = spectrum.button?.window, window.frame.origin != .zero {
            let screenMinX = (window.screen ?? NSScreen.main)?.frame.minX ?? 0
            span = max(80, window.frame.minX - screenMinX)
        }

        if target > current {
            // 접기: 아이콘들을 왼쪽으로 밀어낸 뒤 최종 길이로
            if current >= span {
                setLength(target)
                return false
            }
            setLength(min(span, current + max(14, (span - current) * 0.28)))
            return true
        } else {
            // 펼치기: 왼쪽에서 아이콘들이 미끄러져 들어옴
            let from = min(current, span)
            let next = max(target, from - max(14, (from - target) * 0.28))
            setLength(next)
            return abs(next - target) >= 0.5
        }
    }

    private func setLength(_ length: CGFloat) {
        if abs(divider.length - length) > 0.01 { divider.length = length }
    }

    /// 구분선이 스펙트럼 오른쪽에 놓인 경우 위치값을 고쳐서 다시 넣어 본다 (최대 2번)
    private func autoFix(_ spectrum: NSStatusItem) {
        invalidSince = nil
        guard fixAttempts < 2 else {
            problem = "구분선이 스펙트럼 오른쪽에 있어 아이콘을 숨길 수 없습니다. 메뉴의 '메뉴바 위치 초기화'를 눌러 주세요."
            return
        }
        fixAttempts += 1
        let spectrumName: String = spectrum.autosaveName ?? ""
        let base = StatusItemPosition.preferred(spectrumName) ?? 0
        setLength(0)
        StatusItemPosition.setVisible(divider, false)
        StatusItemPosition.setPreferred(LengthHider.autosaveName, base + 1)
        StatusItemPosition.setVisible(divider, true)
    }
}

/// 배치 모드에서 보이는 점선 구분선
final class DividerLineView: NSView {
    var showsLine = false {
        didSet { if showsLine != oldValue { needsDisplay = true } }
    }

    override func hitTest(_ point: NSPoint) -> NSView? { nil }

    override func draw(_ dirtyRect: NSRect) {
        guard showsLine else { return }
        let x = floor(bounds.midX) + 0.5
        let path = NSBezierPath()
        path.move(to: NSPoint(x: x, y: bounds.minY + 4))
        path.line(to: NSPoint(x: x, y: bounds.maxY - 4))
        path.lineWidth = 1
        let dash: [CGFloat] = [2, 2]
        path.setLineDash(dash, count: dash.count, phase: 0)
        NSColor.labelColor.withAlphaComponent(0.6).setStroke()
        path.stroke()
    }
}

// MARK: macOS 27 이상: macOS의 메뉴바 허용 목록 기능 사용

@MainActor
final class NativeHider: MenuBarHider {
    private var restriction: Any?
    private var inFlight = false
    private var inFlightSince: TimeInterval = 0
    private var generation = 0
    private var retryAfter: TimeInterval = 0
    private var lastError: String?
    private let available: Bool
    private let installedInApplications: Bool

    var isBusy: Bool { inFlight }

    var problem: String? {
        if !available {
            return "이 macOS에서는 다른 아이콘 숨기기 기능을 찾지 못했습니다."
        }
        if !installedInApplications {
            return "macOS 27부터는 /Applications 폴더에서 실행해야 다른 아이콘을 숨길 수 있습니다 (./build.sh install)."
        }
        return lastError
    }

    init() {
        available = SBMenuBarRestrictionIsAvailable()
        // macOS 27은 /Applications 밖에서 실행된 앱을 허용 목록과 맞추지 못해 우리 아이콘까지 숨긴다
        installedInApplications = Bundle.main.bundleURL.path.hasPrefix("/Applications/")
    }

    func update(wantHidden: Bool, needed: Bool, arrange: Bool, animate: Bool, spectrum: NSStatusItem) {
        guard wantHidden, available, installedInApplications else {
            release()
            return
        }
        if restriction != nil { return }

        let now = monotonicNow()
        if inFlight {
            // macOS가 10초 넘게 응답하지 않으면 포기하고 잠시 뒤 다시 시도
            if now - inFlightSince > 10 {
                generation += 1
                inFlight = false
                retryAfter = now + 15
                lastError = "macOS가 아이콘 숨기기 요청에 응답하지 않았습니다."
            }
            return
        }
        guard now >= retryAfter else { return }
        activate(now)
    }

    func resetPositions() {}

    func teardown() { release() }

    private func activate(_ now: TimeInterval) {
        generation += 1
        let myGeneration = generation
        inFlight = true
        inFlightSince = now

        // 시계·제어 센터 같은 시스템 항목은 모두 남기고, 앱은 SpectrumBar만 허용
        let systemItems = (0..<64).map { NSNumber(value: $0) }
        let bundles = [Bundle.main.bundleIdentifier ?? "com.nemo.SpectrumBar"]

        SBMenuBarRestrictionActivate(systemItems, bundles) { [weak self] restriction, error in
            let message = error?.localizedDescription
            Task { @MainActor in
                guard let self, self.generation == myGeneration else {
                    // 그사이 숨기기가 취소됐으면 바로 해제
                    if let restriction { SBMenuBarRestrictionInvalidate(restriction) }
                    return
                }
                self.inFlight = false
                if let restriction {
                    self.restriction = restriction
                    self.lastError = nil
                } else {
                    self.retryAfter = monotonicNow() + 15
                    self.lastError = "다른 아이콘 숨기기 실패: \(message ?? "알 수 없는 오류")"
                }
            }
        }
    }

    private func release() {
        if inFlight {
            generation += 1
            inFlight = false
        }
        if let current = restriction {
            SBMenuBarRestrictionInvalidate(current)
            restriction = nil
        }
    }
}

// MARK: - 다른 앱의 메뉴/팝오버가 열려 있는지 확인

enum MenuBarProbe {
    /// 메뉴바에 매달려 열린 메뉴나 팝오버가 있으면 true (펼친 아이콘을 쓰는 중이면 다시 숨기지 않기 위해)
    static func menuOrPopoverIsOpen(menuBarHeight: CGFloat) -> Bool {
        guard let list = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements],
                                                    kCGNullWindowID) as? [[String: Any]] else {
            return false
        }
        let popUpLevel = Int(CGWindowLevelForKey(.popUpMenuWindow))
        let statusLevel = Int(CGWindowLevelForKey(.statusWindow))
        for info in list {
            guard let layer = info[kCGWindowLayer as String] as? Int else { continue }
            if layer == popUpLevel { return true }
            guard layer >= statusLevel,
                  let bounds = info[kCGWindowBounds as String] as? [String: Any],
                  let rect = CGRect(dictionaryRepresentation: bounds as CFDictionary) else { continue }
            // 메뉴바 바로 아래에서 시작하는 창 = 메뉴바 아이콘이 연 팝오버
            if rect.minY >= menuBarHeight - 2 && rect.minY <= menuBarHeight + 40 && rect.height > 20 {
                return true
            }
        }
        return false
    }
}
