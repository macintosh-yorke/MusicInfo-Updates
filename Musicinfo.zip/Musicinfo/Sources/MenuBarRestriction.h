//  MenuBarRestriction.h
//  SpectrumBar
//
//  macOS 27 이상에서 다른 앱의 메뉴바 아이콘을 숨기기 위한 얇은 Objective-C 래퍼.
//  macOS 27은 예전 방식(구분선 아이템 길이를 크게 늘려 밀어내기)을 막았기 때문에,
//  macOS가 '평가(시험) 모드'에서 쓰는 비공개 프레임워크 MenuBarClientCore의
//  허용 목록(allow-list) 기능을 런타임에 찾아서 사용한다. (Hidden Bar 1.12+와 같은 방식)
//  API가 바뀌거나 없으면 '사용 불가'로만 처리되고 앱의 나머지 기능은 그대로 동작한다.

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 이 macOS에 필요한 비공개 API가 있는지
BOOL SBMenuBarRestrictionIsAvailable(void);

/// allowedBundleIDs 앱과 allowedSystemItems(시계·제어 센터 등)만 메뉴바에 남기고 나머지 아이콘을 숨긴다.
/// completion은 메인 큐에서 호출된다. 성공하면 restriction 객체를 받으며, 그 객체를 해제(Invalidate)하거나
/// 앱이 종료될 때까지 숨김이 유지된다.
void SBMenuBarRestrictionActivate(NSArray<NSNumber *> *allowedSystemItems,
                                  NSArray<NSString *> *allowedBundleIDs,
                                  void (^completion)(id _Nullable restriction, NSError * _Nullable error));

/// 숨김 해제
void SBMenuBarRestrictionInvalidate(id restriction);

NS_ASSUME_NONNULL_END
