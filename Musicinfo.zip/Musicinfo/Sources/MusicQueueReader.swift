import Cocoa
import ApplicationServices

/// 음악 앱의 '재생 대기 목록(다음 재생)'을 손쉬운 사용(Accessibility)으로 읽는다.
/// 음악 앱은 이 목록을 AppleScript로 내주지 않아서, 화면에 그려진 목록을 그대로 읽는 방식.
/// (셔플 순서·'다음에 재생'으로 넣은 곡까지 음악 앱이 보여 주는 그대로 나옴)
///
/// 목록 구조 (음악 앱 재생 대기 목록 표):
///   [재생 기록]  ← 머리 행 (글자 1개 + 설명 없는 버튼)
///   지난 곡들 …
///   [다음 재생] / [계속 재생]  ← 머리 행
///   다음 곡들 …   (행마다 [제목] [아티스트 — 앨범] + '더 보기' 버튼)
enum MusicQueueReader {
    struct Result: Sendable, Equatable {
        var titles: [String]     // 앞에서부터 최대 limit개
        var total: Int           // 다음 곡 전체 개수
        var subtitles: [String] = []   // 곡마다 "아티스트 — 앨범"
    }

    static var isTrusted: Bool { AXIsProcessTrusted() }

    /// 손쉬운 사용 권한 요청 (시스템 설정 창이 뜸)
    static func requestTrust() {
        let key = kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String
        _ = AXIsProcessTrustedWithOptions([key: true] as CFDictionary)
    }

    static func openAccessibilitySettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
            NSWorkspace.shared.open(url)
        }
    }

    // 빠르게 읽기 위한 기억: 찾아 둔 목록 표, '다음 곡' 머리 행 위치
    // (전용 직렬 큐에서만 만짐)
    private static let queue = DispatchQueue(label: "SpectrumBar.queueReader", qos: .userInitiated)
    nonisolated(unsafe) private static var cachedPID: pid_t = 0
    nonisolated(unsafe) private static var cachedTable: AXUIElement?
    nonisolated(unsafe) private static var cachedHeaderIndex: Int?

    /// 다음 곡 목록 (백그라운드 큐에서 읽고 결과를 돌려줌). 권한이 없거나 목록을 못 찾으면 nil.
    /// current: 지금 재생 중인 곡 제목 — 음악 앱 목록이 늦게 갱신돼 이미 지나간 곡이 남아 있으면 잘라 냄
    static func read(pid: pid_t, limit: Int = 3, current: String? = nil) async -> Result? {
        await withCheckedContinuation { continuation in
            queue.async {
                // 넉넉히 읽은 뒤, 목록 앞쪽에 '지금 곡'이 있으면 그 앞(이미 들은 곡)까지 버림
                guard var result = readSync(pid: pid, limit: limit + 12) else {
                    continuation.resume(returning: nil)
                    return
                }
                if let current, !current.isEmpty,
                   let k = result.titles.prefix(12).firstIndex(of: current) {
                    debugLog("queue: stale list, skipping \(k + 1) played rows")
                    result.titles.removeFirst(k + 1)
                    result.subtitles.removeFirst(min(k + 1, result.subtitles.count))
                    result.total = max(0, result.total - (k + 1))
                }
                result.titles = Array(result.titles.prefix(limit))
                result.subtitles = Array(result.subtitles.prefix(limit))
                continuation.resume(returning: result)
            }
        }
    }

    private static func readSync(pid: pid_t, limit: Int) -> Result? {
        guard AXIsProcessTrusted() else { return nil }
        if pid != cachedPID {
            cachedPID = pid
            cachedTable = nil
            cachedHeaderIndex = nil
        }
        // 1) 찾아 둔 표가 아직 살아 있으면 그대로 사용 (창 전체를 다시 뒤지지 않음)
        if let table = cachedTable, let result = parse(table: table, limit: limit) {
            return result
        }
        cachedTable = nil
        cachedHeaderIndex = nil
        let app = AXUIElementCreateApplication(pid)
        AXUIElementSetMessagingTimeout(app, 0.6)
        guard let windows: [AXUIElement] = value(app, kAXWindowsAttribute) else { return nil }
        for window in windows {
            if let table = findQueueTable(in: window), let result = parse(table: table, limit: limit) {
                cachedTable = table
                return result
            }
        }
        return nil
    }

    /// 음악 앱 창이 전부 최소화돼 있는지 — 최소화된 창은 목록을 새로 그리지 않아서 예전 내용이 남음
    static func isMinimized(pid: pid_t) -> Bool {
        guard AXIsProcessTrusted() else { return false }
        let app = AXUIElementCreateApplication(pid)
        guard let windows: [AXUIElement] = value(app, kAXWindowsAttribute), !windows.isEmpty else { return false }
        return windows.allSatisfy { (value($0, kAXMinimizedAttribute) as Bool?) ?? false }
    }

    /// 최소화 풀기 / 다시 최소화
    static func setMinimized(pid: pid_t, _ minimized: Bool) {
        let app = AXUIElementCreateApplication(pid)
        guard let windows: [AXUIElement] = value(app, kAXWindowsAttribute) else { return }
        for w in windows {
            AXUIElementSetAttributeValue(w, kAXMinimizedAttribute as CFString, minimized as CFBoolean)
        }
    }

    // MARK: 목록 찾기

    private static let queueNames: Set<String> = ["재생 대기 목록", "다음 재생", "Playing Next", "Up Next", "次に再生"]

    /// 창 안에서 재생 대기 목록 표를 찾음 (너비 우선, 다른 표 안으로는 들어가지 않음)
    private static func findQueueTable(in root: AXUIElement) -> AXUIElement? {
        var queue: [(AXUIElement, Int)] = [(root, 0)]
        var visited = 0
        while !queue.isEmpty, visited < 600 {
            let (element, depth) = queue.removeFirst()
            visited += 1
            let role: String = value(element, kAXRoleAttribute) ?? ""
            if role == kAXGroupRole, let desc: String = value(element, kAXDescriptionAttribute),
               queueNames.contains(desc), let table = firstTable(in: element) {
                return table
            }
            if role == kAXTableRole || role == kAXOutlineRole {
                // 이름표가 없는 경우 대비: 첫 행이 머리 행이고 그 뒤에 또 머리 행이 있는 표
                if looksLikeQueue(element) { return element }
                continue
            }
            guard depth < 10, let children: [AXUIElement] = value(element, kAXChildrenAttribute) else { continue }
            for child in children { queue.append((child, depth + 1)) }
        }
        return nil
    }

    private static func firstTable(in element: AXUIElement, depth: Int = 0) -> AXUIElement? {
        guard depth < 4, let children: [AXUIElement] = value(element, kAXChildrenAttribute) else { return nil }
        for child in children {
            let role: String = value(child, kAXRoleAttribute) ?? ""
            if role == kAXTableRole || role == kAXOutlineRole { return child }
            if let found = firstTable(in: child, depth: depth + 1) { return found }
        }
        return nil
    }

    private static func looksLikeQueue(_ table: AXUIElement) -> Bool {
        guard let rows: [AXUIElement] = value(table, kAXRowsAttribute), let first = rows.first else { return false }
        return info(of: first).isHeader
    }

    // MARK: 행 읽기

    private struct RowInfo {
        var texts: [String] = []
        var buttons = 0
        var describedButtons = 0
        // 머리 행: 글자 하나 + 버튼 (재생 기록 '지우기', 계속 재생 '셔플·반복' 등). 곡 행은 보통 글자 2개
        // · 재생 기록 / 계속 재생: 글자 1개 + 버튼(설명 없음)
        // · 자동 재생: 아이콘(￼) 붙은 글자 + "비슷한 노래 재생", 버튼 없음
        var isHeader: Bool {
            guard describedButtons == 0, !texts.isEmpty else { return false }
            if texts.count == 1 && buttons > 0 { return true }
            return texts.contains { $0.contains("\u{FFFC}") }
        }
        var isSong: Bool { !texts.isEmpty && !isHeader }
    }

    private static func info(of row: AXUIElement) -> RowInfo {
        var result = RowInfo()
        collect(row, into: &result, depth: 0)
        return result
    }

    private static func collect(_ element: AXUIElement, into info: inout RowInfo, depth: Int) {
        guard depth < 4, let children: [AXUIElement] = value(element, kAXChildrenAttribute) else { return }
        for child in children {
            let role: String = value(child, kAXRoleAttribute) ?? ""
            switch role {
            case kAXStaticTextRole:
                if let text: String = value(child, kAXValueAttribute), !text.isEmpty { info.texts.append(text) }
            case kAXButtonRole:
                info.buttons += 1
                if let desc: String = value(child, kAXDescriptionAttribute), !desc.isEmpty { info.describedButtons += 1 }
            default:
                collect(child, into: &info, depth: depth + 1)
            }
        }
    }

    /// 첫 머리 행(재생 기록) 다음에 나오는 머리 행부터가 '다음 곡'.
    /// 지난번 머리 행 위치 근처만 확인해서 빠르게 찾고, 못 찾을 때만 처음부터 훑음.
    /// 음악 앱의 목록은 화면에 보이는 줄만 글자가 채워짐(안 보이는 줄은 빈 칸).
    /// 그래서 필요한 줄이 비어 있으면 그 줄이 보이도록 목록을 살짝 스크롤시킨 뒤 다시 읽음.
    private static func parse(table: AXUIElement, limit: Int) -> Result? {
        guard let rows: [AXUIElement] = value(table, kAXRowsAttribute), !rows.isEmpty else { return nil }
        var start = headerIndex(in: rows)
        if start == nil {
            // 머리 행이 안 보여서 못 찾음 → 재생 기록은 최대 200곡이라 보통 201번째 줄이 머리 행
            let guess = min(rows.count - 1, 201)
            if guess > 0 {
                scrollToVisible(rows[guess])
                start = headerIndex(in: rows)
            }
        }
        guard let start else {
            return Result(titles: [], total: 0)   // 재생 기록만 있음 = 다음 곡 없음
        }
        cachedHeaderIndex = start
        // 다음 곡 줄이 비어 있으면(안 보이는 곳) 그쪽으로 스크롤
        if start + 1 < rows.count, info(of: rows[start + 1]).texts.isEmpty {
            scrollToVisible(rows[min(rows.count - 1, start + limit + 1)])
            scrollToVisible(rows[start])
        }
        var titles: [String] = []
        var subtitles: [String] = []
        var index = start + 1
        var headersAfter = 0
        while index < rows.count, titles.count < limit {
            let row = info(of: rows[index])
            if row.isHeader { headersAfter += 1 } else if row.isSong {
                titles.append(row.texts[0])
                subtitles.append(row.texts.count > 1 ? row.texts[1] : "")
            }
            index += 1
        }
        let total = titles.count + max(0, rows.count - index)
        return Result(titles: titles, total: max(total - headersAfter, titles.count), subtitles: subtitles)
    }

    private static func scrollToVisible(_ row: AXUIElement) {
        AXUIElementPerformAction(row, "AXScrollToVisible" as CFString)
        usleep(150_000)      // 음악 앱이 줄을 다시 그릴 시간
    }

    /// 0번(재생 기록) 다음에 나오는 첫 머리 행 위치 = '다음 재생' 시작
    /// (음악 앱 손쉬운 사용 응답이 느려서 확인할 줄 수를 최소로)
    private static func headerIndex(in rows: [AXUIElement]) -> Int? {
        // 1) 재생 기록은 최대 200곡 → 기록이 꽉 차 있으면 201번 줄이 바로 머리 행
        if rows.count > 201, info(of: rows[201]).isHeader { return 201 }
        // 2) 지난번 자리 근처 (기록이 덜 찼을 때 곡이 넘어가면 한 줄씩 밀림)
        if let last = cachedHeaderIndex {
            for delta in [0, 1, 2, 3, -1, 4, 5, 6, 7, 8] {
                let i = last + delta
                guard i > 0, i < rows.count else { continue }
                if info(of: rows[i]).isHeader { return i }
            }
        }
        // 3) 못 찾으면 처음부터 훑기 (느리지만 한 번뿐 — 다음부턴 위에서 찾음)
        for i in 1..<rows.count where info(of: rows[i]).isHeader {
            return i
        }
        return nil
    }

    private static func value<T>(_ element: AXUIElement, _ attribute: String) -> T? {
        var ref: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, attribute as CFString, &ref) == .success else { return nil }
        return ref as? T
    }
}

/// 음악 앱 메뉴 막대의 메뉴 항목을 손쉬운 사용으로 누름 (예: 노래 › 바로 다음에 재생)
enum MusicMenu {
    static func press(pid: pid_t, menuTitles: Set<String>, itemTitles: Set<String>) -> Bool {
        guard AXIsProcessTrusted() else { return false }
        let app = AXUIElementCreateApplication(pid)
        AXUIElementSetMessagingTimeout(app, 0.8)
        guard let bar: AXUIElement = copy(app, kAXMenuBarAttribute),
              let barItems: [AXUIElement] = copy(bar, kAXChildrenAttribute) else { return false }
        for barItem in barItems {
            guard let title: String = copy(barItem, kAXTitleAttribute), menuTitles.contains(title),
                  let menus: [AXUIElement] = copy(barItem, kAXChildrenAttribute), let menu = menus.first,
                  let items: [AXUIElement] = copy(menu, kAXChildrenAttribute) else { continue }
            for item in items {
                guard let itemTitle: String = copy(item, kAXTitleAttribute), itemTitles.contains(itemTitle) else { continue }
                return AXUIElementPerformAction(item, kAXPressAction as CFString) == .success
            }
        }
        return false
    }

    private static func copy<T>(_ element: AXUIElement, _ attribute: String) -> T? {
        var ref: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, attribute as CFString, &ref) == .success else { return nil }
        return ref as? T
    }
}
