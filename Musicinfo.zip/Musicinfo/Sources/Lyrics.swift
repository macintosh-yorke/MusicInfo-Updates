import Foundation

/// 가사 한 줄 (시작 시각, 내용)
struct LyricLine: Sendable {
    let time: Double
    let text: String
}

/// 재생 중인 곡의 시간 맞춤 가사(LRC)를 LRCLIB(lrclib.net, 무료 공개 가사 DB)에서 받아 온다.
/// Apple Music 앱의 실시간 가사는 외부 앱이 읽을 수 없어서 이 방식을 쓴다.
@MainActor
final class LyricsProvider {
    private(set) var lines: [LyricLine] = []
    private(set) var isLoading = false
    private var currentKey: String?
    private var task: Task<Void, Never>?
    private var cache: [String: [LyricLine]] = [:]
    var onChange: (@MainActor () -> Void)?

    /// 곡이 바뀌면 가사를 새로 받아 옴 (같은 곡이면 아무것도 안 함)
    func load(for track: NowPlaying?) {
        guard let track, !track.title.isEmpty else {
            currentKey = nil
            task?.cancel()
            lines = []
            isLoading = false
            onChange?()
            return
        }
        guard track.key != currentKey else { return }
        currentKey = track.key
        task?.cancel()

        if let cached = cache[track.key] {
            lines = cached
            isLoading = false
            onChange?()
            return
        }

        lines = []
        isLoading = true
        onChange?()
        let key = track.key
        task = Task { [weak self] in
            let result = await LyricsProvider.fetch(track)
            guard let self, !Task.isCancelled, self.currentKey == key else { return }
            self.cache[key] = result
            self.lines = result
            self.isLoading = false
            self.onChange?()
        }
    }

    /// 재생 위치에 맞는 (현재 줄, 다음 줄)
    func lines(at position: Double) -> (current: String, next: String)? {
        guard !lines.isEmpty else { return nil }
        // 0.2초 일찍 넘겨서 노래보다 늦어 보이지 않게
        let t = position + 0.2
        var index = -1
        var lo = 0, hi = lines.count - 1
        while lo <= hi {
            let mid = (lo + hi) / 2
            if lines[mid].time <= t { index = mid; lo = mid + 1 } else { hi = mid - 1 }
        }
        if index < 0 {
            return ("", lines[0].text)            // 첫 가사 전 (전주)
        }
        let next = index + 1 < lines.count ? lines[index + 1].text : ""
        return (lines[index].text, next)
    }

    // MARK: - LRCLIB

    nonisolated private static func fetch(_ track: NowPlaying) async -> [LyricLine] {
        // 1) 제목·아티스트·앨범·길이로 정확히 찾기
        var get = URLComponents(string: "https://lrclib.net/api/get")!
        get.queryItems = [URLQueryItem(name: "track_name", value: track.title),
                          URLQueryItem(name: "artist_name", value: track.artist),
                          URLQueryItem(name: "album_name", value: track.album)]
        if track.duration > 0 {
            get.queryItems?.append(URLQueryItem(name: "duration", value: String(Int(track.duration.rounded()))))
        }
        if let url = get.url, let data = await download(url),
           let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let synced = object["syncedLyrics"] as? String, !synced.isEmpty {
            let parsed = parse(synced)
            if !parsed.isEmpty { return parsed }
        }

        // 2) 한국 노래는 영어 이름으로 등록된 경우가 많아서, 여러 방식으로 검색한 뒤
        //    '곡 길이'가 거의 같은 결과를 고른다 (이름이 달라도 길이는 같음)
        let base = baseTitle(track.title)
        let searches: [([URLQueryItem], Double)] = [
            ([URLQueryItem(name: "track_name", value: track.title),
              URLQueryItem(name: "artist_name", value: track.artist)], 5),
            ([URLQueryItem(name: "q", value: "\(base) \(track.artist)")], 4),
            ([URLQueryItem(name: "q", value: base)], 2.5),
        ]
        for (items, tolerance) in searches {
            if Task.isCancelled { return [] }
            var search = URLComponents(string: "https://lrclib.net/api/search")!
            search.queryItems = items
            guard let url = search.url, let data = await download(url),
                  let results = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { continue }
            let candidates = results.compactMap { item -> (Double, String)? in
                guard let synced = item["syncedLyrics"] as? String, !synced.isEmpty else { return nil }
                let duration = (item["duration"] as? NSNumber)?.doubleValue ?? 0
                guard track.duration > 0, duration > 0 else { return nil }
                return (abs(duration - track.duration), synced)
            }
            if let best = candidates.min(by: { $0.0 < $1.0 }), best.0 <= tolerance {
                let parsed = parse(best.1)
                if !parsed.isEmpty { return parsed }
            }
        }
        return []
    }

    /// "자니 (feat. 다이나믹 듀오)" → "자니" : 피처링·프로듀서 표기를 떼어 검색이 잘 되게
    nonisolated static func baseTitle(_ title: String) -> String {
        let pattern = #"\s*[\(\[][^\)\]]*(feat|Feat|FEAT|ft\.|prod|Prod)[^\)\]]*[\)\]]"#
        let stripped = title.replacingOccurrences(of: pattern, with: "", options: .regularExpression)
        let trimmed = stripped.trimmingCharacters(in: .whitespaces)
        return trimmed.isEmpty ? title : trimmed
    }

    nonisolated private static func download(_ url: URL) async -> Data? {
        var request = URLRequest(url: url, timeoutInterval: 8)
        request.setValue("SpectrumBar/2.0 (personal macOS menu bar app)", forHTTPHeaderField: "User-Agent")
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200 else { return nil }
        return data
    }

    /// LRC 형식 "[01:23.45] 가사" 해석 (한 줄에 시간 태그가 여러 개여도 처리)
    nonisolated static func parse(_ lrc: String) -> [LyricLine] {
        var result: [LyricLine] = []
        for raw in lrc.split(whereSeparator: \.isNewline) {
            var rest = Substring(raw)
            var times: [Double] = []
            while rest.hasPrefix("["), let close = rest.firstIndex(of: "]") {
                let tag = rest[rest.index(after: rest.startIndex)..<close]
                let parts = tag.split(separator: ":")
                if parts.count == 2, let minutes = Double(parts[0]), let seconds = Double(parts[1]) {
                    times.append(minutes * 60 + seconds)
                }
                rest = rest[rest.index(after: close)...]
            }
            let text = rest.trimmingCharacters(in: .whitespaces)
            for time in times { result.append(LyricLine(time: time, text: text)) }
        }
        return result.sorted { $0.time < $1.time }
    }
}
