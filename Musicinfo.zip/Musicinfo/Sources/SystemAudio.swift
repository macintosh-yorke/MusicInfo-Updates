import Foundation
import CoreAudio
import AudioToolbox
import Accelerate

// MARK: - 공유 상태 (오디오 스레드 ↔ 메인 스레드)

/// 오디오 쪽이 쓰고 메인 스레드가 읽는 최신 상태. 잠금으로 보호한다.
final class LevelStore {
    struct Snapshot {
        var levels: [Float] = []          // 밴드별 레벨 0~1
        var rms: Float = 0                // 최근 버퍼의 RMS (0~1)
        var lastAudio: TimeInterval = 0   // 마지막 오디오 콜백 시각
        var everSignal = false            // 실행 후 0이 아닌 소리를 한 번이라도 받았는지
        var outputActive = false          // 다른 앱이 오디오를 출력 중인지
        var tapRunning = false            // 시스템 오디오 캡처 중인지
        var permissionSuspect = false     // 출력은 있는데 계속 무음 → 권한 거부 의심
        var lastError: String?
    }

    private let lock = NSLock()
    private var snapshot = Snapshot()

    func read() -> Snapshot {
        lock.lock()
        defer { lock.unlock() }
        return snapshot
    }

    func update(_ body: (inout Snapshot) -> Void) {
        lock.lock()
        defer { lock.unlock() }
        body(&snapshot)
    }
}

// MARK: - Core Audio 속성 도우미

enum CoreAudioHelper {
    static let systemObject = AudioObjectID(kAudioObjectSystemObject)

    static func address(_ selector: AudioObjectPropertySelector) -> AudioObjectPropertyAddress {
        AudioObjectPropertyAddress(mSelector: selector,
                                   mScope: kAudioObjectPropertyScopeGlobal,
                                   mElement: kAudioObjectPropertyElementMain)
    }

    /// 고정 크기 속성 읽기. 실패하면 nil
    static func read<T>(_ object: AudioObjectID, _ selector: AudioObjectPropertySelector, _ initial: T) -> T? {
        var addr = address(selector)
        var value = initial
        var size = UInt32(MemoryLayout<T>.size)
        let status = withUnsafeMutablePointer(to: &value) { pointer in
            AudioObjectGetPropertyData(object, &addr, 0, nil, &size, UnsafeMutableRawPointer(pointer))
        }
        return status == noErr ? value : nil
    }

    /// Core Audio에 등록된 오디오 프로세스 목록 (macOS 14.2+, 권한 필요 없음)
    static func processObjects() -> [AudioObjectID] {
        var addr = address(kAudioHardwarePropertyProcessObjectList)
        var size: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(systemObject, &addr, 0, nil, &size) == noErr, size > 0 else {
            return []
        }
        var ids = [AudioObjectID](repeating: 0, count: Int(size) / MemoryLayout<AudioObjectID>.size)
        guard AudioObjectGetPropertyData(systemObject, &addr, 0, nil, &size, &ids) == noErr else {
            return []
        }
        return Array(ids.prefix(Int(size) / MemoryLayout<AudioObjectID>.size))
    }

    /// 우리 앱을 뺀 나머지 중 소리를 출력 중인 프로세스가 있는지
    static func someoneIsPlaying(excluding pid: pid_t) -> Bool {
        for object in processObjects() {
            guard let running = read(object, kAudioProcessPropertyIsRunningOutput, UInt32(0)),
                  running != 0 else { continue }
            if let owner = read(object, kAudioProcessPropertyPID, pid_t(0)), owner == pid { continue }
            return true
        }
        return false
    }

    static func defaultOutputDevice() -> AudioDeviceID {
        read(systemObject, kAudioHardwarePropertyDefaultOutputDevice, AudioDeviceID(0)) ?? 0
    }
}

// MARK: - 시스템 오디오 탭 (macOS 14.4+)

enum TapError: LocalizedError {
    case failed(String, OSStatus)

    var errorDescription: String? {
        switch self {
        case let .failed(step, status): return "\(step) 실패 (OSStatus \(status))"
        }
    }
}

/// 모든 앱의 소리를 받아오는 Core Audio 프로세스 탭 + 탭 전용 비공개 집계 장치
final class TapSession {
    private var tapID: AudioObjectID = 0
    private var aggregateID: AudioObjectID = 0
    private var ioProcID: AudioDeviceIOProcID?
    private(set) var sampleRate: Double = 48_000
    private(set) var isFloat32 = true

    init(queue: DispatchQueue, onInput: @escaping (UnsafePointer<AudioBufferList>) -> Void) throws {
        // 1) 탭 정의: '제외할 프로세스' 목록을 비워 두면 = 모든 앱의 소리 (스테레오 믹스)
        let tap = CATapDescription()
        tap.name = "SpectrumBar"
        tap.processes = []
        tap.isExclusive = true
        tap.isMixdown = true
        tap.isMono = false
        tap.isPrivate = true
        tap.muteBehavior = .unmuted          // 원래 소리는 그대로 스피커로 나감
        tap.uuid = UUID()

        var newTap: AudioObjectID = 0
        var status = AudioHardwareCreateProcessTap(tap, &newTap)
        guard status == noErr else { throw TapError.failed("오디오 탭 생성", status) }
        tapID = newTap

        if let format = CoreAudioHelper.read(newTap, kAudioTapPropertyFormat, AudioStreamBasicDescription()) {
            if format.mSampleRate > 0 { sampleRate = format.mSampleRate }
            isFloat32 = (format.mFormatFlags & kAudioFormatFlagIsFloat) != 0 && format.mBitsPerChannel == 32
        }

        // 2) 탭만 담은 비공개 집계 장치 (마이크 같은 실제 입력 장치는 넣지 않음)
        let tapEntry: [String: Any] = [
            kAudioSubTapUIDKey: tap.uuid.uuidString,
            kAudioSubTapDriftCompensationKey: true,
        ]
        let description: [String: Any] = [
            kAudioAggregateDeviceNameKey: "SpectrumBar Tap",
            kAudioAggregateDeviceUIDKey: "com.nemo.SpectrumBar.tap.\(UUID().uuidString)",
            kAudioAggregateDeviceIsPrivateKey: true,
            kAudioAggregateDeviceIsStackedKey: false,
            kAudioAggregateDeviceTapAutoStartKey: true,
            kAudioAggregateDeviceSubDeviceListKey: [[String: Any]](),
            kAudioAggregateDeviceTapListKey: [tapEntry],
        ]
        var newAggregate: AudioObjectID = 0
        status = AudioHardwareCreateAggregateDevice(description as CFDictionary, &newAggregate)
        guard status == noErr else {
            teardown()
            throw TapError.failed("캡처 장치 생성", status)
        }
        aggregateID = newAggregate

        if let rate = CoreAudioHelper.read(newAggregate, kAudioDevicePropertyNominalSampleRate, Float64(0)), rate > 0 {
            sampleRate = rate
        }

        // 3) IO 콜백 등록 후 시작 → 맨 처음 시작할 때 macOS가 '시스템 오디오 녹음' 권한을 묻는다
        status = AudioDeviceCreateIOProcIDWithBlock(&ioProcID, newAggregate, queue) { _, inputData, _, _, _ in
            onInput(inputData)
        }
        guard status == noErr, ioProcID != nil else {
            teardown()
            throw TapError.failed("오디오 콜백 등록", status)
        }

        status = AudioDeviceStart(newAggregate, ioProcID)
        guard status == noErr else {
            teardown()
            throw TapError.failed("캡처 시작", status)
        }
    }

    func stop() { teardown() }

    deinit { teardown() }

    private func teardown() {
        if aggregateID != 0 {
            if let proc = ioProcID {
                AudioDeviceStop(aggregateID, proc)
                AudioDeviceDestroyIOProcID(aggregateID, proc)
            }
            AudioHardwareDestroyAggregateDevice(aggregateID)
        }
        ioProcID = nil
        aggregateID = 0
        if tapID != 0 { AudioHardwareDestroyProcessTap(tapID) }
        tapID = 0
    }
}

// MARK: - 감시자: 소리 나는 앱이 있을 때만 캡처

/// 0.5초마다 '소리를 출력 중인 앱'이 있는지 확인해서, 있을 때만 시스템 오디오를 캡처·분석한다.
/// 아무 소리도 없으면 캡처를 꺼서 macOS의 '오디오 녹음 중' 표시도 사라진다.
final class SystemAudioMonitor {
    private let store: LevelStore
    private let control = DispatchQueue(label: "SpectrumBar.audio.control", qos: .utility)
    private let io = DispatchQueue(label: "SpectrumBar.audio.io", qos: .userInteractive)
    private let ownPID = getpid()

    // control 큐 전용 상태
    private var timer: DispatchSourceTimer?
    private var session: TapSession?
    private var sessionStart: TimeInterval = 0
    private var sessionDevice: AudioDeviceID = 0
    private var lastPlaying: TimeInterval = -100
    private var lastBegin: TimeInterval = -100
    private var lastPoll: TimeInterval = 0
    private var silentRestarts = 0
    private var silentPlayingTime: TimeInterval = 0

    // io 큐 전용 상태
    private let analyzer: SpectrumAnalyzer
    private var mono: [Float] = []
    private var sampleRate: Double = 48_000
    private var inputIsFloat = true

    init(store: LevelStore, bandCount: Int, gain: Float) {
        self.store = store
        self.analyzer = SpectrumAnalyzer(bandCount: bandCount, gain: gain)
    }

    // MARK: 외부 제어 (메인 스레드에서 호출)

    func start() {
        control.async { [self] in
            guard timer == nil else { return }
            let t = DispatchSource.makeTimerSource(queue: control)
            t.schedule(deadline: .now(), repeating: .milliseconds(500), leeway: .milliseconds(100))
            t.setEventHandler { [weak self] in self?.poll() }
            t.resume()
            timer = t
        }
    }

    func stop() {
        control.sync { [self] in
            timer?.cancel()
            timer = nil
            endSession()
        }
    }

    func restartCapture() {
        control.async { [self] in
            silentRestarts = 0
            silentPlayingTime = 0
            lastBegin = -100
            store.update { s in
                s.permissionSuspect = false
                s.lastError = nil
            }
            endSession()
        }
    }

    func systemDidWake() {
        control.async { [self] in endSession() }
    }

    func setBandCount(_ count: Int) {
        io.async { [analyzer] in analyzer.bandCount = count }
    }

    func setGain(_ gain: Float) {
        io.async { [analyzer] in analyzer.gain = gain }
    }

    // MARK: 주기 점검 (control 큐)

    private func poll() {
        let now = monotonicNow()
        let dt = lastPoll == 0 ? 0 : min(2, now - lastPoll)
        lastPoll = now

        let playing = CoreAudioHelper.someoneIsPlaying(excluding: ownPID)
        if playing { lastPlaying = now }
        let running = session != nil
        store.update { s in
            s.outputActive = playing
            s.tapRunning = running
        }

        guard running else {
            if playing && now - lastBegin > 2 { beginSession(now) }
            return
        }

        let snap = store.read()

        // 소리 내는 앱이 2.5초 넘게 없으면 캡처 종료 → '녹음 중' 표시도 꺼짐
        if !playing && now - lastPlaying > 2.5 {
            endSession()
            return
        }
        // 기본 출력 장치가 바뀌면(이어폰 연결 등) 다시 연결
        if CoreAudioHelper.defaultOutputDevice() != sessionDevice {
            endSession()
            beginSession(now)
            return
        }
        // 콜백이 3초 넘게 끊기면 다시 연결
        if now - sessionStart > 3 && now - snap.lastAudio > 3 {
            endSession()
            beginSession(now)
            return
        }
        // 출력은 있는데 0만 들어오는 경우: 권한 허용 직후일 수 있으니 몇 번 다시 연결해 보고,
        // 계속 그러면 권한 거부를 의심한다.
        if playing && !snap.everSignal {
            silentPlayingTime += dt
            if now - sessionStart > 6 && silentRestarts < 3 {
                silentRestarts += 1
                endSession()
                beginSession(now)
                return
            }
            if silentPlayingTime > 20 && !snap.permissionSuspect {
                store.update { $0.permissionSuspect = true }
            }
        } else if snap.everSignal && snap.permissionSuspect {
            store.update { $0.permissionSuspect = false }
        }
    }

    private func beginSession(_ now: TimeInterval) {
        lastBegin = now
        sessionStart = now
        sessionDevice = CoreAudioHelper.defaultOutputDevice()
        do {
            let newSession = try TapSession(queue: io) { [weak self] input in
                self?.process(input)
            }
            let rate = newSession.sampleRate
            let isFloat = newSession.isFloat32
            io.async { [weak self] in
                self?.sampleRate = rate
                self?.inputIsFloat = isFloat
            }
            session = newSession
            store.update { s in
                s.tapRunning = true
                s.lastError = nil
            }
        } catch {
            let message = error.localizedDescription
            store.update { s in
                s.tapRunning = false
                s.lastError = message
            }
        }
    }

    private func endSession() {
        session?.stop()
        session = nil
        store.update { $0.tapRunning = false }
    }

    // MARK: 오디오 콜백 (io 큐): 모노로 섞고 → RMS + FFT

    private func process(_ input: UnsafePointer<AudioBufferList>) {
        guard inputIsFloat else { return }
        let buffers = UnsafeMutableAudioBufferListPointer(UnsafeMutablePointer(mutating: input))

        // 버퍼 구성(인터리브/비인터리브)에 상관없이 프레임 수 계산
        var frames = Int.max
        for buffer in buffers {
            let channels = max(1, Int(buffer.mNumberChannels))
            frames = min(frames, Int(buffer.mDataByteSize) / (MemoryLayout<Float>.size * channels))
        }
        guard frames != Int.max, frames > 0 else { return }

        if mono.count != frames {
            mono = [Float](repeating: 0, count: frames)
        } else {
            for i in 0..<frames { mono[i] = 0 }
        }

        var totalChannels = 0
        for buffer in buffers {
            guard let raw = buffer.mData else { continue }
            let samples = raw.assumingMemoryBound(to: Float.self)
            let channels = max(1, Int(buffer.mNumberChannels))
            for f in 0..<frames {
                var sum: Float = 0
                for c in 0..<channels { sum += samples[f * channels + c] }
                mono[f] += sum
            }
            totalChannels += channels
        }
        guard totalChannels > 0 else { return }
        let scale = 1 / Float(totalChannels)
        for i in 0..<frames { mono[i] *= scale }

        var rms: Float = 0
        var peak: Float = 0
        vDSP_rmsqv(mono, 1, &rms, vDSP_Length(frames))
        vDSP_maxmgv(mono, 1, &peak, vDSP_Length(frames))
        let levels = analyzer.process(mono, sampleRate: sampleRate)
        let now = monotonicNow()

        store.update { s in
            s.rms = rms
            s.lastAudio = now
            if peak > 0 { s.everSignal = true }
            if let levels { s.levels = levels }
        }
    }
}
