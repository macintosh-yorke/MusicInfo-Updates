import Cocoa

/// 앱 진입점: Dock 아이콘 없이 메뉴바에만 상주(.accessory)
@main
@MainActor
enum SpectrumBarApp {
    static func main() {
        let app = NSApplication.shared
        let delegate = AppDelegate()
        app.delegate = delegate              // NSApplication.delegate는 weak → 아래에서 수명 유지
        app.setActivationPolicy(.accessory)
        withExtendedLifetime(delegate) {
            app.run()
        }
    }
}
