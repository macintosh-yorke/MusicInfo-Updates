import Cocoa
import ServiceManagement
import Carbon.HIToolbox
import Sparkle

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {
    private let store = LevelStore()
    private let settings = Settings.shared
    private var audio: SystemAudioMonitor!
    private var bar: MenuBarController!
    private var widget: DesktopWidgetController!
    private var fullscreen: FullscreenCoverController!
    private var hotKey: GlobalHotKey?
    private var songSearch: SongSearchController!
    private var doubleCommand: DoubleCommandDetector?
    private var updaterController: SPUStandardUpdaterController!

    // MARK: - 앱 수명주기

    func applicationDidFinishLaunching(_ notification: Notification) {
        updaterController = SPUStandardUpdaterController(startingUpdater: true,
                                                         updaterDelegate: nil,
                                                         userDriverDelegate: nil)
        audio = SystemAudioMonitor(store: store, bandCount: settings.bandCount, gain: settings.gain)
        bar = MenuBarController(store: store)
        widget = DesktopWidgetController()
        bar.widget = widget

        // 다음 곡 목록(재생 대기 목록)을 읽으려면 손쉬운 사용 권한이 필요 → 처음 한 번만 물어봄
        if settings.widgetUpNext, !MusicQueueReader.isTrusted,
           !UserDefaults.standard.bool(forKey: "askedQueueAccess") {
            UserDefaults.standard.set(true, forKey: "askedQueueAccess")
            MusicQueueReader.requestTrust()
        }

        // ⌘ 두 번: 보관함 노래 검색 → 재생 / 다음에 재생 / 대기열 / 플레이리스트에 추가
        songSearch = SongSearchController(music: widget.music, widget: widget, menuBar: bar)
        bar.search = songSearch
        // 보관함 노래 목록은 앱이 켜지고 잠시 뒤 미리 읽어 둠 → ⌘ 두 번 했을 때 바로 열림
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
            MainActor.assumeIsolated { self?.songSearch.reloadLibrary() }
        }
        doubleCommand = DoubleCommandDetector { [weak self] in self?.songSearch.toggle() }
        // 개발용: 화면 확인을 위해 밖에서 검색 창 열기/닫기 (object: "open" / "close" / "query:검색어")
        DistributedNotificationCenter.default().addObserver(forName: .init("com.nemo.MusicInfo.dev.search"),
                                                            object: nil, queue: .main) { [weak self] note in
            let command = note.object as? String ?? "open"
            MainActor.assumeIsolated {
                guard let self else { return }
                if command == "close" { self.songSearch.close() }
                else if command.hasPrefix("hover:") { self.widget.devSetHover(command == "hover:1") }
                else if command.hasPrefix("query:") { self.songSearch.show(query: String(command.dropFirst(6)), takeFocus: false) }
                else { self.songSearch.show(takeFocus: false) }
            }
        }

        // ⌘ + Esc: 화면 전체를 앨범 커버로 (다시 누르거나 Esc·클릭으로 닫기)
        fullscreen = FullscreenCoverController(music: widget.music, lyrics: widget.lyrics)
        hotKey = GlobalHotKey(keyCode: kVK_Escape, modifiers: cmdKey) { [weak self] in
            self?.fullscreen.toggle()
        }

        let menu = NSMenu()
        menu.autoenablesItems = false
        menu.delegate = self               // 열 때마다 현재 상태로 다시 구성
        bar.setMenu(menu)
        bar.onPermissionSuspect = { [weak self] in self?.showPermissionHint() }

        audio.start()
        bar.peek(seconds: 4)               // 실행됐다는 표시로 잠깐 보여 줌

        NSWorkspace.shared.notificationCenter.addObserver(
            self, selector: #selector(systemDidWake(_:)),
            name: NSWorkspace.didWakeNotification, object: nil)
    }

    /// 이미 실행 중일 때 Spotlight·Launchpad·Finder에서 다시 열면 → 숨어 있던 스펙트럼을 꺼내고 메뉴 열기
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        bar.openMenuSoon()
        return false
    }

    func applicationWillTerminate(_ notification: Notification) {
        widget.teardown()
        bar.teardown()
        audio.stop()
    }

    @objc private func systemDidWake(_ notification: Notification) {
        audio.systemDidWake()
    }

    // MARK: - 메뉴

    func menuNeedsUpdate(_ menu: NSMenu) {
        buildMenu(menu)
    }

    func menuWillOpen(_ menu: NSMenu) {
        bar.menuOpen = true
    }

    func menuDidClose(_ menu: NSMenu) {
        bar.menuOpen = false
    }

    private func buildMenu(_ menu: NSMenu) {
        menu.removeAllItems()

        for line in bar.statusLines { menu.addItem(infoItem(line)) }
        menu.addItem(.separator())

        // 스펙트럼 모양
        menu.addItem(choiceMenu("막대 개수", [12, 16, 20, 24, 32].map { ("\($0)개", $0) },
                                current: settings.bandCount, action: #selector(setBands(_:))))
        menu.addItem(choiceMenu("막대 두께", (1...6).map { ("\($0) px", $0) },
                                current: settings.barWidth, action: #selector(setBarWidth(_:))))
        menu.addItem(choiceMenu("막대 간격", (0...3).map { ("\($0) px", $0) },
                                current: settings.barGap, action: #selector(setBarGap(_:))))
        menu.addItem(choiceMenu("막대 모양", [("기본 (살짝 둥글게)", BarShape.rounded.rawValue),
                                             ("알약형", BarShape.pill.rawValue),
                                             ("LED 블록", BarShape.led.rawValue),
                                             ("곡선 웨이브", BarShape.wave.rawValue)],
                                current: settings.barShape.rawValue, action: #selector(setShape(_:))))
        menu.addItem(choiceMenu("배치", [("아래에서 위로", BarStyle.bottom.rawValue), ("가운데 대칭", BarStyle.mirror.rawValue)],
                                current: settings.barStyle.rawValue, action: #selector(setStyle(_:))))

        // 색상: 테마 + 옵션
        let themes: [(String, Int)] = [("단색 (시스템)", ColorMode.mono.rawValue),
                                       ("화이트", ColorMode.white.rawValue),
                                       ("무지개", ColorMode.gradient.rawValue),
                                       ("네온", ColorMode.neon.rawValue),
                                       ("선셋", ColorMode.sunset.rawValue),
                                       ("오션", ColorMode.ocean.rawValue)]
        let colorItem = choiceMenu("색상", themes, current: settings.colorMode.rawValue, action: #selector(setColor(_:)))
        colorItem.submenu?.addItem(.separator())
        colorItem.submenu?.addItem(toggleItem("세로 그라데이션 (끝으로 갈수록 투명)", on: settings.verticalFade,
                                              action: #selector(toggleVerticalFade(_:))))
        colorItem.submenu?.addItem(toggleItem("소리가 클수록 밝게", on: settings.levelColor,
                                              action: #selector(toggleLevelColor(_:))))
        menu.addItem(colorItem)

        // 움직임
        let motion = NSMenu()
        motion.autoenablesItems = false
        motion.addItem(choiceMenu("내려오는 방식", [("일정한 속도", FallMode.linear.rawValue), ("중력 낙하", FallMode.gravity.rawValue)],
                                  current: settings.fallMode.rawValue, action: #selector(setFallMode(_:))))
        motion.addItem(choiceMenu("이웃 막대 부드럽게", [("끔", 0), ("약하게", 1), ("강하게", 2)],
                                  current: settings.smoothing, action: #selector(setSmoothing(_:))))
        motion.addItem(.separator())
        motion.addItem(toggleItem("피크 캡 (떠 있다가 떨어지는 점)", on: settings.peakCaps, action: #selector(togglePeakCaps(_:))))
        motion.addItem(toggleItem("자동 음량 맞춤", on: settings.autoGain, action: #selector(toggleAutoGain(_:))))
        motion.addItem(toggleItem("화면 주사율에 맞춰 그리기 (최대 120Hz)", on: settings.displaySync,
                                  action: #selector(toggleDisplaySync(_:))))
        let motionItem = NSMenuItem(title: "움직임", action: nil, keyEquivalent: "")
        motionItem.submenu = motion
        menu.addItem(motionItem)
        menu.addItem(choiceMenu("감도", [("낮음", -6), ("보통", 0), ("높음", 8)],
                                current: Int(settings.gain), action: #selector(setGain(_:))))
        menu.addItem(.separator())

        // 표시 동작
        menu.addItem(choiceMenu("표시 방식", [("소리가 날 때만", ShowMode.auto.rawValue), ("항상 표시", ShowMode.always.rawValue)],
                                current: settings.showMode.rawValue, action: #selector(setShowMode(_:))))
        menu.addItem(choiceMenu("소리가 멈추면 숨기기", [2, 3, 5, 10].map { ("\($0)초 후", $0) },
                                current: Int(settings.hideDelay), action: #selector(setHideDelay(_:))))
        menu.addItem(toggleItem("재생 중 다른 메뉴바 아이콘 숨기기", on: settings.hideOthers,
                                action: #selector(toggleHideOthers(_:))))
        if bar.usesLengthHiding {
            menu.addItem(toggleItem("펼치기 애니메이션", on: settings.animate, action: #selector(toggleAnimate(_:))))
            menu.addItem(toggleItem("아이콘 배치 모드 (항상 보일 아이콘 지정)", on: bar.arrangeMode,
                                    action: #selector(toggleArrange(_:))))
            menu.addItem(actionItem("메뉴바 위치 초기화", action: #selector(resetPositions)))
        }
        menu.addItem(.separator())

        // 바탕화면 위젯
        let widgetMenu = NSMenu()
        widgetMenu.autoenablesItems = false
        widgetMenu.addItem(toggleItem("위젯 켜기", on: settings.widgetEnabled, action: #selector(toggleWidget(_:))))
        widgetMenu.addItem(choiceMenu("표시", [("재생 중일 때만", 0), ("곡이 있으면 항상 (일시정지 포함)", 1)],
                                      current: settings.widgetShowMode, action: #selector(setWidgetShowMode(_:))))
        widgetMenu.addItem(choiceMenu("크기", DesktopWidgetController.sizeTitles.enumerated().map { ($1, $0) },
                                      current: settings.widgetSize, action: #selector(setWidgetSize(_:))))
        widgetMenu.addItem(toggleItem("기본 글라스 (끄면 더 맑은 Clear 글라스)", on: settings.widgetBackground,
                                      action: #selector(toggleWidgetBackground(_:))))
        widgetMenu.addItem(toggleItem("재생 버튼", on: settings.widgetControls, action: #selector(toggleWidgetControls(_:))))
        widgetMenu.addItem(toggleItem("미니 스펙트럼", on: settings.widgetSpectrum, action: #selector(toggleWidgetSpectrum(_:))))
        widgetMenu.addItem(toggleItem("보일 때 다른 바탕화면 위젯 숨기기", on: settings.widgetHideOthers,
                                      action: #selector(toggleWidgetHideOthers(_:))))
        widgetMenu.addItem(toggleItem("가사 표시 (커버 왼쪽 위)", on: settings.widgetLyrics,
                                      action: #selector(toggleWidgetLyrics(_:))))
        widgetMenu.addItem(toggleItem("다음 곡 표시 (제목 위 오른쪽)", on: settings.widgetUpNext,
                                      action: #selector(toggleWidgetUpNext(_:))))
        if !MusicQueueReader.isTrusted {
            widgetMenu.addItem(actionItem("    ↳ 셔플·대기열까지 정확히: 손쉬운 사용 허용…",
                                          action: #selector(allowQueueReading)))
        }
        widgetMenu.addItem(toggleItem("제목·아티스트 가운데 정렬", on: settings.widgetCenterText,
                                      action: #selector(toggleWidgetCenterText(_:))))
        widgetMenu.addItem(.separator())
        let place = NSMenu()
        place.autoenablesItems = false
        place.addItem(actionItem("직접 옮기기… (15초간 표시, 끌어서 이동)", action: #selector(positionWidget)))
        place.addItem(actionItem("기본 위치로", action: #selector(moveWidgetToDefault)))
        place.addItem(.separator())
        for corner in DesktopWidgetController.Corner.allCases {
            let item = actionItem(corner.title, action: #selector(moveWidget(_:)))
            item.tag = corner.rawValue
            place.addItem(item)
        }
        let placeItem = NSMenuItem(title: "위치", action: nil, keyEquivalent: "")
        placeItem.submenu = place
        widgetMenu.addItem(placeItem)
        widgetMenu.addItem(toggleItem("위치 고정 (끌어서 옮기기 막기)", on: settings.widgetLocked,
                                      action: #selector(toggleWidgetLock(_:))))
        menu.addItem(actionItem("노래 검색  (⌘ 두 번)", action: #selector(toggleSongSearch)))
        menu.addItem(actionItem("전체 화면 앨범 커버  (⌘ Esc)", action: #selector(toggleFullscreenCover)))
        let widgetItem = NSMenuItem(title: "바탕화면 위젯 (지금 재생 중)", action: nil, keyEquivalent: "")
        widgetItem.submenu = widgetMenu
        menu.addItem(widgetItem)
        menu.addItem(.separator())

        // 기타
        menu.addItem(toggleItem("로그인 시 자동 실행", on: SMAppService.mainApp.status == .enabled,
                                action: #selector(toggleLogin(_:))))
        menu.addItem(actionItem("시스템 오디오 권한 설정 열기…", action: #selector(openPrivacySettings)))
        menu.addItem(actionItem("오디오 캡처 다시 시작", action: #selector(restartCapture)))
        menu.addItem(.separator())
        let updates = NSMenuItem(title: "업데이트 확인…",
                                 action: #selector(SPUStandardUpdaterController.checkForUpdates(_:)),
                                 keyEquivalent: "")
        updates.target = updaterController
        menu.addItem(updates)
        menu.addItem(.separator())
        menu.addItem(NSMenuItem(title: "MusicInfo 종료", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q"))
    }

    private func infoItem(_ title: String) -> NSMenuItem {
        let item = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        item.isEnabled = false
        return item
    }

    private func actionItem(_ title: String, action: Selector) -> NSMenuItem {
        let item = NSMenuItem(title: title, action: action, keyEquivalent: "")
        item.target = self
        return item
    }

    private func toggleItem(_ title: String, on: Bool, action: Selector) -> NSMenuItem {
        let item = actionItem(title, action: action)
        item.state = on ? .on : .off
        return item
    }

    /// 하위 메뉴로 선택지 목록 만들기. 상위 항목 제목에 현재 값을 같이 보여 줌
    private func choiceMenu(_ title: String, _ options: [(String, Int)], current: Int, action: Selector) -> NSMenuItem {
        let parent = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        let submenu = NSMenu()
        submenu.autoenablesItems = false
        for (label, value) in options {
            let item = actionItem(label, action: action)
            item.tag = value
            item.state = value == current ? .on : .off
            submenu.addItem(item)
            if value == current { parent.title = "\(title): \(label)" }
        }
        parent.submenu = submenu
        return parent
    }

    // MARK: - 메뉴 동작

    @objc private func setBands(_ sender: NSMenuItem) {
        settings.bandCount = sender.tag
        audio.setBandCount(sender.tag)
        bar.applyAppearance()
    }

    @objc private func setBarWidth(_ sender: NSMenuItem) {
        settings.barWidth = sender.tag
        bar.applyAppearance()
    }

    @objc private func setBarGap(_ sender: NSMenuItem) {
        settings.barGap = sender.tag
        bar.applyAppearance()
    }

    @objc private func setStyle(_ sender: NSMenuItem) {
        settings.barStyle = BarStyle(rawValue: sender.tag) ?? .bottom
        bar.applyAppearance()
    }

    @objc private func setColor(_ sender: NSMenuItem) {
        settings.colorMode = ColorMode(rawValue: sender.tag) ?? .mono
        bar.applyAppearance()
    }

    @objc private func setShape(_ sender: NSMenuItem) {
        settings.barShape = BarShape(rawValue: sender.tag) ?? .pill
        bar.applyAppearance()
    }

    @objc private func toggleVerticalFade(_ sender: NSMenuItem) {
        settings.verticalFade.toggle()
        bar.applyAppearance()
    }

    @objc private func toggleLevelColor(_ sender: NSMenuItem) {
        settings.levelColor.toggle()
        bar.applyAppearance()
    }

    @objc private func setFallMode(_ sender: NSMenuItem) {
        settings.fallMode = FallMode(rawValue: sender.tag) ?? .gravity
    }

    @objc private func setSmoothing(_ sender: NSMenuItem) {
        settings.smoothing = sender.tag
    }

    @objc private func togglePeakCaps(_ sender: NSMenuItem) {
        settings.peakCaps.toggle()
        bar.applyAppearance()
    }

    @objc private func toggleAutoGain(_ sender: NSMenuItem) {
        settings.autoGain.toggle()
    }

    @objc private func toggleDisplaySync(_ sender: NSMenuItem) {
        settings.displaySync.toggle()
        bar.applyAppearance()
    }

    @objc private func toggleWidget(_ sender: NSMenuItem) {
        settings.widgetEnabled.toggle()
    }

    @objc private func setWidgetShowMode(_ sender: NSMenuItem) {
        settings.widgetShowMode = sender.tag
    }

    @objc private func setWidgetSize(_ sender: NSMenuItem) {
        settings.widgetSize = sender.tag
        widget.applyAppearance()
    }

    @objc private func toggleWidgetBackground(_ sender: NSMenuItem) {
        settings.widgetBackground.toggle()
        widget.applyAppearance()
    }

    @objc private func toggleWidgetLock(_ sender: NSMenuItem) {
        settings.widgetLocked.toggle()
        widget.applyAppearance()
    }

    @objc private func toggleWidgetControls(_ sender: NSMenuItem) {
        settings.widgetControls.toggle()
        widget.applyAppearance()
    }

    @objc private func toggleWidgetSpectrum(_ sender: NSMenuItem) {
        settings.widgetSpectrum.toggle()
        widget.applyAppearance()
    }

    @objc private func toggleWidgetHideOthers(_ sender: NSMenuItem) {
        settings.widgetHideOthers.toggle()
        widget.applyAppearance()
    }

    @objc private func toggleWidgetLyrics(_ sender: NSMenuItem) {
        settings.widgetLyrics.toggle()
        widget.applyAppearance()
    }

    @objc private func allowQueueReading() {
        MusicQueueReader.requestTrust()
        MusicQueueReader.openAccessibilitySettings()
    }

    @objc private func toggleWidgetUpNext(_ sender: NSMenuItem) {
        settings.widgetUpNext.toggle()
        widget.applyAppearance()
    }

    @objc private func toggleWidgetCenterText(_ sender: NSMenuItem) {
        settings.widgetCenterText.toggle()
        widget.applyAppearance()
    }

    @objc private func toggleSongSearch() {
        songSearch.toggle()
    }

    @objc private func toggleFullscreenCover() {
        fullscreen.toggle()
    }

    @objc private func moveWidgetToDefault() {
        widget.moveToDefault()
    }

    @objc private func positionWidget() {
        if settings.widgetLocked {
            settings.widgetLocked = false
            widget.applyAppearance()
        }
        widget.showForPositioning()
    }

    @objc private func moveWidget(_ sender: NSMenuItem) {
        if let corner = DesktopWidgetController.Corner(rawValue: sender.tag) { widget.move(to: corner) }
    }

    @objc private func setGain(_ sender: NSMenuItem) {
        settings.gain = Float(sender.tag)
        audio.setGain(Float(sender.tag))
    }

    @objc private func setShowMode(_ sender: NSMenuItem) {
        settings.showMode = ShowMode(rawValue: sender.tag) ?? .auto
    }

    @objc private func setHideDelay(_ sender: NSMenuItem) {
        settings.hideDelay = Double(sender.tag)
    }

    @objc private func toggleHideOthers(_ sender: NSMenuItem) {
        settings.hideOthers.toggle()
    }

    @objc private func toggleAnimate(_ sender: NSMenuItem) {
        settings.animate.toggle()
    }

    @objc private func toggleArrange(_ sender: NSMenuItem) {
        let on = !bar.arrangeMode
        bar.setArrangeMode(on)
        if on { showArrangeHelp() }
    }

    @objc private func resetPositions() {
        bar.resetPositions()
    }

    @objc private func toggleLogin(_ sender: NSMenuItem) {
        do {
            if SMAppService.mainApp.status == .enabled {
                try SMAppService.mainApp.unregister()
            } else {
                try SMAppService.mainApp.register()
            }
        } catch {
            showAlert(title: "자동 실행 설정 실패", text: error.localizedDescription)
        }
    }

    @objc private func openPrivacySettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc private func restartCapture() {
        audio.restartCapture()
    }

    // MARK: - 안내 창

    private func showPermissionHint() {
        // 같은 빌드에서는 한 번만 안내
        let build = (Bundle.main.infoDictionary?["CFBundleVersion"] as? String) ?? "0"
        guard settings.permissionHintVersion != build else { return }
        settings.permissionHintVersion = build

        NSApp.activate()
        let alert = NSAlert()
        alert.messageText = "시스템 오디오가 들어오지 않습니다"
        alert.informativeText = """
        다른 앱이 소리를 내고 있는데 MusicInfo에는 무음만 들어오고 있습니다.

        시스템 설정 › 개인정보 보호 및 보안 › 화면 및 시스템 오디오 녹음 › \
        '시스템 오디오 녹음만'에서 MusicInfo를 켠 뒤, 메뉴의 '오디오 캡처 다시 시작'을 눌러 주세요.

        (실제로 무음을 재생하는 앱이 있는 경우라면 무시해도 됩니다.)
        """
        alert.addButton(withTitle: "설정 열기")
        alert.addButton(withTitle: "닫기")
        if alert.runModal() == .alertFirstButtonReturn {
            openPrivacySettings()
        }
    }

    private func showArrangeHelp() {
        NSApp.activate()
        let alert = NSAlert()
        alert.messageText = "아이콘 배치 모드"
        alert.informativeText = """
        메뉴바에 점선 구분선이 나타났습니다.

        • ⌘(Command) 키를 누른 채 아이콘을 끌어 점선 오른쪽(스펙트럼 쪽)에 두면, 음악 재생 중에도 항상 보입니다.
        • 점선 왼쪽에 있는 아이콘은 음악 재생 중 숨겨집니다.

        다 옮겼으면 메뉴에서 '아이콘 배치 모드'를 다시 눌러 끄세요.
        """
        alert.runModal()
    }

    private func showAlert(title: String, text: String) {
        NSApp.activate()
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = text
        alert.runModal()
    }
}
