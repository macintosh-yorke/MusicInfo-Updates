import Cocoa
import CoreImage

// MARK: - 보관함 노래

struct LibraryTrack: Equatable {
    let title: String
    let artist: String
    let album: String
    let persistentID: String
    let genre: String
    let playCount: Int
    /// 검색용: 소문자·악센트 제거한 문자열과 한글 초성
    let searchTitle: String
    let searchOther: String
    let initials: String

    init(title: String, artist: String, album: String, persistentID: String, genre: String = "", playCount: Int = 0) {
        self.title = title
        self.artist = artist
        self.album = album
        self.persistentID = persistentID
        self.genre = genre
        self.playCount = playCount
        searchTitle = SongSearch.normalize(title)
        searchOther = SongSearch.normalize(artist + " " + album + " " + genre)
        initials = SongSearch.initials(title + " " + artist)
    }
}

enum SongSearch {
    static func normalize(_ s: String) -> String {
        s.folding(options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive], locale: nil)
    }

    private static let choseong: [Character] = ["ㄱ", "ㄲ", "ㄴ", "ㄷ", "ㄸ", "ㄹ", "ㅁ", "ㅂ", "ㅃ", "ㅅ",
                                                "ㅆ", "ㅇ", "ㅈ", "ㅉ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]

    /// 한글은 초성만, 나머지 글자는 그대로 (공백 제거) — "행복한 나를" → "ㅎㅂㅎㄴㄹ"
    static func initials(_ s: String) -> String {
        var out = ""
        for scalar in s.unicodeScalars {
            let v = scalar.value
            if (0xAC00...0xD7A3).contains(v) {
                out.append(choseong[Int((v - 0xAC00) / 588)])
            } else if !CharacterSet.whitespaces.contains(scalar) {
                out.unicodeScalars.append(scalar)
            }
        }
        return normalize(out)
    }

    static func isInitialsQuery(_ q: String) -> Bool {
        !q.isEmpty && q.unicodeScalars.allSatisfy { (0x3131...0x314E).contains($0.value) || $0 == " " }
    }

    /// 점수 높은 순 (같으면 많이 들은 순)
    static func search(_ query: String, in tracks: [LibraryTrack], limit: Int = 60) -> [LibraryTrack] {
        let q = normalize(query.trimmingCharacters(in: .whitespaces))
        guard !q.isEmpty else { return [] }
        let words = q.split(separator: " ").map(String.init)
        let initialsQuery = isInitialsQuery(query) ? q.replacingOccurrences(of: " ", with: "") : nil
        var scored: [(Int, LibraryTrack)] = []
        for track in tracks {
            var score = 0
            if track.searchTitle == q { score = 100 }
            else if track.searchTitle.hasPrefix(q) { score = 80 }
            else if track.searchTitle.contains(q) { score = 60 }
            else if words.allSatisfy({ track.searchTitle.contains($0) || track.searchOther.contains($0) }) {
                score = track.searchOther.contains(q) ? 45 : 35
            } else if let iq = initialsQuery, track.initials.contains(iq) {
                score = track.initials.hasPrefix(iq) ? 30 : 20
            }
            if score > 0 { scored.append((score, track)) }
        }
        scored.sort { $0.0 != $1.0 ? $0.0 > $1.0 : $0.1.playCount > $1.1.playCount }
        return scored.prefix(limit).map(\.1)
    }

    // MARK: 추천

    /// 장르 비슷한 정도: 같으면 2, 단어가 겹치면 1 ("K-Pop" ↔ "Pop", "Hip-Hop/Rap" ↔ "Rap")
    static func genreAffinity(_ a: String, _ b: String) -> Int {
        let x = normalize(a), y = normalize(b)
        guard !x.isEmpty, !y.isEmpty else { return 0 }
        if x == y { return 2 }
        let separators = CharacterSet(charactersIn: " /&-,·")
        let tx = Set(x.components(separatedBy: separators).filter { $0.count >= 2 })
        let ty = Set(y.components(separatedBy: separators).filter { $0.count >= 2 })
        return tx.isDisjoint(with: ty) ? 0 : 1
    }

    /// 검색어가 없을 때 보여 줄 추천: (지금 곡과 비슷한 장르, 많이 들은 노래)
    static func recommendations(for current: NowPlaying?, in tracks: [LibraryTrack],
                                similarCount: Int = 8, topCount: Int = 12)
        -> (genre: String, similar: [LibraryTrack], top: [LibraryTrack]) {
        let currentEntry = current.flatMap { now in
            tracks.first { $0.title == now.title && $0.artist == now.artist }
                ?? tracks.first { $0.title == now.title }
        }
        let genre = currentEntry?.genre ?? ""
        let artist = currentEntry?.artist ?? current?.artist ?? ""
        let currentID = currentEntry?.persistentID

        var similar: [LibraryTrack] = []
        if !genre.isEmpty || !artist.isEmpty {
            var scored: [(Double, LibraryTrack)] = []
            for track in tracks where track.persistentID != currentID {
                let affinity = genreAffinity(genre, track.genre)
                let sameArtist = !artist.isEmpty && track.artist == artist
                guard affinity > 0 || sameArtist else { continue }
                // 장르가 같을수록, 같은 가수면 더, 그 안에서는 많이 들은 순
                let score = Double(affinity) * 1000 + (sameArtist ? 600 : 0) + Double(min(track.playCount, 999))
                scored.append((score, track))
            }
            scored.sort { $0.0 > $1.0 }
            // 한 가수가 목록을 다 차지하지 않게 가수당 최대 2곡
            var perArtist: [String: Int] = [:]
            for (_, track) in scored where similar.count < similarCount {
                let n = perArtist[track.artist, default: 0]
                guard n < 2 else { continue }
                perArtist[track.artist] = n + 1
                similar.append(track)
            }
        }
        let shown = Set(similar.map(\.persistentID) + [currentID].compactMap { $0 })
        // 많이 들은 노래 = 10번 이상 들은 곡 중에서 무작위로 (열 때마다 섞임)
        let top = tracks.filter { $0.playCount >= 10 && !shown.contains($0.persistentID) }
            .shuffled()
            .prefix(topCount)
        return (genre, similar, Array(top))
    }
}

// MARK: - ⌘ 두 번 누르기 감지

/// Command 키만 짧게 두 번 연속 누르면 실행 (다른 키와 같이 누르면 무시)
/// 다른 앱을 쓰는 중에도 감지하려면 손쉬운 사용 권한이 필요
@MainActor
final class DoubleCommandDetector {
    private var monitors: [Any] = []
    private var commandDown = false
    private var downAt: TimeInterval = 0
    private var dirty = false            // 누르는 동안 다른 키를 눌렀는지
    private var lastTapAt: TimeInterval = 0
    private let action: @MainActor () -> Void

    init(action: @escaping @MainActor () -> Void) {
        self.action = action
        let handler: (NSEvent) -> Void = { [weak self] event in
            MainActor.assumeIsolated { self?.handle(event) }
        }
        if let global = NSEvent.addGlobalMonitorForEvents(matching: [.flagsChanged, .keyDown], handler: handler) {
            monitors.append(global)
        }
        if let local = NSEvent.addLocalMonitorForEvents(matching: [.flagsChanged, .keyDown], handler: { event in
            handler(event)
            return event
        }) {
            monitors.append(local)
        }
    }

    private func handle(_ event: NSEvent) {
        let now = monotonicNow()
        if event.type == .keyDown {
            dirty = true
            lastTapAt = 0
            return
        }
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
            .subtracting([.capsLock, .numericPad, .function])
        let isCommandKey = event.keyCode == 55 || event.keyCode == 54
        if isCommandKey, flags == .command {
            commandDown = true
            downAt = now
            dirty = false
        } else if isCommandKey, !flags.contains(.command), commandDown {
            commandDown = false
            guard !dirty, now - downAt < 0.35 else {
                lastTapAt = 0
                return
            }
            if lastTapAt > 0, now - lastTapAt < 0.45 {
                lastTapAt = 0
                action()
            } else {
                lastTapAt = now
            }
        } else {
            // 다른 보조키 조합
            dirty = true
            lastTapAt = 0
        }
    }
}

// MARK: - 노래 검색 창

/// Spotlight처럼 화면 위쪽에 뜨는 보관함 노래 검색 창.
/// 검색어가 없으면: 지금 곡과 비슷한 장르 + 많이 들은 노래 추천
/// ↩ 재생 · ⌘↩ 바로 다음에 재생 · ⌥↩ 대기열에 추가 · ⌘L 플레이리스트에 추가 · esc 닫기
@MainActor
final class SongSearchController: NSObject, NSTextFieldDelegate, NSTableViewDataSource, NSTableViewDelegate {
    private enum Row {
        case header(String, String)          // 제목, 오른쪽 작은 글씨
        case track(LibraryTrack, rank: Int?) // rank: 많이 들은 순위
        case carousel([LibraryTrack])        // 가로로 넘기는 커버 카드 (추천)
    }

    private let music: MusicBridge
    private var panel: SearchPanel?
    private let field = NSTextField()
    private let searchIcon = NSImageView()
    private let nowPlayingChip = NSTextField(labelWithString: "")
    private let divider = NSBox()
    private let table = NSTableView()
    private let scroll = NSScrollView()
    private let footer = NSStackView()
    private let status = NSTextField(labelWithString: "")
    private let credit = NSTextField(labelWithString: "@yorke.om")
    private let toast = NSTextField(labelWithString: "")
    private var keyMonitor: Any?
    private var library: [LibraryTrack] = []
    private var libraryLoadedAt: TimeInterval = -1000
    private var rows: [Row] = []
    private var previousApp: NSRunningApplication?
    // 옆 창: 지금 재생 중 + 다음 재생 목록
    private var sidePanel: SidePanel?
    private var queueObserver: NSObjectProtocol?
    private let mainBackground = PanelBackgroundView()
    private let sideBackground = PanelBackgroundView(backdropFraction: 0.5)
    private let sideView = QueueSideView()
    private let sideWidth: CGFloat = 300
    private let sideGap: CGFloat = 12
    private let sideHeight: CGFloat = 520

    // 썸네일: 보이는 행만 하나씩 천천히 읽어 옴 (입력이 끊기지 않게)
    private var artCache: [String: NSImage] = [:]
    private var artMissing: Set<String> = []
    private var artQueue: [String] = []
    private var artLoading = false

    private let width: CGFloat = 720
    private let fieldHeight: CGFloat = 78
    private let carouselHeight: CGFloat = 188
    private let searchPill = NSView()
    private var menuTrack: LibraryTrack?        // 카드에서 오른쪽 클릭한 곡
    private let rowHeight: CGFloat = 54
    private let headerHeight: CGFloat = 32
    private let maxListHeight: CGFloat = 430
    private let footerHeight: CGFloat = 38
    static let radius: CGFloat = 26
    /// 검색 창·옆 창·위젯·스펙트럼이 모두 같은 속도·같은 곡선으로 움직이게
    static let openDuration: TimeInterval = 0.36
    static let closeDuration: TimeInterval = 0.3
    static let timing = CAMediaTimingFunction(controlPoints: 0.65, 0, 0.35, 1)   // easeInOutCubic과 같은 곡선

    private weak var widget: DesktopWidgetController?
    // 검색 창 위: 크게 그린 음악 스펙트럼
    private var spectrumPanel: NSPanel?
    private let bigSpectrum = SpectrumView()
    private let spectrumBackground = PanelBackgroundView()
    private let spectrumHeight: CGFloat = 54
    private let widgetGap: CGFloat = 12

    private weak var menuBar: MenuBarController?

    init(music: MusicBridge, widget: DesktopWidgetController? = nil, menuBar: MenuBarController? = nil) {
        self.music = music
        self.widget = widget
        self.menuBar = menuBar
        super.init()
    }

    var isVisible: Bool { panel?.isVisible ?? false }

    func toggle() {
        isVisible && !isClosing ? close() : show()
    }

    /// 보관함 노래 목록 읽기 (앱 시작 직후 미리 한 번 → 검색 창이 바로 열리게)
    func reloadLibrary() {
        guard music.isMusicRunning, let tracks = music.libraryTracks() else { return }
        library = tracks
        libraryLoadedAt = monotonicNow()
    }

    // MARK: 열기 / 닫기

    func show(query: String = "", takeFocus: Bool = true) {
        guard music.isMusicRunning else {
            NSSound.beep()
            return
        }
        // 이미 열려 있으면 입력칸만 다시 잡음
        if let panel, panel.isVisible, !isClosing {
            if takeFocus {
                panel.makeKeyAndOrderFront(nil)
                panel.makeFirstResponder(field)
            }
            return
        }
        // 닫히는 중에 다시 열면: 닫기를 멈추고 그 자리에서 다시 나타남
        isClosing = false
        if NSWorkspace.shared.frontmostApplication?.bundleIdentifier != Bundle.main.bundleIdentifier {
            previousApp = NSWorkspace.shared.frontmostApplication
        }
        let panel = self.panel ?? makePanel()
        self.panel = panel
        if library.isEmpty { reloadLibrary() }      // 처음 한 번만 여기서 (보통은 앱 시작 때 미리 읽어 둠)
        field.stringValue = ""
        toast.alphaValue = 0
        applyTheme()
        updateNowPlayingChip()
        field.stringValue = query
        updateRows()

        let mouse = NSEvent.mouseLocation
        let screen = NSScreen.screens.first { $0.frame.contains(mouse) } ?? NSScreen.main ?? NSScreen.screens[0]
        let frame = screen.visibleFrame
        let height = panelHeight()
        // [바탕화면 위젯] + 검색 창 + 옆 창을 한 덩어리로 화면 가운데에, 위에는 큰 스펙트럼
        let widgetWidth = widget?.attachableWidth ?? 0
        let leftWidth = widgetWidth > 0 ? widgetWidth + widgetGap : 0
        let groupWidth = leftWidth + width + sideGap + sideWidth
        let top = min(frame.maxY - frame.height * 0.16, frame.maxY - spectrumHeight - 24)
        let origin = NSPoint(x: frame.midX - groupWidth / 2 + leftWidth, y: top - height)
        panel.setFrame(NSRect(origin: origin, size: NSSize(width: width, height: height)), display: true)
        layoutContent()
        prepareSidePanel(parent: panel)
        prepareSpectrumPanel()

        // ── 모든 창(검색 창·옆 창·위젯·스펙트럼·아래 카드)이 같은 순간에 같은 방식으로 나타남 ──
        //    제자리에서 살짝 아래 → 위로 떠오르며 서서히 보임
        let panelFrame = panel.frame
        var widgetTarget: NSRect?
        if let widget, let target = widget.attachTarget(leftOf: panelFrame, gap: widgetGap) {
            let start = widget.beginAttach()
            widgetWasHidden = start.wasHidden
            widgetTarget = target
            widget.setAttachState(frame: target, alpha: 0)
            prepareControlsCard(below: target, bottom: panelFrame.minY)
        } else {
            controlsPanel?.orderOut(nil)
        }
        let spectrumTarget = NSRect(x: panelFrame.minX, y: panelFrame.maxY + 10, width: panelFrame.width, height: spectrumHeight)
        menuBar?.setSpectrumBorrowed(true, animated: false)     // 메뉴바 쪽은 숨기고 검색 창 위에만
        setSpectrumFrame(spectrumTarget, progress: 1)
        spectrumPanel?.alphaValue = 0
        spectrumPanel?.orderFront(nil)

        panel.alphaValue = 0
        if takeFocus {
            panel.makeKeyAndOrderFront(nil)
            panel.makeFirstResponder(field)
        } else {
            panel.orderFront(nil)          // 미리보기: 키 입력은 가져오지 않음
        }
        installKeyMonitor()

        let windows = appearingWindows(widgetTarget: widgetTarget)
        runGroup(duration: SongSearchController.openDuration, step: { [weak self] e in
            self?.applyAppear(windows, progress: e)
        }, done: { [weak self] in
            // 무거운 일(썸네일·대기 목록·보관함 새로 읽기)은 나타나기가 끝난 뒤에 → 애니메이션이 끊기지 않게
            guard let self else { return }
            self.requestVisibleArtwork()
            self.loadQueue()
            if monotonicNow() - self.libraryLoadedAt > 600 {
                self.reloadLibrary()
                if self.field.stringValue.isEmpty { self.updateRows() }
            }
        })
    }

    private typealias Appearing = (window: NSWindow?, frame: NSRect, isWidget: Bool)
    private let rise: CGFloat = 14

    /// 같이 나타나고 사라질 창들과 각자의 최종 자리
    private func appearingWindows(widgetTarget: NSRect?) -> [Appearing] {
        var list: [Appearing] = []
        if let panel { list.append((panel, panel.frame, false)) }
        if let sidePanel { list.append((sidePanel, sidePanel.frame, false)) }
        if let spectrumPanel { list.append((spectrumPanel, spectrumPanel.frame, false)) }
        if let controlsPanel, controlsPanel.isVisible { list.append((controlsPanel, controlsPanel.frame, false)) }
        if let widgetTarget { list.append((nil, widgetTarget, true)) }
        return list
    }

    /// progress 0 = 살짝 아래·투명 → 1 = 제자리·불투명
    private func applyAppear(_ windows: [Appearing], progress e: CGFloat) {
        for item in windows {
            let frame = item.frame.offsetBy(dx: 0, dy: -rise * (1 - e))
            if item.isWidget {
                widget?.setAttachState(frame: frame, alpha: e)
            } else if let w = item.window {
                // 검색 창의 옆 창은 자식 창이라 같이 움직이므로 위치는 부모만
                if w !== sidePanel { w.setFrameOrigin(frame.origin) }
                w.alphaValue = e
            }
        }
    }

    func close(restoreFocus: Bool = true) {
        guard let panel, panel.isVisible, !isClosing else { return }
        isClosing = true
        if let keyMonitor { NSEvent.removeMonitor(keyMonitor) }
        keyMonitor = nil
        artQueue.removeAll()
        controlsTimer?.invalidate()
        controlsTimer = nil
        let widgetFrame = (widget?.isAttached ?? false) ? widget?.currentFrame : nil
        let windows = appearingWindows(widgetTarget: widgetFrame)

        runGroup(duration: SongSearchController.closeDuration, step: { [weak self] e in
            self?.applyAppear(windows, progress: 1 - e)
        }, done: { [weak self] in
            guard let self else { return }
            if let side = self.sidePanel { panel.removeChildWindow(side); side.orderOut(nil) }
            self.controlsPanel?.orderOut(nil)
            self.spectrumPanel?.orderOut(nil)
            panel.orderOut(nil)
            // 위젯은 보이지 않는 채로 바탕화면 자리로 돌아간 뒤, 원래 보이던 위젯이면 거기서 다시 나타남
            self.widget?.finishDetach()
            self.menuBar?.setSpectrumBorrowed(false)
            self.isClosing = false
        })
        if restoreFocus, let previousApp, previousApp.bundleIdentifier != Bundle.main.bundleIdentifier {
            previousApp.activate()
        }
    }

    // MARK: 한꺼번에 움직이기 (화면 주사율에 맞춘 한 개의 시계로 모든 창을 같이 그림)

    private var groupLink: CADisplayLink?
    private var groupStart: CFTimeInterval = 0
    private var groupDuration: CFTimeInterval = 0
    private var groupStep: ((CGFloat) -> Void)?
    private var groupDone: (() -> Void)?
    private var isClosing = false
    private var widgetWasHidden = false

    private func runGroup(duration: TimeInterval, step: @escaping (CGFloat) -> Void, done: @escaping () -> Void) {
        groupLink?.invalidate()
        groupStep = step
        groupDone = done
        groupDuration = duration
        groupStart = CACurrentMediaTime()
        step(0)
        let link = mainBackground.displayLink(target: self, selector: #selector(groupTick(_:)))
        link.add(to: .main, forMode: .common)
        groupLink = link
    }

    @objc private func groupTick(_ link: CADisplayLink) {
        // 다음 화면 갱신 시각 기준으로 계산 → 프레임이 밀려도 위치가 늦지 않음
        let now = max(CACurrentMediaTime(), link.targetTimestamp)
        let t = min(1, (now - groupStart) / groupDuration)
        let e = CGFloat(t < 0.5 ? 4 * t * t * t : 1 - pow(-2 * t + 2, 3) / 2)   // easeInOutCubic
        groupStep?(e)
        if t >= 1 {
            link.invalidate()
            groupLink = nil
            let done = groupDone
            groupStep = nil
            groupDone = nil
            done?()
        }
    }

    private static func lerp(_ a: NSRect, _ b: NSRect, _ e: CGFloat) -> NSRect {
        NSRect(x: a.minX + (b.minX - a.minX) * e, y: a.minY + (b.minY - a.minY) * e,
               width: a.width + (b.width - a.width) * e, height: a.height + (b.height - a.height) * e)
    }

    // MARK: 재생 설정 카드 (검색 창 왼쪽, 앨범 위젯 아래 빈자리)

    private var controlsPanel: NSPanel?
    private let controlsView = PlaybackControlsView()
    private let controlsBackground = PanelBackgroundView()
    private var controlsTimer: Timer?

    private func prepareControlsCard(below widgetFrame: NSRect, bottom: CGFloat) {
        let height = widgetFrame.minY - widgetGap - bottom
        guard height >= 96 else { controlsPanel?.orderOut(nil); return }
        let panel = controlsPanel ?? {
            let p = SidePanel(contentRect: .zero, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
            p.level = .floating
            p.isOpaque = false
            p.backgroundColor = .clear
            p.hasShadow = true
            p.appearance = NSAppearance(named: .darkAqua)
            p.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .transient]
            let root = NSView()
            root.wantsLayer = true
            controlsBackground.autoresizingMask = [.width, .height]
            root.addSubview(controlsBackground)
            controlsView.autoresizingMask = [.width, .height]
            root.addSubview(controlsView)
            p.contentView = root
            return p
        }()
        controlsPanel = panel
        panel.setFrame(NSRect(x: widgetFrame.minX, y: bottom, width: widgetFrame.width, height: height), display: true)
        controlsBackground.frame = panel.contentView?.bounds ?? .zero
        controlsView.frame = panel.contentView?.bounds ?? .zero
        controlsBackground.tint = mainBackground.tint

        controlsView.onShuffle = { [weak self] on in self?.music.setShuffle(on); self?.refreshControls() }
        controlsView.onRepeat = { [weak self] mode in
            guard let self else { return }
            _ = self.music.cycleRepeat(from: mode)
            self.refreshControls()
        }
        controlsView.onVolume = { [weak self] v in self?.music.setVolume(v) }
        controlsView.onFavorite = { [weak self] on in self?.music.setFavorited(on); self?.refreshControls() }
        refreshControls()
        panel.alphaValue = 0
        panel.orderFront(nil)
        // 음악 앱에서 바꾼 것도 따라가도록 1초마다 확인
        controlsTimer?.invalidate()
        let t = Timer(timeInterval: 1, repeats: true) { [weak self] _ in
            MainActor.assumeIsolated { self?.refreshControls() }
        }
        RunLoop.main.add(t, forMode: .common)
        controlsTimer = t
    }

    private var sideShownArtwork: NSImage?
    private var sideShownTitle: String?

    private func refreshControls() {
        // 옆 창의 '지금 재생 중'도 곡·커버가 바뀌면 갱신
        if music.artwork !== sideShownArtwork || music.track?.title != sideShownTitle {
            sideShownArtwork = music.artwork
            sideShownTitle = music.track?.title
            sideView.setNowPlaying(music.track, artwork: music.artwork, playing: music.isPlaying)
        }
        guard groupLink == nil || controlsView.options == nil else { return }   // 나타나는 중엔 건너뜀 (끊김 방지)
        if let options = music.playbackOptions() { controlsView.options = options }
    }

    // MARK: 화면 구성

    private func makePanel() -> SearchPanel {
        let panel = SearchPanel(contentRect: NSRect(x: 0, y: 0, width: width, height: fieldHeight),
                                styleMask: [.borderless, .nonactivatingPanel],
                                backing: .buffered, defer: false)
        panel.level = .floating
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = true
        panel.hidesOnDeactivate = false
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .transient]
        panel.onResignKey = { [weak self] in self?.close(restoreFocus: false) }

        panel.appearance = NSAppearance(named: .darkAqua)
        let root = NSView()
        root.wantsLayer = true
        mainBackground.autoresizingMask = [.width, .height]
        root.addSubview(mainBackground)
        let content = NSView()
        content.autoresizingMask = [.width, .height]
        root.addSubview(content)

        // 검색칸: 둥근 알약 모양 칸 안에 아이콘·입력·지금 곡
        searchPill.wantsLayer = true
        searchPill.layer?.backgroundColor = NSColor.white.withAlphaComponent(0.075).cgColor
        searchPill.layer?.cornerRadius = 15
        searchPill.layer?.borderWidth = 1
        searchPill.layer?.borderColor = NSColor.white.withAlphaComponent(0.07).cgColor
        content.addSubview(searchPill)
        searchIcon.image = NSImage(systemSymbolName: "magnifyingglass", accessibilityDescription: nil)
        searchIcon.symbolConfiguration = .init(pointSize: 21, weight: .semibold)
        searchIcon.contentTintColor = .secondaryLabelColor
        content.addSubview(searchIcon)

        field.isBordered = false
        field.drawsBackground = false
        field.focusRingType = .none
        field.font = .systemFont(ofSize: 24, weight: .regular)
        field.placeholderAttributedString = NSAttributedString(string: "노래, 가수, 앨범 검색", attributes: [
            .font: NSFont.systemFont(ofSize: 24, weight: .regular),
            .foregroundColor: NSColor.tertiaryLabelColor])
        field.delegate = self
        field.cell?.usesSingleLineMode = true
        field.cell?.isScrollable = true
        content.addSubview(field)

        // 오른쪽: 지금 재생 중 칩
        nowPlayingChip.font = .systemFont(ofSize: 11.5, weight: .semibold)
        nowPlayingChip.textColor = .secondaryLabelColor
        nowPlayingChip.alignment = .right
        nowPlayingChip.lineBreakMode = .byTruncatingTail
        content.addSubview(nowPlayingChip)

        divider.boxType = .separator
        content.addSubview(divider)

        // 결과 목록
        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("song"))
        table.addTableColumn(column)
        table.headerView = nil
        table.intercellSpacing = NSSize(width: 0, height: 0)
        table.backgroundColor = .clear
        table.style = .plain
        table.selectionHighlightStyle = .regular
        table.usesAutomaticRowHeights = false
        table.dataSource = self
        table.delegate = self
        table.target = self
        table.doubleAction = #selector(doubleClicked)
        table.menu = NSMenu()
        table.menu?.delegate = self
        scroll.documentView = table
        scroll.drawsBackground = false
        scroll.hasVerticalScroller = true
        scroll.autohidesScrollers = true
        scroll.scrollerStyle = .overlay
        scroll.borderType = .noBorder
        scroll.contentView.postsBoundsChangedNotifications = true
        NotificationCenter.default.addObserver(self, selector: #selector(scrolled),
                                               name: NSView.boundsDidChangeNotification, object: scroll.contentView)
        content.addSubview(scroll)

        // 아래: 단축키 안내 (키캡 모양)
        footer.orientation = .horizontal
        footer.spacing = 14
        footer.alignment = .centerY
        for (keys, text) in [("↩", "재생"), ("⌘ ↩", "바로 다음에"), ("⌥ ↩", "대기열에 추가"), ("⌘ L", "플레이리스트"), ("esc", "닫기")] {
            footer.addArrangedSubview(Self.hintView(keys: keys, text: text))
        }
        content.addSubview(footer)

        status.font = .systemFont(ofSize: 11, weight: .medium)
        status.textColor = .tertiaryLabelColor
        status.alignment = .right
        content.addSubview(status)

        credit.font = .systemFont(ofSize: 11, weight: .medium)
        credit.textColor = .tertiaryLabelColor
        credit.alignment = .right
        content.addSubview(credit)

        // 동작 알림 (예: '○○'에 추가함)
        toast.font = .systemFont(ofSize: 12, weight: .semibold)
        toast.textColor = .white
        toast.alignment = .center
        toast.wantsLayer = true
        toast.drawsBackground = false
        toast.layer?.backgroundColor = NSColor.black.withAlphaComponent(0.65).cgColor
        toast.layer?.cornerRadius = 11
        toast.alphaValue = 0
        content.addSubview(toast)

        panel.contentView = root
        return panel
    }

    // MARK: 옆 창

    private func prepareSidePanel(parent: NSPanel) {
        let side = sidePanel ?? makeSidePanel()
        sidePanel = side
        side.setFrame(sideFrame(for: parent.frame), display: true)
        sideView.setNowPlaying(music.track, artwork: music.artwork, playing: music.isPlaying)
        // 다음 곡: 위젯이 이미 읽어 둔 것으로 먼저 채우고, 움직임이 끝난 뒤 더 많이 다시 읽음
        // 읽어 둔 목록으로 바로 채움 (나타나는 순간부터 보이게)
        let cached = music.queue.prefix(12).map { (title: $0.title, subtitle: $0.subtitle) }
        sideView.setQueue(Array(cached), total: music.queueTotal)
        side.alphaValue = 0
        parent.addChildWindow(side, ordered: .above)
        side.orderFront(nil)
    }

    // MARK: 큰 스펙트럼 (검색 창 위)

    private func prepareSpectrumPanel() {
        guard spectrumPanel == nil else {
            spectrumBackground.tint = mainBackground.tint
            return
        }
        let p = NSPanel(contentRect: .zero, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        p.level = .floating
        p.isOpaque = false
        p.backgroundColor = .clear
        p.hasShadow = true
        p.ignoresMouseEvents = true
        p.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .transient]
        bigSpectrum.wantsLayer = true
        // 검색 창과 같은 진한 배경 위에 막대 (밝은 화면에서도 잘 보이게)
        let root = NSView()
        root.wantsLayer = true
        root.addSubview(spectrumBackground)
        root.addSubview(bigSpectrum)
        p.contentView = root
        spectrumPanel = p
        spectrumBackground.tint = mainBackground.tint
    }

    /// progress 0 = 메뉴바 모양(배경 없음, 작은 막대) → 1 = 검색 창 위 모양
    private func setSpectrumFrame(_ frame: NSRect, progress: CGFloat) {
        guard let panel = spectrumPanel else { return }
        panel.setFrame(frame, display: false)
        spectrumBackground.frame = panel.contentView?.bounds ?? .zero
        spectrumBackground.alphaValue = progress
        let pad = 22 * progress, vpad = 14 * progress
        bigSpectrum.frame = NSRect(x: pad, y: vpad, width: frame.width - pad * 2, height: frame.height - vpad * 2)

        let settings = Settings.shared
        let n = max(1, settings.bandCount)
        let smallGap = CGFloat(settings.barGap)
        let bigGap: CGFloat = n > 48 ? 4 : 7
        let gap = smallGap + (bigGap - smallGap) * progress
        var look = SpectrumLook()
        look.shape = settings.barShape
        look.style = settings.barStyle
        look.colorMode = settings.colorMode
        look.barGap = gap
        look.barWidth = max(1, (bigSpectrum.frame.width - SpectrumView.hPadding * 2 - CGFloat(n - 1) * gap) / CGFloat(n))
        look.verticalFade = settings.verticalFade
        look.levelColor = settings.levelColor
        look.peakCaps = settings.peakCaps
        bigSpectrum.look = look
        bigSpectrum.needsDisplay = true
    }

    /// 메뉴바 스펙트럼과 같은 값으로 매 프레임 갱신
    func updateSpectrum(levels: [CGFloat], peaks: [CGFloat]) {
        guard let spectrumPanel, spectrumPanel.isVisible else { return }
        bigSpectrum.update(levels: levels, peaks: peaks)
    }

    /// 옆 창: 검색 창 오른쪽, 위쪽을 맞추고 높이도 같게 (너무 낮으면 최소 높이)
    private func sideFrame(for main: NSRect) -> NSRect {
        let h = max(main.height, sideHeight)
        return NSRect(x: main.maxX + sideGap, y: main.maxY - h, width: sideWidth, height: h)
    }

    /// 다음 곡: 음악 앱에서 매번 읽지 않고, 한 번 읽어 둔 목록(MusicBridge.queue)을 그대로 씀
    private func loadQueue() {
        guard MusicQueueReader.isTrusted else {
            sideView.setQueue(nil, total: 0)
            sideView.guideMode = .permission
            waitForTrust()
            return
        }
        if music.queue.isEmpty && music.queueStatus != .noTable {
            music.reloadQueue()          // 아직 한 번도 못 읽었으면 그때만
        }
        showCachedQueue()
        if queueObserver == nil {
            queueObserver = NotificationCenter.default.addObserver(forName: MusicBridge.queueChanged, object: nil, queue: .main) { [weak self] _ in
                MainActor.assumeIsolated {
                    guard let self, self.isVisible else { return }
                    self.showCachedQueue()
                }
            }
        }
    }

    private func showCachedQueue() {
        if music.queue.isEmpty && music.queueStatus == .noTable {
            sideView.setQueue(nil, total: 0)
            sideView.guideMode = .panelClosed
            return
        }
        sideView.guideMode = .none
        sideView.staleHint = music.queueStatus == .minimized
        let entries = music.queue.prefix(12).map { (title: $0.title, subtitle: $0.subtitle) }
        sideView.setQueue(Array(entries), total: music.queueTotal)
    }

    /// 권한을 켜면 바로 목록을 읽도록 1초마다 확인 (창이 열려 있는 동안만)
    private func waitForTrust() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in
            MainActor.assumeIsolated {
                guard let self, self.isVisible, self.sideView.showsPermissionGuide else { return }
                if MusicQueueReader.isTrusted { self.loadQueue() } else { self.waitForTrust() }
            }
        }
    }

    private func makeSidePanel() -> SidePanel {
        let side = SidePanel(contentRect: NSRect(x: 0, y: 0, width: sideWidth, height: sideHeight),
                             styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        side.level = .floating
        side.isOpaque = false
        side.backgroundColor = .clear
        side.hasShadow = true
        side.hidesOnDeactivate = false
        side.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .transient]
        side.appearance = NSAppearance(named: .darkAqua)
        let root = NSView()
        root.wantsLayer = true
        let background = sideBackground
        background.autoresizingMask = [.width, .height]
        root.addSubview(background)
        sideView.autoresizingMask = [.width, .height]
        sideView.onRefresh = { [weak self] in self?.music.refreshQueueRestoringWindow() }
        sideView.onGuideButton = { [weak self] mode in
            switch mode {
            case .permission:
                MusicQueueReader.requestTrust()
                MusicQueueReader.openAccessibilitySettings()
            case .panelClosed:
                // 음악 앱 '보기 › 재생 대기 보기'를 눌러 목록을 열고 다시 읽음
                guard let pid = NSRunningApplication.runningApplications(withBundleIdentifier: MusicBridge.bundleID).first?.processIdentifier else { return }
                _ = MusicMenu.press(pid: pid, menuTitles: ["보기", "View"],
                                    itemTitles: ["재생 대기 보기", "Show Playing Next", "Playing Next"])
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                    MainActor.assumeIsolated { self?.music.reloadQueue() }
                }
            case .none:
                break
            }
        }
        root.addSubview(sideView)
        side.contentView = root
        background.frame = root.bounds
        sideView.frame = root.bounds
        return side
    }

    /// 지금 곡 커버로 배경 색을 물들임 (검색 창: 위쪽만 은은하게 / 옆 창: 위쪽에 흐린 커버)
    private var themedArtwork: NSImage?
    private var themeApplied = false

    private func applyTheme() {
        let art = music.artwork
        guard !themeApplied || art !== themedArtwork else { return }
        themeApplied = true
        themedArtwork = art
        let tint = art.flatMap { PanelBackgroundView.averageColor(of: $0) }
        mainBackground.tint = tint
        mainBackground.backdrop = nil
        sideBackground.tint = tint
        sideBackground.backdrop = art.flatMap { PanelBackgroundView.blurred($0) }
    }

    private static func hintView(keys: String, text: String) -> NSView {
        let stack = NSStackView()
        stack.orientation = .horizontal
        stack.spacing = 5
        let cap = NSTextField(labelWithString: keys)
        cap.font = .systemFont(ofSize: 10.5, weight: .semibold)
        cap.textColor = .secondaryLabelColor
        cap.alignment = .center
        cap.wantsLayer = true
        cap.layer?.backgroundColor = NSColor.labelColor.withAlphaComponent(0.08).cgColor
        cap.layer?.cornerRadius = 5
        cap.layer?.borderWidth = 0.5
        cap.layer?.borderColor = NSColor.labelColor.withAlphaComponent(0.15).cgColor
        cap.translatesAutoresizingMaskIntoConstraints = false
        cap.widthAnchor.constraint(greaterThanOrEqualToConstant: 22).isActive = true
        cap.heightAnchor.constraint(equalToConstant: 17).isActive = true
        let label = NSTextField(labelWithString: text)
        label.font = .systemFont(ofSize: 11, weight: .medium)
        label.textColor = .tertiaryLabelColor
        stack.addArrangedSubview(cap)
        stack.addArrangedSubview(label)
        return stack
    }

    private func listHeight() -> CGFloat {
        let h = rows.indices.reduce(CGFloat(0)) { $0 + height(of: $1) }
        return min(h, maxListHeight)
    }

    private func height(of row: Int) -> CGFloat {
        switch rows[row] {
        case .header: return headerHeight
        case .carousel: return carouselHeight
        case .track: return rowHeight
        }
    }

    private func panelHeight() -> CGFloat {
        rows.isEmpty
            ? fieldHeight + (field.stringValue.isEmpty ? 0 : footerHeight)
            : fieldHeight + listHeight() + 10 + footerHeight
    }

    private func layoutContent() {
        guard let panel, let root = panel.contentView else { return }
        let size = panel.frame.size
        root.subviews.first?.frame = root.bounds
        let top = size.height
        let pill = NSRect(x: 14, y: top - fieldHeight + 14, width: width - 28, height: 50)
        searchPill.frame = pill
        searchIcon.frame = NSRect(x: pill.minX + 16, y: pill.midY - 12, width: 24, height: 24)
        nowPlayingChip.frame = NSRect(x: pill.maxX - 226, y: pill.midY - 8, width: 210, height: 16)
        field.frame = NSRect(x: pill.minX + 50, y: pill.midY - 15, width: pill.width - 50 - 236, height: 30)
        divider.frame = NSRect(x: 20, y: top - fieldHeight + 2, width: width - 40, height: 1)
        divider.isHidden = true

        let list = rows.isEmpty ? 0 : listHeight()
        scroll.isHidden = rows.isEmpty
        scroll.frame = NSRect(x: 8, y: footerHeight, width: width - 16, height: list + 6)
        table.tableColumns.first?.width = scroll.contentSize.width

        let showFooter = top > fieldHeight
        footer.isHidden = !showFooter
        status.isHidden = !showFooter
        credit.isHidden = !showFooter
        let fit = footer.fittingSize
        footer.frame = NSRect(x: 20, y: (footerHeight - fit.height) / 2, width: fit.width, height: fit.height)
        status.frame = NSRect(x: width - 250, y: (footerHeight - 14) / 2, width: 140, height: 14)
        credit.frame = NSRect(x: width - 125, y: (footerHeight - 14) / 2, width: 105, height: 14)
        toast.frame = NSRect(x: (width - 260) / 2, y: footerHeight + 10, width: 260, height: 24)
    }

    private func resize() {
        guard let panel else { return }
        let height = panelHeight()
        var frame = panel.frame
        frame.origin.y += frame.height - height       // 위쪽 고정
        frame.size.height = height
        panel.setFrame(frame, display: true, animate: false)
        layoutContent()
        sidePanel?.setFrame(sideFrame(for: frame), display: true)
        // 재생 설정 카드: 검색 창 높이가 바뀌면 아래 끝을 따라감
        if let controlsPanel, controlsPanel.isVisible, let widget, widget.isAttached, let wf = widget.currentFrame {
            let h = wf.minY - widgetGap - frame.minY
            controlsPanel.setFrame(NSRect(x: wf.minX, y: frame.minY, width: wf.width, height: max(1, h)), display: true)
            controlsPanel.alphaValue = h >= 96 ? 1 : 0
        }
    }

    private func updateNowPlayingChip() {
        if let track = music.track {
            nowPlayingChip.stringValue = (music.isPlaying ? "♫  " : "❙❙  ") + track.title
        } else {
            nowPlayingChip.stringValue = ""
        }
    }

    // MARK: 검색 / 추천

    func controlTextDidChange(_ obj: Notification) {
        updateRows()
        resize()
    }

    private func updateRows() {
        let query = field.stringValue.trimmingCharacters(in: .whitespaces)
        var newRows: [Row] = []
        if query.isEmpty {
            let rec = SongSearch.recommendations(for: music.track, in: library, similarCount: 10)
            if !rec.similar.isEmpty {
                let right = rec.genre.isEmpty ? "같은 가수" : rec.genre
                newRows.append(.header("지금 듣는 곡과 비슷한 노래", right))
                newRows.append(.carousel(rec.similar))
            }
            if !rec.top.isEmpty {
                newRows.append(.header("많이 들은 노래", "10번 이상 · 무작위"))
                newRows += rec.top.map { .track($0, rank: nil) }
            }
            status.stringValue = library.isEmpty ? (music.lastError ?? "보관함을 읽지 못했습니다") : "보관함 \(library.count)곡"
        } else {
            let found = SongSearch.search(query, in: library)
            if !found.isEmpty {
                newRows.append(.header("노래", "\(found.count >= 60 ? "60+" : "\(found.count)")곡"))
                newRows += found.map { .track($0, rank: nil) }
            }
            status.stringValue = found.isEmpty ? "결과 없음" : ""
        }
        rows = newRows
        table.reloadData()
        if let first = rows.indices.first(where: { isTrack($0) }) {
            table.selectRowIndexes(IndexSet(integer: first), byExtendingSelection: false)
        }
        table.scrollRowToVisible(0)
        if groupLink == nil { requestVisibleArtwork() }
    }

    // MARK: 표

    func numberOfRows(in tableView: NSTableView) -> Int { rows.count }

    func tableView(_ tableView: NSTableView, heightOfRow row: Int) -> CGFloat {
        height(of: row)
    }

    func tableView(_ tableView: NSTableView, isGroupRow row: Int) -> Bool { false }

    func tableView(_ tableView: NSTableView, shouldSelectRow row: Int) -> Bool {
        isTrack(row)
    }

    func tableView(_ tableView: NSTableView, viewFor tableColumn: NSTableColumn?, row: Int) -> NSView? {
        switch rows[row] {
        case .header(let title, let right):
            let id = NSUserInterfaceItemIdentifier("header")
            let cell = (tableView.makeView(withIdentifier: id, owner: nil) as? SectionHeaderView) ?? SectionHeaderView()
            cell.identifier = id
            cell.titleLabel.stringValue = title
            cell.rightLabel.stringValue = right
            return cell
        case .carousel(let tracks):
            let view = CarouselRowView()
            view.configure(tracks: tracks, artwork: { [weak self] in self?.artCache[$0] },
                           nowPlaying: music.track)
            view.onPlay = { [weak self] track in self?.doAction(.play, track: track) }
            view.onMenu = { [weak self] track, event, sourceView in
                guard let self else { return }
                self.menuTrack = track
                let menu = NSMenu()
                self.buildContextMenu(menu)
                NSMenu.popUpContextMenu(menu, with: event, for: sourceView)
                self.menuTrack = nil
            }
            return view
        case .track(let track, let rank):
            let id = NSUserInterfaceItemIdentifier("songCell")
            let cell = (tableView.makeView(withIdentifier: id, owner: nil) as? SongCellView) ?? SongCellView()
            cell.identifier = id
            cell.titleLabel.stringValue = track.title.isEmpty ? "제목 없음" : track.title
            cell.detailLabel.stringValue = [track.artist, track.album].filter { !$0.isEmpty }.joined(separator: " · ")
            cell.rankLabel.stringValue = rank.map { "\($0)" } ?? ""
            cell.countLabel.stringValue = track.playCount > 0 ? "\(track.playCount)회" : ""
            cell.isNowPlaying = music.track.map { $0.title == track.title && $0.artist == track.artist } ?? false
            cell.setArtwork(artCache[track.persistentID])
            cell.needsLayout = true
            return cell
        }
    }

    func tableView(_ tableView: NSTableView, rowViewForRow row: Int) -> NSTableRowView? {
        SongRowView()
    }

    // MARK: 썸네일

    @objc private func scrolled() {
        requestVisibleArtwork()
    }

    private func requestVisibleArtwork() {
        let visible = table.rows(in: table.visibleRect)
        guard visible.length > 0 || !rows.isEmpty else { return }
        let range = visible.length > 0 ? visible.location..<(visible.location + visible.length) : 0..<min(rows.count, 9)
        var ids: [String] = []
        for i in range where i < rows.count {
            switch rows[i] {
            case .track(let t, _): ids.append(t.persistentID)
            case .carousel(let tracks): ids += tracks.map(\.persistentID)
            case .header: break
            }
        }
        artQueue = ids.filter { artCache[$0] == nil && !artMissing.contains($0) }
        loadNextArtwork()
    }

    private func loadNextArtwork() {
        guard !artLoading, !artQueue.isEmpty else { return }
        artLoading = true
        // 한 장씩: 키 입력 사이사이에 읽음
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.015) { [weak self] in
            MainActor.assumeIsolated {
                guard let self else { return }
                self.artLoading = false
                guard self.isVisible, !self.artQueue.isEmpty else { return }
                let id = self.artQueue.removeFirst()
                if let image = self.music.artwork(persistentID: id).flatMap({ Self.thumbnail($0) }) {
                    self.artCache[id] = image
                    self.applyArtwork(id: id, image: image)
                } else {
                    self.artMissing.insert(id)
                }
                if self.artCache.count > 600 { self.artCache.removeAll() }
                self.loadNextArtwork()
            }
        }
    }

    private func applyArtwork(id: String, image: NSImage) {
        let visible = table.rows(in: table.visibleRect)
        for i in visible.location..<(visible.location + visible.length) where i < rows.count {
            switch rows[i] {
            case .track(let t, _) where t.persistentID == id:
                (table.view(atColumn: 0, row: i, makeIfNecessary: false) as? SongCellView)?.setArtwork(image, animated: true)
            case .carousel:
                (table.view(atColumn: 0, row: i, makeIfNecessary: false) as? CarouselRowView)?.setArtwork(image, for: id)
            default:
                break
            }
        }
    }

    private static func thumbnail(_ image: NSImage) -> NSImage {
        let side: CGFloat = 96
        let thumb = NSImage(size: NSSize(width: side, height: side))
        thumb.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high
        let s = image.size
        let scale = max(side / max(s.width, 1), side / max(s.height, 1))
        let w = s.width * scale, h = s.height * scale
        image.draw(in: NSRect(x: (side - w) / 2, y: (side - h) / 2, width: w, height: h))
        thumb.unlockFocus()
        return thumb
    }

    // MARK: 키보드

    private func installKeyMonitor() {
        if let keyMonitor { NSEvent.removeMonitor(keyMonitor) }
        keyMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            // 키 이벤트는 늘 메인 스레드에서 옴 → 그대로 넘겨 처리하고, 처리했으면 삼킴
            let key = UncheckedBox(value: event)
            let handled = MainActor.assumeIsolated { () -> Bool in
                guard let self, let panel = self.panel, key.value.window === panel else { return false }
                return self.handleKey(key.value)
            }
            return handled ? nil : event
        }
    }

    private func handleKey(_ event: NSEvent) -> Bool {
        let mods = event.modifierFlags.intersection([.command, .option, .shift, .control])
        switch event.keyCode {
        case 53:
            close()
            return true
        case 125:
            moveSelection(1)
            return true
        case 126:
            moveSelection(-1)
            return true
        case 36, 76:
            if mods == .command { doAction(.playNext) }
            else if mods == .option { doAction(.playLater) }
            else { doAction(.play) }
            return true
        case 37 where mods == .command:
            showPlaylistMenu()
            return true
        default:
            return false
        }
    }

    private func moveSelection(_ delta: Int) {
        guard !rows.isEmpty else { return }
        var i = table.selectedRow
        repeat {
            i += delta
            if i < 0 || i >= rows.count { return }
        } while !isTrack(i)
        table.selectRowIndexes(IndexSet(integer: i), byExtendingSelection: false)
        // 첫 곡으로 올라가면 그 위 머리 행까지 보이게
        table.scrollRowToVisible(i > 0 && delta < 0 ? i - 1 : i)
    }

    private func isTrack(_ i: Int) -> Bool {
        if case .track = rows[i] { return true }
        return false
    }

    @objc private func doubleClicked() {
        doAction(.play)
    }

    // MARK: 동작

    private enum Action { case play, playNext, playLater }

    private var selectedTrack: LibraryTrack? {
        if let menuTrack { return menuTrack }
        let row = table.clickedRow >= 0 ? table.clickedRow : table.selectedRow
        guard row >= 0, row < rows.count, case .track(let t, _) = rows[row] else { return nil }
        return t
    }

    private func doAction(_ action: Action, track: LibraryTrack? = nil) {
        guard let track = track ?? selectedTrack else { NSSound.beep(); return }
        switch action {
        case .play:
            close()
            if !music.play(persistentID: track.persistentID) { NSSound.beep() }
        case .playNext, .playLater:
            close()
            let returnTo = previousApp
            music.enqueue(persistentID: track.persistentID, next: action == .playNext) { ok in
                if !ok { NSSound.beep() }
                debugLog("search: enqueue \(track.title) next=\(action == .playNext) ok=\(ok)")
                if let returnTo, returnTo.bundleIdentifier != MusicBridge.bundleID {
                    returnTo.activate()
                }
            }
        }
    }

    private func showPlaylistMenu() {
        guard let track = selectedTrack, let panel else { NSSound.beep(); return }
        let menu = NSMenu()
        addPlaylistItems(to: menu, track: track)
        let row = max(0, table.selectedRow)
        let rect = table.rect(ofRow: row)
        let point = table.convert(NSPoint(x: rect.minX + 60, y: rect.maxY), to: nil)
        menu.popUp(positioning: nil, at: panel.contentView?.convert(point, from: nil) ?? point, in: panel.contentView)
    }

    private func addPlaylistItems(to menu: NSMenu, track: LibraryTrack) {
        let names = music.userPlaylistNames()
        if names.isEmpty {
            let empty = NSMenuItem(title: "플레이리스트 없음", action: nil, keyEquivalent: "")
            empty.isEnabled = false
            menu.addItem(empty)
        }
        for name in names {
            let item = NSMenuItem(title: name, action: #selector(addToPlaylist(_:)), keyEquivalent: "")
            item.target = self
            item.image = NSImage(systemSymbolName: "music.note.list", accessibilityDescription: nil)
            item.representedObject = [track.persistentID, name, track.title]
            menu.addItem(item)
        }
    }

    @objc private func addToPlaylist(_ sender: NSMenuItem) {
        guard let info = sender.representedObject as? [String], info.count == 3 else { return }
        showToast(music.add(persistentID: info[0], toPlaylist: info[1])
                  ? "‘\(info[1])’에 추가했어요" : "추가하지 못했습니다")
    }

    private func showToast(_ text: String) {
        toast.stringValue = text
        toast.alphaValue = 1
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) { [weak self] in
            MainActor.assumeIsolated {
                guard let self else { return }
                NSAnimationContext.runAnimationGroup { context in
                    context.duration = 0.3
                    self.toast.animator().alphaValue = 0
                }
            }
        }
    }

    @objc private func menuPlay(_ sender: NSMenuItem) { doAction(.play) }
    @objc private func menuPlayNext(_ sender: NSMenuItem) { doAction(.playNext) }
    @objc private func menuPlayLater(_ sender: NSMenuItem) { doAction(.playLater) }

    fileprivate func buildContextMenu(_ menu: NSMenu) {
        menu.removeAllItems()
        guard let track = selectedTrack else { return }
        for (title, symbol, action) in [("재생", "play.fill", #selector(menuPlay(_:))),
                                        ("바로 다음에 재생", "text.line.first.and.arrowtriangle.forward", #selector(menuPlayNext(_:))),
                                        ("대기열에 추가", "text.line.last.and.arrowtriangle.forward", #selector(menuPlayLater(_:)))] {
            let item = NSMenuItem(title: title, action: action, keyEquivalent: "")
            item.target = self
            item.image = NSImage(systemSymbolName: symbol, accessibilityDescription: nil)
            menu.addItem(item)
        }
        menu.addItem(.separator())
        let sub = NSMenu()
        addPlaylistItems(to: sub, track: track)
        let parent = NSMenuItem(title: "플레이리스트에 추가", action: nil, keyEquivalent: "")
        parent.image = NSImage(systemSymbolName: "plus", accessibilityDescription: nil)
        parent.submenu = sub
        menu.addItem(parent)
    }
}

extension SongSearchController: NSMenuDelegate {
    func menuNeedsUpdate(_ menu: NSMenu) {
        buildContextMenu(menu)
    }
}

/// 메인 스레드에서만 오가는 값을 넘길 때 쓰는 상자 (NSEvent처럼 Sendable이 아닌 것)
struct UncheckedBox<T>: @unchecked Sendable {
    let value: T
}

/// 옆 창: 눌러도 검색 창의 입력 상태를 빼앗지 않음
final class SidePanel: NSPanel {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
}

/// 테두리 없지만 글자 입력을 받는 창. 다른 곳을 누르면 닫힘
final class SearchPanel: NSPanel {
    var onResignKey: (@MainActor () -> Void)?
    override var canBecomeKey: Bool { true }
    override func resignKey() {
        super.resignKey()
        let callback = onResignKey
        DispatchQueue.main.async { MainActor.assumeIsolated { callback?() } }
    }
}

/// 목록 구역 제목 ("많이 들은 노래" 등)
final class SectionHeaderView: NSTableCellView {
    let titleLabel = NSTextField(labelWithString: "")
    let rightLabel = NSTextField(labelWithString: "")

    init() {
        super.init(frame: .zero)
        titleLabel.font = .systemFont(ofSize: 12, weight: .bold)
        titleLabel.textColor = .secondaryLabelColor
        rightLabel.font = .systemFont(ofSize: 11, weight: .medium)
        rightLabel.textColor = .tertiaryLabelColor
        rightLabel.alignment = .right
        rightLabel.lineBreakMode = .byTruncatingTail
        addSubview(titleLabel)
        addSubview(rightLabel)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    override func layout() {
        super.layout()
        titleLabel.frame = NSRect(x: 14, y: 4, width: bounds.width * 0.6, height: 16)
        rightLabel.frame = NSRect(x: bounds.width * 0.6, y: 5, width: bounds.width * 0.4 - 14, height: 14)
    }
}

final class SongCellView: NSTableCellView {
    let titleLabel = NSTextField(labelWithString: "")
    let detailLabel = NSTextField(labelWithString: "")
    let rankLabel = NSTextField(labelWithString: "")
    let countLabel = NSTextField(labelWithString: "")
    private let art = CoverView()
    private let artPlaceholder = NSImageView(image: NSImage(systemSymbolName: "music.note", accessibilityDescription: nil) ?? NSImage())
    private let playingIcon = NSImageView(image: NSImage(systemSymbolName: "waveform", accessibilityDescription: nil) ?? NSImage())
    var isNowPlaying = false { didSet { playingIcon.isHidden = !isNowPlaying; applyColors() } }

    init() {
        super.init(frame: .zero)
        titleLabel.font = .systemFont(ofSize: 14, weight: .semibold)
        detailLabel.font = .systemFont(ofSize: 12, weight: .regular)
        rankLabel.font = .monospacedDigitSystemFont(ofSize: 13, weight: .bold)
        rankLabel.alignment = .center
        countLabel.font = .monospacedDigitSystemFont(ofSize: 11, weight: .medium)
        countLabel.alignment = .right
        for label in [titleLabel, detailLabel, rankLabel, countLabel] {
            label.lineBreakMode = .byTruncatingTail
            addSubview(label)
        }
        art.cornerRadius = 8
        art.wantsLayer = true
        art.layer?.backgroundColor = NSColor.labelColor.withAlphaComponent(0.08).cgColor
        art.layer?.borderWidth = 0.5
        art.layer?.borderColor = NSColor.labelColor.withAlphaComponent(0.12).cgColor
        addSubview(art)
        artPlaceholder.symbolConfiguration = .init(pointSize: 15, weight: .medium)
        art.addSubview(artPlaceholder)
        playingIcon.symbolConfiguration = .init(pointSize: 12, weight: .bold)
        playingIcon.isHidden = true
        addSubview(playingIcon)
        applyColors()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    func setArtwork(_ image: NSImage?, animated: Bool = false) {
        art.setImage(image, fade: animated ? 0.25 : 0)
        artPlaceholder.isHidden = image != nil
    }

    override var backgroundStyle: NSView.BackgroundStyle {
        didSet { applyColors() }
    }

    private func applyColors() {
        titleLabel.textColor = NSColor.white.withAlphaComponent(0.95)
        detailLabel.textColor = NSColor.white.withAlphaComponent(0.55)
        rankLabel.textColor = NSColor.white.withAlphaComponent(0.4)
        countLabel.textColor = NSColor.white.withAlphaComponent(0.38)
        artPlaceholder.contentTintColor = NSColor.white.withAlphaComponent(0.3)
        playingIcon.contentTintColor = NSColor(calibratedRed: 1, green: 0.32, blue: 0.42, alpha: 1)
    }

    override func layout() {
        super.layout()
        let h = bounds.height
        let hasRank = !rankLabel.stringValue.isEmpty
        var x: CGFloat = 12
        rankLabel.isHidden = !hasRank
        if hasRank {
            rankLabel.frame = NSRect(x: x, y: (h - 17) / 2, width: 22, height: 17)
            x += 26
        }
        let side: CGFloat = 40
        art.frame = NSRect(x: x, y: (h - side) / 2, width: side, height: side)
        artPlaceholder.frame = art.bounds.insetBy(dx: 11, dy: 11)
        x += side + 12
        let right: CGFloat = countLabel.stringValue.isEmpty ? 14 : 70
        countLabel.frame = NSRect(x: bounds.width - 66, y: (h - 14) / 2, width: 52, height: 14)
        let titleX = isNowPlaying ? x + 18 : x
        playingIcon.frame = NSRect(x: x, y: h / 2 + 1, width: 14, height: 16)
        titleLabel.frame = NSRect(x: titleX, y: h / 2, width: bounds.width - titleX - right, height: 18)
        detailLabel.frame = NSRect(x: x, y: h / 2 - 18, width: bounds.width - x - right, height: 16)
    }
}

/// 선택된 행: 둥근 강조
final class SongRowView: NSTableRowView {
    override func drawSelection(in dirtyRect: NSRect) {
        guard selectionHighlightStyle != .none else { return }
        let rect = bounds.insetBy(dx: 6, dy: 2)
        let path = NSBezierPath(roundedRect: rect, xRadius: 12, yRadius: 12)
        NSColor.white.withAlphaComponent(0.13).setFill()
        path.fill()
        NSColor.white.withAlphaComponent(0.10).setStroke()
        path.lineWidth = 0.5
        path.stroke()
    }

    override var isEmphasized: Bool {
        get { true }
        set {}
    }
}

// MARK: - 검색 창 옆: 지금 재생 중 + 다음 재생 목록

final class QueueSideView: NSView {
    private let nowHeader = NSTextField(labelWithString: "지금 재생 중")
    private let cover = CoverView()
    private let coverShadow = NSView()
    private let coverPlaceholder = NSImageView(image: NSImage(systemSymbolName: "music.note", accessibilityDescription: nil) ?? NSImage())
    private let titleLabel = NSTextField(wrappingLabelWithString: "")
    private let artistLabel = NSTextField(labelWithString: "")
    private let albumLabel = NSTextField(labelWithString: "")
    private let divider = NSBox()
    private let queueHeader = NSTextField(labelWithString: "다음 재생")
    private let queueCount = NSTextField(labelWithString: "")
    private let list = FlippedView()
    private let message = NSTextField(wrappingLabelWithString: "")
    private var items: [(String, String)] = []
    private var total = 0
    // 권한이 꺼져 있을 때: 켜는 방법 + 설정 열기 버튼
    private let guide = NSTextField(wrappingLabelWithString: "")
    private let openButton = NSButton(title: "손쉬운 사용 설정 열기", target: nil, action: nil)
    enum Guide { case none, permission, panelClosed }
    /// 안내 화면: 권한이 꺼져 있을 때 / 음악 앱 재생 대기 목록이 닫혀 있을 때
    var guideMode: Guide = .none { didSet { applyGuide(); needsLayout = true } }
    var showsPermissionGuide: Bool { guideMode == .permission }
    var onGuideButton: ((Guide) -> Void)?
    /// 음악 창이 최소화돼 있어 목록이 예전 것일 수 있을 때: 아래에 알림 + 새로고침
    var staleHint = false { didSet { if staleHint != oldValue { needsLayout = true } } }
    var onRefresh: (() -> Void)?
    private let staleLabel = NSTextField(wrappingLabelWithString: "음악 앱 창이 최소화돼 있으면 목록이 새로 바뀌지 않아요.")
    private let refreshButton = NSButton(title: "잠깐 펼쳐서 새로고침", target: nil, action: nil)

    override var isFlipped: Bool { true }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        for label in [nowHeader, queueHeader] {
            label.font = .systemFont(ofSize: 11.5, weight: .bold)
            label.textColor = .secondaryLabelColor
        }
        queueCount.font = .systemFont(ofSize: 11, weight: .medium)
        queueCount.textColor = .tertiaryLabelColor
        queueCount.alignment = .right
        cover.cornerRadius = 14
        cover.wantsLayer = true
        cover.layer?.backgroundColor = NSColor.white.withAlphaComponent(0.08).cgColor
        coverShadow.wantsLayer = true
        coverShadow.shadow = {
            let s = NSShadow()
            s.shadowColor = NSColor.black.withAlphaComponent(0.55)
            s.shadowBlurRadius = 18
            s.shadowOffset = NSSize(width: 0, height: -6)
            return s
        }()
        coverPlaceholder.symbolConfiguration = .init(pointSize: 22, weight: .medium)
        coverPlaceholder.contentTintColor = .tertiaryLabelColor
        cover.addSubview(coverPlaceholder)
        titleLabel.font = .systemFont(ofSize: 16, weight: .bold)
        titleLabel.alignment = .center
        artistLabel.alignment = .center
        albumLabel.alignment = .center
        titleLabel.maximumNumberOfLines = 2
        titleLabel.lineBreakMode = .byTruncatingTail
        artistLabel.font = .systemFont(ofSize: 12.5, weight: .medium)
        artistLabel.textColor = .secondaryLabelColor
        albumLabel.font = .systemFont(ofSize: 11.5)
        albumLabel.textColor = .tertiaryLabelColor
        for label in [artistLabel, albumLabel] { label.lineBreakMode = .byTruncatingTail }
        divider.boxType = .separator
        message.font = .systemFont(ofSize: 12)
        message.textColor = .tertiaryLabelColor
        coverShadow.addSubview(cover)
        for view in [nowHeader, coverShadow, titleLabel, artistLabel, albumLabel, divider, queueHeader, queueCount, list, message] as [NSView] {
            addSubview(view)
        }
        staleLabel.font = .systemFont(ofSize: 10.5)
        staleLabel.textColor = NSColor.white.withAlphaComponent(0.4)
        refreshButton.bezelStyle = .push
        refreshButton.controlSize = .small
        refreshButton.target = self
        refreshButton.action = #selector(refreshTapped)
        addSubview(staleLabel)
        addSubview(refreshButton)
        guide.isHidden = true
        openButton.bezelStyle = .push
        openButton.controlSize = .large
        openButton.keyEquivalent = ""
        openButton.target = self
        openButton.action = #selector(openSettings)
        openButton.isHidden = true
        addSubview(guide)
        addSubview(openButton)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    @objc private func refreshTapped() {
        onRefresh?()
    }

    @objc private func openSettings() {
        onGuideButton?(guideMode)
    }

    private func applyGuide() {
        let steps = NSMutableAttributedString()
        let para = NSMutableParagraphStyle()
        para.lineSpacing = 3
        para.paragraphSpacing = 5
        func add(_ text: String, bold: Bool = false, color: NSColor = .secondaryLabelColor) {
            steps.append(NSAttributedString(string: text, attributes: [
                .font: NSFont.systemFont(ofSize: 12, weight: bold ? .semibold : .regular),
                .foregroundColor: color, .paragraphStyle: para]))
        }
        switch guideMode {
        case .permission:
            add("다음 곡 목록을 보려면 손쉬운 사용 권한이 필요해요.\n", bold: true, color: .labelColor)
            add("1. 아래 버튼으로 시스템 설정을 열어요\n")
            add("2. 개인정보 보호 및 보안 › 손쉬운 사용\n")
            add("3. 목록에서 MusicInfo를 켜요\n")
            add("    (없으면 ＋ 눌러 응용 프로그램 › MusicInfo 추가)\n")
            add("4. 켠 뒤 ⌘ 두 번으로 검색 창을 다시 열면 보여요", color: .tertiaryLabelColor)
            openButton.title = "손쉬운 사용 설정 열기"
        case .panelClosed:
            add("음악 앱의 재생 대기 목록이 닫혀 있어요.\n", bold: true, color: .labelColor)
            add("다음 곡은 음악 앱 오른쪽의 재생 대기 목록에서 읽어 와요. 목록을 한 번 열어 두면 계속 보여요.\n")
            add("음악 앱 창은 다른 창 뒤에 가려도 괜찮지만, 최소화하면 목록이 멈춰요.", color: .tertiaryLabelColor)
            openButton.title = "재생 대기 목록 열기"
        case .none:
            break
        }
        guide.attributedStringValue = steps
    }

    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    func setNowPlaying(_ track: NowPlaying?, artwork: NSImage?, playing: Bool) {
        nowHeader.stringValue = track == nil ? "재생 중인 곡 없음" : (playing ? "지금 재생 중" : "일시 정지됨")
        titleLabel.stringValue = track?.title ?? ""
        artistLabel.stringValue = track?.artist ?? ""
        albumLabel.stringValue = track?.album ?? ""
        cover.image = artwork
        coverPlaceholder.isHidden = artwork != nil
        needsLayout = true
    }

    /// 내용이 바뀔 때 부드럽게 겹쳐 바뀜 (다음 곡 목록이 '툭' 나타나지 않게)
    private func crossfade() {
        wantsLayer = true
        let t = CATransition()
        t.type = .fade
        t.duration = 0.35
        t.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        layer?.add(t, forKey: "content")
    }

    /// nil = 대기 목록을 못 읽음
    func setQueue(_ entries: [(title: String, subtitle: String)]?, total: Int, note: String? = nil) {
        if let entries {
            items = entries.map { ($0.title, $0.subtitle) }
            self.total = total
            message.stringValue = entries.isEmpty ? "다음에 재생할 곡이 없어요" : ""
        } else {
            items = []
            self.total = 0
            message.stringValue = note ?? "다음 곡을 읽지 못했어요"
        }
        queueCount.stringValue = total > 0 ? "\(total)곡" : ""
        crossfade()
        needsLayout = true
    }

    override func layout() {
        super.layout()
        let w = bounds.width
        let pad: CGFloat = 18
        var y: CGFloat = 18
        nowHeader.alignment = .center
        nowHeader.frame = NSRect(x: pad, y: y, width: w - pad * 2, height: 15)
        y += 26
        // 큰 커버 (가운데)
        // 커버는 적당히 → 아래 다음 곡 목록이 더 많이 보이게
        let side = floor(min(w - pad * 2 - 60, bounds.height * 0.3, 200))
        coverShadow.frame = NSRect(x: floor((w - side) / 2), y: y, width: side, height: side)
        cover.frame = coverShadow.bounds
        coverPlaceholder.frame = cover.bounds.insetBy(dx: side * 0.36, dy: side * 0.36)
        y += side + 14
        let tw = w - pad * 2
        titleLabel.preferredMaxLayoutWidth = tw
        let titleH = min(42, titleLabel.sizeThatFits(NSSize(width: tw, height: 100)).height)
        titleLabel.frame = NSRect(x: pad, y: y, width: tw, height: titleH)
        y += titleH + 2
        artistLabel.frame = NSRect(x: pad, y: y, width: tw, height: 16)
        y += 17
        albumLabel.frame = NSRect(x: pad, y: y, width: tw, height: 15)
        y += 15 + 14
        divider.frame = NSRect(x: pad, y: y, width: w - pad * 2, height: 1)
        y += 14
        queueHeader.frame = NSRect(x: pad, y: y, width: 120, height: 15)
        queueCount.frame = NSRect(x: w - pad - 100, y: y, width: 100, height: 15)
        y += 22

        // 맨 아래: 최소화 알림 + 새로고침
        let hintH: CGFloat = staleHint ? 62 : 0
        staleLabel.isHidden = !staleHint
        refreshButton.isHidden = !staleHint
        if staleHint {
            staleLabel.frame = NSRect(x: pad, y: bounds.height - hintH, width: w - pad * 2, height: 28)
            refreshButton.frame = NSRect(x: pad - 4, y: bounds.height - hintH + 28, width: w - pad * 2 + 8, height: 24)
        }
        // 목록: 칸이 허락하는 만큼, 넘치면 마지막 줄에 "… 외 N곡"
        list.frame = NSRect(x: 0, y: y, width: w, height: bounds.height - y - 10 - hintH)
        list.subviews.forEach { $0.removeFromSuperview() }
        message.frame = NSRect(x: pad, y: y + 4, width: w - pad * 2, height: 34)
        let guiding = guideMode != .none
        guide.isHidden = !guiding
        openButton.isHidden = !guiding
        message.isHidden = guiding
        if guiding {
            guide.preferredMaxLayoutWidth = w - pad * 2
            let gh = guide.sizeThatFits(NSSize(width: w - pad * 2, height: 400)).height
            guide.frame = NSRect(x: pad, y: y + 2, width: w - pad * 2, height: gh)
            openButton.sizeToFit()
            openButton.frame = NSRect(x: pad - 4, y: y + gh + 12, width: w - pad * 2 + 8, height: 32)
            list.subviews.forEach { $0.removeFromSuperview() }
            return
        }
        let rowH: CGFloat = 40
        let capacity = max(0, Int(list.bounds.height / rowH))
        let showMore = total > min(items.count, capacity)
        let shown = min(items.count, showMore ? max(0, capacity - 1) : capacity)
        for i in 0..<shown {
            let row = QueueRowView(index: i + 1, title: items[i].0, subtitle: items[i].1)
            row.frame = NSRect(x: 8, y: list.frame.minY + CGFloat(i) * rowH, width: w - 16, height: rowH)
            row.frame.origin.y = CGFloat(i) * rowH
            list.addSubview(row)
        }
        if showMore {
            let more = NSTextField(labelWithString: "…  외 \(total - shown)곡")
            more.font = .systemFont(ofSize: 12, weight: .semibold)
            more.textColor = .tertiaryLabelColor
            more.frame = NSRect(x: pad, y: CGFloat(shown) * rowH + 10, width: w - pad * 2, height: 16)
            list.addSubview(more)
        }
    }
}

final class FlippedView: NSView {
    override var isFlipped: Bool { true }
}

private final class QueueRowView: NSView {
    override var isFlipped: Bool { true }

    init(index: Int, title: String, subtitle: String) {
        super.init(frame: .zero)
        let number = NSTextField(labelWithString: "\(index)")
        number.font = .monospacedDigitSystemFont(ofSize: 12, weight: .bold)
        number.textColor = index == 1 ? .controlAccentColor : .tertiaryLabelColor
        number.alignment = .center
        let titleLabel = NSTextField(labelWithString: title.isEmpty ? "제목 없음" : title)
        titleLabel.font = .systemFont(ofSize: 13, weight: index == 1 ? .semibold : .medium)
        let detail = NSTextField(labelWithString: subtitle.replacingOccurrences(of: " — ", with: " · "))
        detail.font = .systemFont(ofSize: 11)
        detail.textColor = .secondaryLabelColor
        for label in [titleLabel, detail] { label.lineBreakMode = .byTruncatingTail }
        for view in [number, titleLabel, detail] { addSubview(view) }
        number.identifier = .init("n"); titleLabel.identifier = .init("t"); detail.identifier = .init("d")
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    override func layout() {
        super.layout()
        let w = bounds.width
        for view in subviews {
            switch view.identifier?.rawValue {
            case "n": view.frame = NSRect(x: 4, y: 12, width: 22, height: 16)
            case "t": view.frame = NSRect(x: 32, y: 4, width: w - 40, height: 17)
            case "d": view.frame = NSRect(x: 32, y: 21, width: w - 40, height: 15)
            default: break
            }
        }
    }
}


// MARK: - 불투명 배경 (진한 검정 + 지금 곡 색으로 은은하게)

final class PanelBackgroundView: NSView {
    var tint: NSColor? { didSet { needsDisplay = true } }
    var backdrop: NSImage? { didSet { needsDisplay = true } }
    private let backdropFraction: CGFloat

    init(backdropFraction: CGFloat = 0) {
        self.backdropFraction = backdropFraction
        super.init(frame: .zero)
        wantsLayer = true
        layerContentsRedrawPolicy = .duringViewResize
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    override func draw(_ dirtyRect: NSRect) {
        let r = SongSearchController.radius
        let shape = NSBezierPath(roundedRect: bounds, xRadius: r, yRadius: r)
        NSGraphicsContext.saveGraphicsState()
        shape.addClip()
        // 바탕: 아주 진한 회색
        NSColor(calibratedRed: 0.075, green: 0.075, blue: 0.085, alpha: 1).setFill()
        bounds.fill()
        // 위쪽에 흐린 커버 (옆 창)
        if let backdrop, backdropFraction > 0 {
            let h = bounds.height * backdropFraction
            let area = NSRect(x: 0, y: bounds.height - h, width: bounds.width, height: h)
            let s = backdrop.size
            let scale = max(area.width / max(s.width, 1), area.height / max(s.height, 1))
            let w = s.width * scale, ih = s.height * scale
            // 커버가 위쪽 영역 밖(아래)으로 삐져나와 띠처럼 보이지 않게 영역 안으로만 그림
            NSGraphicsContext.saveGraphicsState()
            NSBezierPath(rect: area).addClip()
            backdrop.draw(in: NSRect(x: area.midX - w / 2, y: area.midY - ih / 2, width: w, height: ih),
                          from: .zero, operation: .sourceOver, fraction: 0.55)
            NSGraphicsContext.restoreGraphicsState()
            let base = NSColor(calibratedRed: 0.075, green: 0.075, blue: 0.085, alpha: 1)
            NSGradient(colors: [base, base.withAlphaComponent(0.55), base.withAlphaComponent(0.15)],
                       atLocations: [0, 0.45, 1], colorSpace: .sRGB)?.draw(in: area, angle: 90)
        }
        // 지금 곡 색: 위에서 아래로 사라지는 은은한 빛
        if let tint {
            let glow = tint.usingColorSpace(.sRGB) ?? tint
            NSGradient(colors: [glow.withAlphaComponent(0.42), glow.withAlphaComponent(0.12), glow.withAlphaComponent(0)],
                       atLocations: [0, 0.35, 1], colorSpace: .sRGB)?.draw(in: bounds, angle: -90)
        }
        NSGraphicsContext.restoreGraphicsState()
        // 얇은 밝은 테두리
        let border = NSBezierPath(roundedRect: bounds.insetBy(dx: 0.5, dy: 0.5), xRadius: r - 0.5, yRadius: r - 0.5)
        NSColor.white.withAlphaComponent(0.12).setStroke()
        border.lineWidth = 1
        border.stroke()
    }

    static func averageColor(of image: NSImage) -> NSColor? {
        guard let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return nil }
        var pixel = [UInt8](repeating: 0, count: 4)
        guard let ctx = CGContext(data: &pixel, width: 1, height: 1, bitsPerComponent: 8, bytesPerRow: 4,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        ctx.interpolationQuality = .medium
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: 1, height: 1))
        let color = NSColor(calibratedRed: CGFloat(pixel[0]) / 255, green: CGFloat(pixel[1]) / 255,
                            blue: CGFloat(pixel[2]) / 255, alpha: 1)
        // 너무 어둡거나 칙칙하면 살짝 밝고 선명하게
        var h: CGFloat = 0, sat: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        color.getHue(&h, saturation: &sat, brightness: &b, alpha: &a)
        return NSColor(calibratedHue: h, saturation: min(1, sat * 1.3 + 0.1), brightness: max(0.45, min(0.85, b * 1.2)), alpha: 1)
    }

    private static let ciContext = CIContext(options: [.cacheIntermediates: false])
    private static var blurCache: (source: ObjectIdentifier, result: NSImage)?

    /// 흐린 배경용: 작게 줄인 뒤 흐리게 (어차피 흐리게 할 거라 큰 그림을 그대로 쓰면 낭비) + 같은 그림이면 다시 안 만듦
    static func blurred(_ image: NSImage) -> NSImage? {
        let id = ObjectIdentifier(image)
        if let cached = blurCache, cached.source == id { return cached.result }
        guard let cg = image.cgImage(forProposedRect: nil, context: nil, hints: nil) else { return nil }
        let side = 160
        guard let ctx = CGContext(data: nil, width: side, height: side, bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else { return nil }
        ctx.interpolationQuality = .medium
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: side, height: side))
        guard let small = ctx.makeImage() else { return nil }
        let source = CIImage(cgImage: small)
        let output = source.clampedToExtent()
            .applyingGaussianBlur(sigma: Double(side) / 14)
            .cropped(to: source.extent)
        guard let result = ciContext.createCGImage(output, from: source.extent) else { return nil }
        let blurred = NSImage(cgImage: result, size: NSSize(width: side, height: side))
        blurCache = (id, blurred)
        return blurred
    }
}

// MARK: - 추천 카드 (가로로 넘기기)

/// 세로 휠은 바깥 목록으로 넘기고, 가로 휠(트랙패드 좌우)만 직접 처리
final class HorizontalScrollView: NSScrollView {
    override func scrollWheel(with event: NSEvent) {
        if abs(event.scrollingDeltaY) > abs(event.scrollingDeltaX) {
            nextResponder?.scrollWheel(with: event)
        } else {
            super.scrollWheel(with: event)
        }
    }
}

final class CarouselRowView: NSTableCellView {
    var onPlay: ((LibraryTrack) -> Void)?
    var onMenu: ((LibraryTrack, NSEvent, NSView) -> Void)?
    private let scroll = HorizontalScrollView()
    private let strip = FlippedView()
    private var tiles: [CarouselTile] = []
    private let tileWidth: CGFloat = 132
    private let gap: CGFloat = 14
    private let pad: CGFloat = 14

    init() {
        super.init(frame: .zero)
        scroll.drawsBackground = false
        scroll.hasHorizontalScroller = false
        scroll.hasVerticalScroller = false
        scroll.verticalScrollElasticity = .none
        scroll.horizontalScrollElasticity = .allowed
        scroll.documentView = strip
        addSubview(scroll)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    func configure(tracks: [LibraryTrack], artwork: (String) -> NSImage?, nowPlaying: NowPlaying?) {
        tiles.forEach { $0.removeFromSuperview() }
        tiles = tracks.map { track in
            let tile = CarouselTile(track: track)
            tile.setArtwork(artwork(track.persistentID), animated: false)
            tile.isNowPlaying = nowPlaying.map { $0.title == track.title && $0.artist == track.artist } ?? false
            tile.onClick = { [weak self] in self?.onPlay?(track) }
            tile.onRightClick = { [weak self] event, view in self?.onMenu?(track, event, view) }
            strip.addSubview(tile)
            return tile
        }
        needsLayout = true
    }

    func setArtwork(_ image: NSImage, for id: String) {
        for tile in tiles where tile.track.persistentID == id { tile.setArtwork(image, animated: true) }
    }

    override func layout() {
        super.layout()
        scroll.frame = bounds
        // 오른쪽 끝은 살짝 흐려지게 → 옆으로 더 넘길 수 있다는 느낌 + 잘린 카드가 덜 어색하게
        scroll.wantsLayer = true
        let fade = CAGradientLayer()
        fade.frame = scroll.bounds
        fade.startPoint = CGPoint(x: 0, y: 0.5)
        fade.endPoint = CGPoint(x: 1, y: 0.5)
        fade.colors = [NSColor.black.cgColor, NSColor.black.cgColor, NSColor.clear.cgColor]
        let edge = max(0, 1 - 56 / max(scroll.bounds.width, 1))
        fade.locations = [0, NSNumber(value: Double(edge)), 1]
        scroll.layer?.mask = fade
        let n = CGFloat(tiles.count)
        strip.frame = NSRect(x: 0, y: 0, width: max(bounds.width, pad * 2 + n * tileWidth + max(0, n - 1) * gap),
                             height: bounds.height)
        for (i, tile) in tiles.enumerated() {
            tile.frame = NSRect(x: pad + CGFloat(i) * (tileWidth + gap), y: 4, width: tileWidth, height: bounds.height - 8)
        }
    }
}

final class CarouselTile: NSView {
    let track: LibraryTrack
    var onClick: (() -> Void)?
    var onRightClick: ((NSEvent, NSView) -> Void)?
    var isNowPlaying = false { didSet { playingDot.isHidden = !isNowPlaying } }
    private let coverHost = NSView()
    private let cover = CoverView()
    private let placeholder = NSImageView(image: NSImage(systemSymbolName: "music.note", accessibilityDescription: nil) ?? NSImage())
    private let playBadge = NSImageView(image: NSImage(systemSymbolName: "play.circle.fill", accessibilityDescription: nil) ?? NSImage())
    private let playingDot = NSImageView(image: NSImage(systemSymbolName: "waveform", accessibilityDescription: nil) ?? NSImage())
    private let titleLabel = NSTextField(labelWithString: "")
    private let artistLabel = NSTextField(labelWithString: "")
    private var hovering = false { didSet { updateHover() } }

    override var isFlipped: Bool { true }

    init(track: LibraryTrack) {
        self.track = track
        super.init(frame: .zero)
        coverHost.wantsLayer = true
        coverHost.shadow = {
            let s = NSShadow()
            s.shadowColor = NSColor.black.withAlphaComponent(0.45)
            s.shadowBlurRadius = 10
            s.shadowOffset = NSSize(width: 0, height: -4)
            return s
        }()
        cover.cornerRadius = 12
        cover.layer?.backgroundColor = NSColor.white.withAlphaComponent(0.08).cgColor
        coverHost.addSubview(cover)
        placeholder.symbolConfiguration = .init(pointSize: 26, weight: .medium)
        placeholder.contentTintColor = NSColor.white.withAlphaComponent(0.3)
        cover.addSubview(placeholder)
        playBadge.symbolConfiguration = .init(pointSize: 30, weight: .semibold)
        playBadge.contentTintColor = .white
        playBadge.alphaValue = 0
        playBadge.shadow = {
            let s = NSShadow()
            s.shadowColor = NSColor.black.withAlphaComponent(0.5)
            s.shadowBlurRadius = 6
            return s
        }()
        cover.addSubview(playBadge)
        playingDot.symbolConfiguration = .init(pointSize: 11, weight: .bold)
        playingDot.contentTintColor = NSColor(calibratedRed: 1, green: 0.32, blue: 0.42, alpha: 1)
        playingDot.isHidden = true
        titleLabel.stringValue = track.title.isEmpty ? "제목 없음" : track.title
        titleLabel.font = .systemFont(ofSize: 12.5, weight: .semibold)
        titleLabel.textColor = NSColor.white.withAlphaComponent(0.95)
        artistLabel.stringValue = track.artist
        artistLabel.font = .systemFont(ofSize: 11)
        artistLabel.textColor = NSColor.white.withAlphaComponent(0.55)
        for label in [titleLabel, artistLabel] { label.lineBreakMode = .byTruncatingTail }
        for view in [coverHost, titleLabel, artistLabel, playingDot] as [NSView] { addSubview(view) }
        toolTip = [track.title, track.artist, track.album].filter { !$0.isEmpty }.joined(separator: "\n")
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    func setArtwork(_ image: NSImage?, animated: Bool) {
        cover.setImage(image, fade: animated ? 0.25 : 0)
        placeholder.isHidden = image != nil
    }

    override func layout() {
        super.layout()
        let side = bounds.width
        coverHost.frame = NSRect(x: 0, y: 0, width: side, height: side)
        cover.frame = coverHost.bounds
        placeholder.frame = cover.bounds.insetBy(dx: side * 0.35, dy: side * 0.35)
        playBadge.frame = NSRect(x: side - 44, y: 8, width: 36, height: 36)
        let textX: CGFloat = isNowPlaying ? 16 : 0
        playingDot.frame = NSRect(x: 0, y: side + 9, width: 14, height: 14)
        titleLabel.frame = NSRect(x: textX, y: side + 7, width: side - textX, height: 17)
        artistLabel.frame = NSRect(x: 0, y: side + 25, width: side, height: 15)
    }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: bounds, options: [.mouseEnteredAndExited, .activeAlways, .inVisibleRect],
                                       owner: self, userInfo: nil))
    }

    override func mouseEntered(with event: NSEvent) { hovering = true }
    override func mouseExited(with event: NSEvent) { hovering = false }

    private func updateHover() {
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.15
            playBadge.animator().alphaValue = hovering ? 1 : 0
        }
        cover.layer?.borderWidth = hovering ? 2 : 0
        cover.layer?.borderColor = NSColor.white.withAlphaComponent(0.55).cgColor
    }

    override func mouseUp(with event: NSEvent) {
        if bounds.contains(convert(event.locationInWindow, from: nil)) { onClick?() }
    }

    override func mouseDown(with event: NSEvent) {}

    override func rightMouseDown(with event: NSEvent) {
        onRightClick?(event, self)
    }
}

// MARK: - 재생 설정 카드 (셔플·반복·좋아요·음량)

final class PlaybackControlsView: NSView {
    var onShuffle: ((Bool) -> Void)?
    var onRepeat: ((String) -> Void)?
    var onVolume: ((Int) -> Void)?
    var onFavorite: ((Bool) -> Void)?
    var options: MusicBridge.PlaybackOptions? { didSet { apply(animated: oldValue != nil) } }

    private let header = NSTextField(labelWithString: "재생 설정")
    private let shuffleTile = ControlTile()
    private let repeatTile = ControlTile()
    private let favoriteTile = ControlTile()
    private let slider = NSSlider(value: 50, minValue: 0, maxValue: 100, target: nil, action: nil)
    private let lowIcon = NSImageView(image: NSImage(systemSymbolName: "speaker.fill", accessibilityDescription: nil) ?? NSImage())
    private let highIcon = NSImageView(image: NSImage(systemSymbolName: "speaker.wave.3.fill", accessibilityDescription: nil) ?? NSImage())
    private var lastUserVolume: TimeInterval = 0

    override var isFlipped: Bool { true }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        header.font = .systemFont(ofSize: 11.5, weight: .bold)
        header.textColor = NSColor.white.withAlphaComponent(0.5)
        addSubview(header)
        for tile in [shuffleTile, repeatTile, favoriteTile] { addSubview(tile) }
        shuffleTile.onClick = { [weak self] in
            guard let self, let o = self.options else { return }
            self.onShuffle?(!o.shuffle)
        }
        repeatTile.onClick = { [weak self] in
            guard let self, let o = self.options else { return }
            self.onRepeat?(o.repeatMode)
        }
        favoriteTile.onClick = { [weak self] in
            guard let self, let o = self.options else { return }
            self.onFavorite?(!o.favorited)
        }
        slider.isContinuous = true
        slider.controlSize = .small
        slider.target = self
        slider.action = #selector(volumeChanged)
        addSubview(slider)
        for icon in [lowIcon, highIcon] {
            icon.symbolConfiguration = .init(pointSize: 11, weight: .semibold)
            icon.contentTintColor = NSColor.white.withAlphaComponent(0.5)
            addSubview(icon)
        }
        apply(animated: false)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    @objc private func volumeChanged() {
        lastUserVolume = monotonicNow()
        onVolume?(Int(slider.doubleValue.rounded()))
    }

    private func apply(animated: Bool) {
        let o = options ?? MusicBridge.PlaybackOptions()
        let pink = NSColor(calibratedRed: 1, green: 0.32, blue: 0.42, alpha: 1)
        shuffleTile.set(symbol: "shuffle", title: o.shuffle ? "셔플 켬" : "셔플", active: o.shuffle, tint: .white, animated: animated)
        let repeatTitle = o.repeatMode == "one" ? "한 곡 반복" : (o.repeatMode == "all" ? "전체 반복" : "반복")
        repeatTile.set(symbol: o.repeatMode == "one" ? "repeat.1" : "repeat", title: repeatTitle,
                       active: o.repeatMode != "off", tint: .white, animated: animated)
        favoriteTile.set(symbol: o.favorited ? "heart.fill" : "heart", title: "좋아요",
                         active: o.favorited, tint: pink, animated: animated)
        // 사용자가 막 끌고 있는 동안엔 음량 막대를 덮어쓰지 않음
        if monotonicNow() - lastUserVolume > 1.5 { slider.doubleValue = Double(o.volume) }
    }

    override func layout() {
        super.layout()
        let w = bounds.width, h = bounds.height
        let pad: CGFloat = 16
        header.frame = NSRect(x: pad + 2, y: 14, width: w - pad * 2, height: 15)
        // 아래: 음량, 그 위 남는 자리에 버튼 3개
        let volumeY = h - 30
        lowIcon.frame = NSRect(x: pad, y: volumeY + 2, width: 14, height: 14)
        highIcon.frame = NSRect(x: w - pad - 18, y: volumeY + 2, width: 18, height: 14)
        slider.frame = NSRect(x: pad + 20, y: volumeY, width: w - pad * 2 - 44, height: 18)
        let avail = volumeY - 12 - 36
        let tileH = max(36, min(76, avail))
        let top: CGFloat = 36 + max(0, (avail - tileH) / 2)     // 남는 자리는 위아래 고르게
        let gap: CGFloat = 8
        let tileW = (w - pad * 2 - gap * 2) / 3
        for (i, tile) in [shuffleTile, repeatTile, favoriteTile].enumerated() {
            tile.frame = NSRect(x: pad + CGFloat(i) * (tileW + gap), y: top, width: tileW, height: tileH)
        }
    }
}

/// 둥근 칸 버튼: 아이콘 + 작은 글씨, 켜지면 밝게
final class ControlTile: NSView {
    var onClick: (() -> Void)?
    private let icon = NSImageView()
    private let label = NSTextField(labelWithString: "")
    private var hovering = false { didSet { updateBackground() } }
    private var active = false

    override var isFlipped: Bool { true }
    override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer?.cornerRadius = 12
        icon.symbolConfiguration = .init(pointSize: 17, weight: .semibold)
        label.font = .systemFont(ofSize: 10.5, weight: .semibold)
        label.alignment = .center
        label.lineBreakMode = .byTruncatingTail
        addSubview(icon)
        addSubview(label)
        updateBackground()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) not used") }

    func set(symbol: String, title: String, active: Bool, tint: NSColor, animated: Bool) {
        let changed = active != self.active || label.stringValue != title
        self.active = active
        icon.image = NSImage(systemSymbolName: symbol, accessibilityDescription: title)
        icon.contentTintColor = active ? tint : NSColor.white.withAlphaComponent(0.55)
        label.stringValue = title
        label.textColor = active ? NSColor.white.withAlphaComponent(0.95) : NSColor.white.withAlphaComponent(0.5)
        if animated && changed {
            let t = CATransition()
            t.type = .fade
            t.duration = 0.2
            layer?.add(t, forKey: "state")
        }
        updateBackground()
    }

    private func updateBackground() {
        let base: CGFloat = active ? 0.16 : 0.06
        layer?.backgroundColor = NSColor.white.withAlphaComponent(base + (hovering ? 0.05 : 0)).cgColor
        layer?.borderWidth = 0.5
        layer?.borderColor = NSColor.white.withAlphaComponent(active ? 0.18 : 0.06).cgColor
    }

    override func layout() {
        super.layout()
        let h = bounds.height
        let showLabel = h >= 50
        label.isHidden = !showLabel
        icon.frame = NSRect(x: (bounds.width - 24) / 2, y: showLabel ? h / 2 - 20 : (h - 22) / 2, width: 24, height: 22)
        label.frame = NSRect(x: 4, y: h / 2 + 6, width: bounds.width - 8, height: 14)
    }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        trackingAreas.forEach(removeTrackingArea)
        addTrackingArea(NSTrackingArea(rect: bounds, options: [.mouseEnteredAndExited, .activeAlways, .inVisibleRect],
                                       owner: self, userInfo: nil))
    }

    override func mouseEntered(with event: NSEvent) { hovering = true }
    override func mouseExited(with event: NSEvent) { hovering = false }
    override func mouseDown(with event: NSEvent) { alphaValue = 0.7 }
    override func mouseUp(with event: NSEvent) {
        alphaValue = 1
        if bounds.contains(convert(event.locationInWindow, from: nil)) { onClick?() }
    }
}
