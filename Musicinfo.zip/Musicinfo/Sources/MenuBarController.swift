import Cocoa
import QuartzCore

/// 메뉴바 스펙트럼 아이템의 표시/숨김, 다른 아이콘 숨기기, 마우스를 올렸을 때 펼치기를 관리한다.
///
/// 상태 흐름
///   소리 없음 ──(1초 이상 소리)──▶ 재생 중: 스펙트럼 표시 + 다른 아이콘 숨김
///      ▲                              │ 마우스를 스펙트럼(또는 그 오른쪽)에 올림
///      │                              ▼
///      └──(설정한 시간 동안 무음)── 펼침: 다른 아이콘 표시 → 메뉴바를 벗어나면 다시 숨김
@MainActor
final class MenuBarController: NSObject {
    static let spectrumAutosaveName = "SpectrumBarSpectrum"

    let spectrumItem: NSStatusItem
    let hider: any MenuBarHider
    /// 바탕화면 위젯 (같은 막대 값을 그대로 받아서 그림)
    weak var widget: DesktopWidgetController?
    weak var search: SongSearchController?
    private let store: LevelStore
    private let settings = Settings.shared
    private let spectrumView = SpectrumView()
    // 갱신 드라이버: 항상 도는 5Hz 타이머 + (보일 때) 60fps 타이머 또는 화면 주사율 동기화
    private enum Driver { case none, timer, display }
    private var slowTimer: Timer?
    private var fastTimer: Timer?
    private var displayLink: CADisplayLink?
    private var driver: Driver = .none
    private var lastFrame: TimeInterval = 0
    /// 검색 창이 스펙트럼을 가져가 있는 동안엔 메뉴바 쪽은 그리지 않음 (안 보이는데 그리면 낭비)
    private var spectrumBorrowed = false
    /// 위젯·검색 창 스펙트럼은 초당 60번이면 충분 (메뉴바는 설정대로 최대 120)
    private var lastSecondaryPush: TimeInterval = 0
    private var lastHoverCheck: TimeInterval = 0

    // 소리 감지
    private(set) var musicActive = false
    private var loudSince: TimeInterval?
    private var lastLoud: TimeInterval = -100

    // 마우스 호버로 펼치기
    private(set) var revealed = false
    private var lastPointerInBar: TimeInterval = 0
    private var lastPopupCheck: TimeInterval = 0

    // 기타
    private var peekUntil: TimeInterval = 0
    private var openMenuAttempts = 0
    var menuOpen = false
    private(set) var arrangeMode = false
    private var displayed: [CGFloat] = []
    private var velocities: [CGFloat] = []     // 중력 낙하 속도
    private var peaks: [CGFloat] = []          // 피크 캡 높이
    private var peakHold: [CGFloat] = []       // 피크가 머무는 남은 시간
    private var peakVelocities: [CGFloat] = []
    private var agcReference: CGFloat = 0.5    // 자동 음량 맞춤 기준값
    private var permissionNotified = false
    var onPermissionSuspect: (@MainActor () -> Void)?

    // 감지 기준
    private let startThreshold: Float = 0.004   // 약 -48 dBFS 넘으면 '소리 남'
    private let keepThreshold: Float = 0.001    // 재생 중엔 약 -60 dBFS까지 유지 (조용한 구간 대비)
    private let startDelay: TimeInterval = 1.0  // 1초 넘게 이어져야 시작 (짧은 알림음 무시)
    private let revealHold: TimeInterval = 1.2  // 마우스가 메뉴바를 벗어난 뒤 다시 숨기기까지

    /// 아이콘 배치 모드·애니메이션은 macOS 26 이하 방식에서만 의미가 있음
    var usesLengthHiding: Bool { hider is LengthHider }

    /// 메뉴바 스펙트럼의 화면 위치 (보이고 있을 때만)
    var spectrumScreenFrame: NSRect? {
        guard let button = spectrumItem.button, let window = button.window,
              spectrumItem.length > 1, window.isVisible else { return nil }
        let frame = window.convertToScreen(button.convert(button.bounds, to: nil))
        return frame.width > 1 ? frame : nil
    }

    /// 검색 창이 스펙트럼을 '끌어가' 있는 동안 메뉴바 쪽은 숨김
    func setSpectrumBorrowed(_ borrowed: Bool, animated: Bool = true) {
        spectrumBorrowed = borrowed
        if !borrowed { spectrumView.update(levels: displayed, peaks: peaks) }
        NSAnimationContext.runAnimationGroup { context in
            context.duration = animated ? 0.15 : 0
            spectrumView.animator().alphaValue = borrowed ? 0 : 1
        }
    }

    init(store: LevelStore) {
        self.store = store

        // 스펙트럼은 처음엔 맨 오른쪽(시계 쪽), 구분선은 그 바로 왼쪽에 생기도록 위치 기본값 지정
        StatusItemPosition.setDefault(MenuBarController.spectrumAutosaveName, 0)
        let item = NSStatusBar.system.statusItem(withLength: 0)
        item.autosaveName = MenuBarController.spectrumAutosaveName
        spectrumItem = item

        if ProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 27 {
            hider = NativeHider()
        } else {
            hider = LengthHider()
        }
        super.init()

        if let button = spectrumItem.button {
            spectrumView.frame = button.bounds
            spectrumView.autoresizingMask = [.width, .height]
            button.addSubview(spectrumView)
        }
        applyAppearance()
        StatusItemPosition.setVisible(spectrumItem, false)   // 평소엔 숨김

        // 상태 점검용 5Hz 타이머는 항상 돈다 (화면 동기화가 멈춰도 상태 판정이 멈추지 않도록)
        let t = Timer(timeInterval: 0.2, target: self, selector: #selector(slowTick), userInfo: nil, repeats: true)
        t.tolerance = 0.05
        RunLoop.main.add(t, forMode: .common)
        slowTimer = t
    }

    // MARK: - 외부에서 호출

    func setMenu(_ menu: NSMenu) {
        spectrumItem.menu = menu
    }

    /// 설정(막대 개수·두께·간격·모양·색상) 반영
    func applyAppearance() {
        var look = SpectrumLook()
        look.shape = settings.barShape
        look.style = settings.barStyle
        look.colorMode = settings.colorMode
        look.barWidth = CGFloat(settings.barWidth)
        look.barGap = CGFloat(settings.barGap)
        look.verticalFade = settings.verticalFade
        look.levelColor = settings.levelColor
        look.peakCaps = settings.peakCaps
        spectrumView.look = look

        let n = settings.bandCount
        if displayed.count != n { resetBars(count: n) }
        if driver != .none { setDriver(desiredDriver) }   // 화면 동기화 설정 변경 반영
        widget?.applyAppearance()
        let width = spectrumWidth
        if spectrumItem.length != width { spectrumItem.length = width }
    }

    /// 잠깐 보여 주기 (실행 직후, 앱을 다시 열었을 때)
    func peek(seconds: TimeInterval) {
        peekUntil = max(peekUntil, monotonicNow() + seconds)
        reconcile(now: monotonicNow())
        setDriver(desiredDriver)
    }

    /// 숨어 있을 때 앱을 다시 실행하면: 스펙트럼을 꺼내고 설정 메뉴를 연다
    func openMenuSoon() {
        peek(seconds: 15)
        openMenuAttempts = 0
        perform(#selector(tryOpenMenu), with: nil, afterDelay: 0.3)
    }

    func setArrangeMode(_ on: Bool) {
        arrangeMode = on
        if on { revealed = false }
        reconcile(now: monotonicNow())
    }

    /// 스펙트럼을 맨 오른쪽, 구분선을 그 바로 왼쪽으로 되돌림
    func resetPositions() {
        StatusItemPosition.setVisible(spectrumItem, false)
        StatusItemPosition.setPreferred(MenuBarController.spectrumAutosaveName, 0)
        hider.resetPositions()
        peek(seconds: 5)
    }

    func teardown() {
        slowTimer?.invalidate()
        setDriver(.none)
        hider.teardown()
    }

    /// 메뉴 맨 위에 보여 줄 상태 설명
    var statusLines: [String] {
        let snap = store.read()
        var lines: [String] = []
        if musicActive {
            lines.append("♪ 소리 감지됨 — 스펙트럼 표시 중")
        } else if snap.outputActive {
            lines.append("오디오 출력 감지됨 — 소리를 기다리는 중")
        } else {
            lines.append("대기 중 — 소리가 나면 나타납니다")
        }
        if let error = snap.lastError {
            lines.append("⚠︎ 오디오 캡처 오류: \(error)")
        }
        if snap.permissionSuspect {
            lines.append("⚠︎ 무음만 들어옵니다 — 시스템 오디오 녹음 권한을 확인하세요")
        }
        if settings.hideOthers, let problem = hider.problem {
            lines.append("⚠︎ \(problem)")
        }
        return lines
    }

    // MARK: - 타이머 (보일 때 60fps, 숨어 있을 때 5fps)

    private var spectrumWidth: CGFloat {
        SpectrumView.width(bands: settings.bandCount, barWidth: settings.barWidth, gap: settings.barGap)
    }

    /// 지금 필요한 갱신 방식
    private var desiredDriver: Driver {
        let widgetShowing = widget?.isShowing ?? false
        guard spectrumItem.isVisible || musicActive || hider.isBusy || widgetShowing else { return .none }
        return settings.displaySync && spectrumItem.isVisible ? .display : .timer
    }

    private func setDriver(_ wanted: Driver) {
        guard wanted != driver else { return }
        fastTimer?.invalidate()
        fastTimer = nil
        displayLink?.invalidate()
        displayLink = nil
        driver = wanted

        switch wanted {
        case .none:
            break
        case .timer:
            let t = Timer(timeInterval: 1.0 / 60.0, target: self, selector: #selector(fastTick),
                          userInfo: nil, repeats: true)
            t.tolerance = 0.004
            RunLoop.main.add(t, forMode: .common)   // 메뉴가 열려 있어도 계속 동작
            fastTimer = t
        case .display:
            // ProMotion 화면이면 최대 120Hz로 화면 갱신에 맞춰 그림
            let link = spectrumView.displayLink(target: self, selector: #selector(displayTick(_:)))
            link.preferredFrameRateRange = CAFrameRateRange(minimum: 30, maximum: 120, preferred: 120)
            link.add(to: .main, forMode: .common)
            displayLink = link
        }
    }

    @objc private func slowTick() { tick() }
    @objc private func fastTick() { tick() }
    @objc private func displayTick(_ link: CADisplayLink) { tick() }

    @objc private func tick() {
        let now = monotonicNow()
        let snap = store.read()

        updateSoundState(now: now, snap: snap)
        // 마우스 위치 확인은 초당 30번이면 충분
        if now - lastHoverCheck >= 1.0 / 30 {
            lastHoverCheck = now
            updateHover(now: now)
        }
        reconcile(now: now)
        if spectrumItem.isVisible || (widget?.isShowing ?? false) { animateBars(now: now, snap: snap) }

        if snap.permissionSuspect && !permissionNotified {
            permissionNotified = true
            onPermissionSuspect?()
        }

        let wanted = desiredDriver
        if wanted != driver { setDriver(wanted) }
    }

    @objc private func tryOpenMenu() {
        if let window = spectrumItem.button?.window, window.frame.origin != .zero, window.frame.width > 1 {
            spectrumItem.button?.performClick(nil)
        } else if openMenuAttempts < 10 {
            openMenuAttempts += 1
            perform(#selector(tryOpenMenu), with: nil, afterDelay: 0.25)
        }
    }

    // MARK: - 소리 감지 (RMS 기준, 시작 1초 / 종료는 설정한 시간)

    private func updateSoundState(now: TimeInterval, snap: LevelStore.Snapshot) {
        let rms: Float = now - snap.lastAudio < 0.35 ? snap.rms : 0

        if rms > startThreshold {
            if loudSince == nil { loudSince = now }
            lastLoud = now
        } else if musicActive && rms > keepThreshold {
            lastLoud = now
        } else if loudSince != nil && now - lastLoud > 0.4 {
            loudSince = nil
        }

        if !musicActive, let since = loudSince, now - since >= startDelay {
            musicActive = true
        } else if musicActive && now - lastLoud >= settings.hideDelay {
            musicActive = false
            loudSince = nil
            revealed = false
        }
    }

    // MARK: - 마우스 호버로 펼치기

    private func updateHover(now: TimeInterval) {
        guard musicActive, settings.hideOthers, !arrangeMode, spectrumItem.isVisible,
              let window = spectrumItem.button?.window, window.frame.origin != .zero else {
            revealed = false
            return
        }

        let mouse = NSEvent.mouseLocation
        let homeScreen = window.screen ?? NSScreen.main
        // 스펙트럼이 '화면 오른쪽 끝에서 얼마나 떨어져 있는지' → 다른 모니터의 메뉴바에도 같은 위치로 적용
        let distanceFromRight = (homeScreen?.frame.maxX ?? window.frame.maxX) - window.frame.minX

        var inBar = false
        var inHotZone = false
        var barHeight = NSStatusBar.system.thickness
        if let screen = NSScreen.screens.first(where: { $0.frame.insetBy(dx: 0, dy: -2).contains(mouse) }) {
            barHeight = max(NSStatusBar.system.thickness, screen.frame.maxY - screen.visibleFrame.maxY)
            inBar = mouse.y >= screen.frame.maxY - barHeight - 1
            inHotZone = inBar && mouse.x >= screen.frame.maxX - distanceFromRight - 2
        }

        // 스펙트럼 위(또는 그 오른쪽 시계 쪽)에 올라가면 펼치기
        if inHotZone {
            revealed = true
            lastPointerInBar = now
            return
        }
        guard revealed else { return }

        // 메뉴바 위에 있거나 클릭 중이면 펼친 상태 유지 → 펼쳐진 아이콘을 누를 수 있음
        if inBar || NSEvent.pressedMouseButtons != 0 {
            lastPointerInBar = now
            return
        }
        guard now - lastPointerInBar > revealHold, now - lastPopupCheck > 0.3 else { return }
        lastPopupCheck = now
        if MenuBarProbe.menuOrPopoverIsOpen(menuBarHeight: barHeight) {
            lastPointerInBar = now        // 펼친 아이콘의 메뉴를 쓰는 중이면 유지
        } else {
            revealed = false
        }
    }

    // MARK: - 메뉴바 상태 맞추기

    private func reconcile(now: TimeInterval) {
        let show = settings.showMode == .always || musicActive || now < peekUntil || menuOpen || arrangeMode
        if show != spectrumItem.isVisible {
            if show {
                spectrumItem.length = spectrumWidth
            } else {
                resetBars(count: displayed.count)
            }
            StatusItemPosition.setVisible(spectrumItem, show)
        }

        // 메뉴가 열려 있는 동안엔 메뉴바 배치를 바꾸지 않음
        guard !menuOpen else { return }

        let wantHidden = settings.hideOthers && musicActive && !revealed && !arrangeMode && spectrumItem.isVisible
        hider.update(wantHidden: wantHidden,
                     needed: (settings.hideOthers && musicActive) || arrangeMode,
                     arrange: arrangeMode,
                     animate: settings.animate,
                     spectrum: spectrumItem)
    }

    // MARK: - 막대 애니메이션 (시간 기준이라 60Hz·120Hz 어디서나 같은 속도)

    private func resetBars(count n: Int) {
        displayed = Array(repeating: 0, count: n)
        velocities = Array(repeating: 0, count: n)
        peaks = Array(repeating: 0, count: n)
        peakHold = Array(repeating: 0, count: n)
        peakVelocities = Array(repeating: 0, count: n)
        spectrumView.update(levels: displayed, peaks: peaks)
        widget?.update(levels: displayed, peaks: peaks)
    }

    private func animateBars(now: TimeInterval, snap: LevelStore.Snapshot) {
        let n = displayed.count
        guard n > 0 else { return }
        let dt = CGFloat(min(0.1, max(0.001, now - lastFrame)))
        lastFrame = now

        // 1) 목표 높이
        let fresh = now - snap.lastAudio < 0.3 && snap.levels.count == n
        var targets = (0..<n).map { fresh ? CGFloat(snap.levels[$0]) : 0 }

        // 2) 이웃 막대 부드럽게 (산 모양)
        let weights: [CGFloat] = [0, 0.3, 0.65]
        let a = weights[min(max(settings.smoothing, 0), 2)]
        if a > 0 && n > 2 {
            var smoothed = targets
            for i in 0..<n {
                let left = targets[max(i - 1, 0)]
                let right = targets[min(i + 1, n - 1)]
                smoothed[i] = (targets[i] + a * (left + right)) / (1 + 2 * a)
            }
            targets = smoothed
        }

        // 3) 자동 음량 맞춤: 최근 최대값을 기준으로 높이를 키움 (빠르게 따라 올라가고 몇 초에 걸쳐 내려옴)
        if settings.autoGain {
            let loudest = targets.max() ?? 0
            if loudest > agcReference {
                agcReference += (loudest - agcReference) * min(1, dt * 10)
            } else if fresh {
                agcReference -= (agcReference - loudest) * min(1, dt * 0.3)
            }
            agcReference = max(0.35, agcReference)
            let gain = 0.92 / agcReference
            targets = targets.map { min(1, $0 * gain) }
        }

        // 4) 막대: 올라갈 땐 빠르게, 내려갈 땐 일정 속도 또는 중력 가속
        let attack = 1 - CGFloat(exp(-Double(dt) * 40))
        let gravity = settings.fallMode == .gravity
        var changed = false
        for i in 0..<n {
            let target = targets[i]
            let old = displayed[i]
            var value = old
            if target >= value {
                value += (target - value) * attack
                velocities[i] = 0
            } else if gravity {
                velocities[i] += 4.5 * dt
                value = max(target, value - velocities[i] * dt)
                if value == target { velocities[i] = 0 }
            } else {
                value = max(target, value - 1.8 * dt)
            }
            displayed[i] = value

            // 5) 피크 캡: 0.4초 머문 뒤 천천히 떨어짐
            if value >= peaks[i] {
                peaks[i] = value
                peakHold[i] = 0.4
                peakVelocities[i] = 0
            } else if peakHold[i] > 0 {
                peakHold[i] -= dt
            } else {
                peakVelocities[i] += 1.4 * dt
                peaks[i] = max(value, peaks[i] - peakVelocities[i] * dt)
            }

            if abs(value - old) > 0.0005 || peaks[i] > value + 0.0005 { changed = true }
        }
        if changed {
            if !spectrumBorrowed { spectrumView.update(levels: displayed, peaks: peaks) }
            if now - lastSecondaryPush >= 1.0 / 61 {
                lastSecondaryPush = now
                widget?.update(levels: displayed, peaks: peaks)
                search?.updateSpectrum(levels: displayed, peaks: peaks)
            }
        }
    }
}
