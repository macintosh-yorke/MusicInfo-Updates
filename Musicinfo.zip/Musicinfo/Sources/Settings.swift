import Foundation

enum BarStyle: Int { case bottom = 0, mirror = 1 }
/// 색상 테마 (gradient = 무지개)
enum ColorMode: Int { case mono = 0, gradient = 1, neon = 2, sunset = 3, ocean = 4, white = 5 }
/// 막대 모양
enum BarShape: Int { case rounded = 0, pill = 1, led = 2, wave = 3 }
/// 내려오는 방식
enum FallMode: Int { case linear = 0, gravity = 1 }
enum ShowMode: Int { case auto = 0, always = 1 }

/// 단조 증가 시계(초). 시스템 시간 변경의 영향을 받지 않는다.
func monotonicNow() -> TimeInterval { ProcessInfo.processInfo.systemUptime }

/// 개발용 기록: 임시 폴더의 SpectrumBar-debug.log (커지면 비움)
private let debugLogQueue = DispatchQueue(label: "SpectrumBar.debugLog")
func debugLog(_ message: String) {
    let line = "\(Date().formatted(date: .omitted, time: .standard)) \(message)\n"
    debugLogQueue.async {
        let url = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("SpectrumBar-debug.log")
        if let size = try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int, size > 200_000 {
            try? FileManager.default.removeItem(at: url)
        }
        if let handle = try? FileHandle(forWritingTo: url) {
            handle.seekToEndOfFile()
            handle.write(Data(line.utf8))
            try? handle.close()
        } else {
            try? Data(line.utf8).write(to: url)
        }
    }
}

/// UserDefaults 기반 설정 (메인 스레드에서만 사용)
final class Settings {
    static let shared = Settings()
    private let d = UserDefaults.standard

    private func int(_ key: String, _ fallback: Int) -> Int {
        d.object(forKey: key) == nil ? fallback : d.integer(forKey: key)
    }

    private func bool(_ key: String, _ fallback: Bool) -> Bool {
        d.object(forKey: key) == nil ? fallback : d.bool(forKey: key)
    }

    // MARK: 스펙트럼 모양

    var bandCount: Int {
        get { int("bandCount", 32) }
        set { d.set(newValue, forKey: "bandCount") }
    }

    /// 막대 두께(px)
    var barWidth: Int {
        get { int("barWidth", 4) }
        set { d.set(newValue, forKey: "barWidth") }
    }

    /// 막대 사이 간격(px)
    var barGap: Int {
        get { int("barGap", 2) }
        set { d.set(newValue, forKey: "barGap") }
    }

    var barStyle: BarStyle {
        get { BarStyle(rawValue: int("barStyle", 0)) ?? .bottom }
        set { d.set(newValue.rawValue, forKey: "barStyle") }
    }

    var colorMode: ColorMode {
        get { ColorMode(rawValue: int("colorMode", ColorMode.white.rawValue)) ?? .white }
        set { d.set(newValue.rawValue, forKey: "colorMode") }
    }

    /// 표시 감도(dB). 낮음 -6 / 보통 0 / 높음 +8
    var gain: Float {
        get { d.object(forKey: "gain") == nil ? -6 : d.float(forKey: "gain") }
        set { d.set(newValue, forKey: "gain") }
    }

    // MARK: 디자인

    var barShape: BarShape {
        get { BarShape(rawValue: int("barShape", BarShape.rounded.rawValue)) ?? .rounded }
        set { d.set(newValue.rawValue, forKey: "barShape") }
    }

    /// 막대 끝으로 갈수록 투명해지는 세로 그라데이션
    var verticalFade: Bool {
        get { bool("verticalFade", true) }
        set { d.set(newValue, forKey: "verticalFade") }
    }

    /// 소리가 클수록 밝은 색
    var levelColor: Bool {
        get { bool("levelColor", true) }
        set { d.set(newValue, forKey: "levelColor") }
    }

    // MARK: 움직임

    var fallMode: FallMode {
        get { FallMode(rawValue: int("fallMode", FallMode.linear.rawValue)) ?? .linear }
        set { d.set(newValue.rawValue, forKey: "fallMode") }
    }

    /// 막대 위에 떠 있다가 천천히 떨어지는 피크 캡
    var peakCaps: Bool {
        get { bool("peakCaps", false) }
        set { d.set(newValue, forKey: "peakCaps") }
    }

    /// 이웃 막대 부드럽게: 0 끔 / 1 약하게 / 2 강하게
    var smoothing: Int {
        get { int("smoothing", 2) }
        set { d.set(newValue, forKey: "smoothing") }
    }

    /// 자동 음량 맞춤 (조용한 곡도 높이를 채움)
    var autoGain: Bool {
        get { bool("autoGain", true) }
        set { d.set(newValue, forKey: "autoGain") }
    }

    /// 화면 주사율에 맞춰 그리기 (ProMotion 최대 120Hz)
    var displaySync: Bool {
        get { bool("displaySync", true) }
        set { d.set(newValue, forKey: "displaySync") }
    }

    // MARK: 바탕화면 위젯

    var widgetEnabled: Bool {
        get { bool("widgetEnabled", true) }
        set { d.set(newValue, forKey: "widgetEnabled") }
    }

    /// 0 = 2×2 (애플 소형 위젯, 기본) / 1 = 4×4 (애플 대형 위젯)
    var widgetSize: Int {
        get { int("widgetSize2x2", 0) }
        set { d.set(newValue, forKey: "widgetSize2x2") }
    }

    /// 0 재생 중일 때만 / 1 곡이 있으면 항상 (일시정지 포함)
    var widgetShowMode: Int {
        get { int("widgetShowMode", 0) }
        set { d.set(newValue, forKey: "widgetShowMode") }
    }

    /// 평상시 글라스 스타일: 켜면 기본(Regular), 끄면 맑은(Clear) 리퀴드 글라스
    var widgetBackground: Bool {
        get { bool("widgetBackground", true) }
        set { d.set(newValue, forKey: "widgetBackground") }
    }

    /// 위치 고정 (끄면 아무 때나 끌어서 이동)
    var widgetLocked: Bool {
        get { bool("widgetLocked", false) }
        set { d.set(newValue, forKey: "widgetLocked") }
    }

    /// 위젯 아래쪽 미니 스펙트럼
    var widgetSpectrum: Bool {
        get { bool("widgetSpectrum", true) }
        set { d.set(newValue, forKey: "widgetSpectrum") }
    }

    /// 위젯 재생 버튼 (이전·재생/일시정지·다음)
    var widgetControls: Bool {
        get { bool("widgetControls", true) }
        set { d.set(newValue, forKey: "widgetControls") }
    }

    /// 제목·아티스트 가운데 정렬
    var widgetCenterText: Bool {
        get { bool("widgetCenterText", true) }
        set { d.set(newValue, forKey: "widgetCenterText") }
    }

    /// 위젯 커버 왼쪽 위에 가사 표시 (LRCLIB에서 받아 옴)
    var widgetLyrics: Bool {
        get { bool("widgetLyrics", true) }
        set { d.set(newValue, forKey: "widgetLyrics") }
    }

    /// 위젯 제목 위 오른쪽에 다음 곡 표시
    var widgetUpNext: Bool {
        get { bool("widgetUpNext", true) }
        set { d.set(newValue, forKey: "widgetUpNext") }
    }

    /// 우리 위젯이 보일 때 애플 바탕화면 위젯 숨기기
    var widgetHideOthers: Bool {
        get { bool("widgetHideOthers", true) }
        set { d.set(newValue, forKey: "widgetHideOthers") }
    }

    var widgetX: Double? {
        get { d.object(forKey: "widgetX") as? Double }
        set { d.set(newValue, forKey: "widgetX") }
    }

    var widgetY: Double? {
        get { d.object(forKey: "widgetY") as? Double }
        set { d.set(newValue, forKey: "widgetY") }
    }

    // MARK: 표시 동작

    /// 소리가 날 때만 표시 / 항상 표시
    var showMode: ShowMode {
        get { ShowMode(rawValue: int("showMode", 0)) ?? .auto }
        set { d.set(newValue.rawValue, forKey: "showMode") }
    }

    /// 소리가 멈춘 뒤 숨기기까지 기다리는 시간(초)
    var hideDelay: Double {
        get { d.object(forKey: "hideDelay") == nil ? 3 : d.double(forKey: "hideDelay") }
        set { d.set(newValue, forKey: "hideDelay") }
    }

    /// 재생 중 다른 메뉴바 아이콘 숨기기
    var hideOthers: Bool {
        get { bool("hideOthers", true) }
        set { d.set(newValue, forKey: "hideOthers") }
    }

    /// 펼치기/접기 애니메이션 (macOS 26 이하에서만 사용)
    var animate: Bool {
        get { bool("animate", true) }
        set { d.set(newValue, forKey: "animate") }
    }

    /// 권한 안내 창을 마지막으로 보여 준 앱 빌드 번호 (버전당 한 번만 안내)
    var permissionHintVersion: String? {
        get { d.string(forKey: "permissionHintVersion") }
        set { d.set(newValue, forKey: "permissionHintVersion") }
    }
}
