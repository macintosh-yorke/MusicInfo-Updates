#!/bin/bash
# MusicInfo 빌드 스크립트 (Xcode 불필요, Command Line Tools만 있으면 됨)
#   ./build.sh            → build/MusicInfo.app 생성 (현재 맥 아키텍처)
#   ./build.sh universal  → Apple Silicon + Intel 겸용
#   ./build.sh install    → 빌드 후 /Applications 에 설치하고 실행 (권장)
#
# 개발자 인증서가 있으면 서명을 고정해 재빌드 때마다 권한을 다시 묻지 않게 할 수 있음:
#   SIGN_ID="Apple Development: 이름 (팀ID)" ./build.sh install
set -euo pipefail
cd "$(dirname "$0")"

# 개발용: debug/probe.applescript 가 있으면 한 번 실행해서 결과를 debug/probe.out 에 남김
if [[ -f debug/probe.applescript ]]; then
  osascript debug/probe.applescript > debug/probe.out 2>&1 || true
  mv -f debug/probe.applescript debug/probe.applescript.done
fi
# 개발용: 앱 디버그 기록·서명 인증서 목록을 debug/ 로 복사
if [[ -d debug ]]; then
  cp -f "${TMPDIR:-/tmp}/SpectrumBar-debug.log" debug/app.log 2>/dev/null || true
  security find-identity -v -p codesigning > debug/identities.txt 2>&1 || true
fi
# 개발용: debug/fix-tcc 가 있으면 이 앱의 손쉬운 사용·자동화 권한 기록을 지우고(서명이 바뀌어 꼬인 것 정리)
# 앱을 다시 켜서 권한 요청 창이 새로 뜨게 함
if [[ -f debug/fix-tcc ]]; then
  mv -f debug/fix-tcc debug/fix-tcc.done
  { echo "== 서명"; codesign -dvv /Applications/MusicInfo.app 2>&1 | grep -E "Authority|Identifier|TeamIdentifier|Signature" || true
    echo "== reset"; tccutil reset Accessibility com.nemo.SpectrumBar 2>&1 || true
    tccutil reset AppleEvents com.nemo.SpectrumBar 2>&1 || true
    defaults delete com.nemo.SpectrumBar askedQueueAccess 2>&1 || true
    pkill -x MusicInfo 2>/dev/null || true; sleep 1; open /Applications/MusicInfo.app; echo restarted; } > debug/fix-tcc.txt 2>&1
fi
# 개발용: debug/shot-search 가 있으면 검색 창을 열어 화면을 찍음 (내용 = open 또는 query:검색어)
shot_search() {
  local cmd; cmd=$(cat debug/shot-search 2>/dev/null || echo open)
  mv -f debug/shot-search debug/shot-search.done
  osascript -l JavaScript -e "ObjC.import('Foundation'); \$.NSDistributedNotificationCenter.defaultCenter.postNotificationNameObjectUserInfoDeliverImmediately('com.nemo.MusicInfo.dev.search', '$cmd', \$(), true)" >/dev/null 2>&1 || true
  sleep 1.5
  screencapture -x -m debug/search.png || true
  osascript -l JavaScript -e "ObjC.import('Foundation'); \$.NSDistributedNotificationCenter.defaultCenter.postNotificationNameObjectUserInfoDeliverImmediately('com.nemo.MusicInfo.dev.search', 'close', \$(), true)" >/dev/null 2>&1 || true
}
if [[ -f debug/probe-only ]]; then
  { ps -axo pid,etime,comm | grep -E "MusicInfo|Music$" | grep -v grep; ls -t ~/Library/Logs/DiagnosticReports 2>/dev/null | grep -i musicinfo | head -3; } > debug/ps.txt 2>&1 || true
  # CPU·메모리 사용량 (2초 간격 4번)
  pid=$(pgrep -x MusicInfo | head -1)
  [[ -n "$pid" ]] && top -l 4 -s 2 -pid "$pid" -stats pid,cpu,mem,threads 2>/dev/null | grep -E "^ *$pid" > debug/cpu.txt || true
  # 어디에 CPU를 쓰는지 3초 표본 (debug/sample 이 있을 때만)
  if [[ -n "$pid" && -f debug/sample ]]; then
    mv -f debug/sample debug/sample.done
    sample "$pid" 3 -mayDie -file debug/sample.txt >/dev/null 2>&1 || true
  fi
  latest=$(ls -t ~/Library/Logs/DiagnosticReports/MusicInfo* 2>/dev/null | head -1)
  [[ -n "$latest" ]] && cp -f "$latest" debug/crash.ips || true
fi
if [[ -f debug/shot-search && -f debug/probe-only ]]; then shot_search; fi
# 개발용: debug/dev-cmd (1줄: 보낼 명령, 2줄: 찍은 뒤 되돌릴 명령) → 화면을 debug/dev.png 로
if [[ -f debug/dev-cmd && -f debug/probe-only ]]; then
  first=$(sed -n 1p debug/dev-cmd); second=$(sed -n 2p debug/dev-cmd)
  mv -f debug/dev-cmd debug/dev-cmd.done
  post() { osascript -l JavaScript -e "ObjC.import('Foundation'); \$.NSDistributedNotificationCenter.defaultCenter.postNotificationNameObjectUserInfoDeliverImmediately('com.nemo.MusicInfo.dev.search', '$1', \$(), true)" >/dev/null 2>&1 || true; }
  post "$first"; sleep 1.2
  screencapture -x -m debug/dev.png || true
  [[ -n "$second" ]] && post "$second"
fi
# 개발용: debug/probe-only 가 있으면 위 확인만 하고 빌드는 건너뜀 (권한이 풀리지 않게)
if [[ -f debug/probe-only ]]; then
  mv -f debug/probe-only debug/probe-only.done
  echo "probe only"; exit 0
fi

APP=MusicInfo
OLD_APP=SpectrumBar   # 예전 이름 (설치할 때 지움)
OUT=build/$APP.app
MODE="${1:-}"
MIN_OS=14.4
# 서명: 이 맥에 Apple Development 인증서가 있으면 자동으로 사용
#  → 다시 빌드해도 서명이 같아서 손쉬운 사용·자동화 권한이 풀리지 않음 (임시 서명은 빌드마다 풀림)
if [[ -z "${SIGN_ID:-}" ]]; then
  SIGN_ID=$(security find-identity -v -p codesigning 2>/dev/null | awk '/Apple Development|Developer ID Application/ {print $2; exit}')
fi
SIGN_ID="${SIGN_ID:--}"

if ! command -v swiftc >/dev/null; then
  echo "swiftc가 없습니다. 먼저 'xcode-select --install'을 실행하세요."; exit 1
fi

rm -rf build
mkdir -p "$OUT/Contents/MacOS" "$OUT/Contents/Resources"

build_arch() {
  local arch="$1" output="$2"
  # Objective-C 래퍼 (macOS 27 메뉴바 숨기기용)
  clang -c -fobjc-arc -O2 -target "$arch-apple-macos$MIN_OS" \
    Sources/MenuBarRestriction.m -o "build/MenuBarRestriction-$arch.o"
  # Swift 본체
  swiftc -O -swift-version 5 -parse-as-library -module-name "$APP" \
    -target "$arch-apple-macos$MIN_OS" \
    -import-objc-header Sources/SpectrumBar-Bridging.h \
    Sources/*.swift "build/MenuBarRestriction-$arch.o" \
    -framework AppKit -framework CoreAudio -framework AudioToolbox \
    -framework Accelerate -framework ServiceManagement \
    -F Vendor -framework Sparkle \
    -Xlinker -rpath -Xlinker @executable_path/../Frameworks \
    -o "$output"
}

if [[ "$MODE" == "universal" ]]; then
  build_arch arm64 "build/$APP-arm64"
  build_arch x86_64 "build/$APP-x86_64"
  lipo -create "build/$APP-arm64" "build/$APP-x86_64" -output "$OUT/Contents/MacOS/$APP"
else
  build_arch "$(uname -m)" "$OUT/Contents/MacOS/$APP"
fi

cp Info.plist "$OUT/Contents/Info.plist"
cp Resources/AppIcon.icns "$OUT/Contents/Resources/AppIcon.icns"
chmod 644 "$OUT/Contents/Resources/AppIcon.icns"
cp Vendor/Sparkle-LICENSE.txt "$OUT/Contents/Resources/Sparkle-LICENSE.txt"
mkdir -p "$OUT/Contents/Frameworks"
ditto Vendor/Sparkle.framework "$OUT/Contents/Frameworks/Sparkle.framework"
if ! codesign --force --sign "$SIGN_ID" "$OUT"; then
  echo "⚠️ 인증서 서명 실패 → 임시 서명으로 대신함"
  codesign --force --sign - "$OUT"
fi
echo "서명: $(codesign -dv "$OUT" 2>&1 | grep -E '^(Authority|Signature)=' | head -1)"
echo "✅ 빌드 완료: $OUT"

if [[ "$MODE" == "install" ]]; then
  LSREGISTER=/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister
  pkill -x "$APP" 2>/dev/null || true
  sleep 0.5
  # 예전 이름(SpectrumBar)으로 설치된 앱은 끄고 지움 → 앱이 두 개 보이지 않게
  pkill -x "$OLD_APP" 2>/dev/null || true
  if [[ -d "/Applications/$OLD_APP.app" ]]; then
    "$LSREGISTER" -u "/Applications/$OLD_APP.app" 2>/dev/null || true
    rm -rf "/Applications/$OLD_APP.app"
  fi
  rm -rf "/Applications/$APP.app"
  cp -R "$OUT" /Applications/
  # 빌드 폴더 사본은 지우고 등록도 해제 → Spotlight·Launchpad에 앱이 하나만 보이게
  "$LSREGISTER" -u "$PWD/$OUT" 2>/dev/null || true
  rm -rf "$OUT"
  # 새 이름·아이콘이 바로 보이게 등록 갱신
  "$LSREGISTER" -f "/Applications/$APP.app" 2>/dev/null || true
  touch "/Applications/$APP.app"
  open "/Applications/$APP.app"
  if [[ -d debug ]]; then
    { echo "== /Applications"; ls -d /Applications/*Spectrum* /Applications/*MusicInfo* 2>&1 || true
      echo "== 실행 중"; sleep 2; ps -axo pid,comm | grep -E "MusicInfo|SpectrumBar" | grep -v grep || true
      echo "== Info"; /usr/libexec/PlistBuddy -c "Print :CFBundleName" "/Applications/$APP.app/Contents/Info.plist" || true
      ls "/Applications/$APP.app/Contents/Resources" || true; } > debug/install.txt 2>&1 || true
  fi
  echo "✅ /Applications 에 설치하고 실행했습니다. (빌드 폴더 사본은 정리함)"
  if [[ -f debug/shot-search ]]; then sleep 3; shot_search; fi
else
  echo "실행: open $OUT"
  echo "※ macOS 27 이상에서 '다른 아이콘 숨기기'는 ./build.sh install 로 /Applications 에 설치해야 동작합니다."
fi
